(function () {
  "use strict";

  var API = "https://dromocob.tr/api/licenses/desktop";
  var PRODUCT = "dromocob-ultra-ae";
  var VERSION = "2.7.0";
  var RECEIPT_KEY = "dromocob.license.receipt.v1";
  var DEVICE_KEY = "dromocob.license.deviceSeed.v1";
  var publicKey = "-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEJIaXjBazqILzkD5yiE/Ohr5myG5j\nLjlc3J8iDyQ9fQcCPQiDZTolIAv37dHgonh4mi6nKqHSORynKnbGyjIx4A==\n-----END PUBLIC KEY-----\n";
  var state = { valid: false, receipt: null, deviceHash: "", error: "" };

  function nodeCrypto() { try { return window.require ? window.require("crypto") : null; } catch (_) { return null; } }
  function randomHex(bytes) {
    var crypto = nodeCrypto();
    if (crypto) return crypto.randomBytes(bytes).toString("hex");
    var output = "";
    for (var i = 0; i < bytes * 2; i++) output += Math.floor(Math.random() * 16).toString(16);
    return output;
  }
  function deviceHash() {
    var seed = localStorage.getItem(DEVICE_KEY);
    if (!seed) { seed = randomHex(32); localStorage.setItem(DEVICE_KEY, seed); }
    var source = [seed, navigator.platform, navigator.userAgent, "com.dromocob.ultra.panel"].join("|");
    var crypto = nodeCrypto();
    if (!crypto) return Promise.reject(new Error("Güvenli cihaz kimliği üretilemedi."));
    state.deviceHash = crypto.createHash("sha256").update(source, "utf8").digest("hex");
    return Promise.resolve(state.deviceHash);
  }
  function request(path, payload, method, bearer, absolute) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open(method || "POST", absolute ? path : API + path, true);
      xhr.timeout = 15000;
      xhr.setRequestHeader("Content-Type", "application/json");
      if (bearer) xhr.setRequestHeader("Authorization", "Bearer " + bearer);
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;
        var result;
        try { result = JSON.parse(xhr.responseText || "{}"); } catch (_) { result = {}; }
        if (xhr.status >= 200 && xhr.status < 300 && result.ok) resolve(result);
        else reject(new Error(result.error || "Lisans sunucusuna ulaşılamadı."));
      };
      xhr.onerror = function () { reject(new Error("Lisans sunucusuna ulaşılamadı.")); };
      xhr.ontimeout = function () { reject(new Error("Lisans doğrulaması zaman aşımına uğradı.")); };
      xhr.send(payload ? JSON.stringify(payload) : null);
    });
  }
  function canonical(payload) {
    return JSON.stringify({
      activationId: payload.activationId, deviceHash: payload.deviceHash, issuedAt: payload.issuedAt,
      licenseId: payload.licenseId, offlineUntil: payload.offlineUntil, plan: payload.plan,
      productId: payload.productId, receiptId: payload.receiptId, userId: payload.userId,
      validUntil: payload.validUntil, version: payload.version
    });
  }
  function normalizePEM(value) {
    value = String(value || "").trim().replace(/\\n/g, "\n").replace(/\r/g, "");
    var lines = value.split("\n"), head = lines.shift(), foot = lines.pop(), body = lines.join("").replace(/\s+/g, "");
    return head + "\n" + (body.match(/.{1,64}/g) || []).join("\n") + "\n" + foot + "\n";
  }
  function signatureBuffer(value) {
    var BufferCtor;
    try { BufferCtor = window.require("buffer").Buffer; } catch (_) { BufferCtor = Buffer; }
    var base64 = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
    while (base64.length % 4) base64 += "=";
    return BufferCtor.from(base64, "base64");
  }
  function verifyReceipt(receipt) {
    try {
      if (!receipt || !receipt.payload || !receipt.signature || !publicKey) return false;
      if (receipt.algorithm !== "ES256" || Number(receipt.payload.version) !== 1) return false;
      if (receipt.payload.productId !== PRODUCT || String(receipt.payload.deviceHash).toLowerCase() !== String(state.deviceHash).toLowerCase()) return false;
      if (Date.parse(receipt.payload.validUntil) <= Date.now() || Date.parse(receipt.payload.offlineUntil) <= Date.now()) return false;
      var crypto = nodeCrypto();
      if (!crypto) return false;
      var BufferCtor = window.require("buffer").Buffer;
      return Boolean(crypto.verify("sha256", BufferCtor.from(canonical(receipt.payload), "utf8"), { key: normalizePEM(publicKey), dsaEncoding: "ieee-p1363" }, signatureBuffer(receipt.signature)));
    } catch (_) { return false; }
  }
  function saveReceipt(receipt) {
    state.receipt = receipt;
    state.valid = verifyReceipt(receipt);
    if (state.valid) { localStorage.setItem(RECEIPT_KEY, JSON.stringify(receipt)); state.error = ""; }
    render();
    return state.valid;
  }
  function storedReceipt() { try { return JSON.parse(localStorage.getItem(RECEIPT_KEY) || "null"); } catch (_) { return null; } }
  function deviceLabel() { return (navigator.platform || "Desktop") + " • " + state.deviceHash.slice(-8).toUpperCase(); }
  function render() {
    var p = state.receipt && state.receipt.payload;
    document.body.classList.toggle("license-active", state.valid);
    var title = document.getElementById("licenseTitle"); if (!title) return;
    title.textContent = state.valid ? "Ultra etkin ve doğrulandı." : "Ultra’yı etkinleştir.";
    document.getElementById("licenseDescription").textContent = state.valid ? "Bu cihaz ES256 imzalı lisans makbuzu ile korunuyor." : (state.error || "Lisans anahtarın bu cihaz için güvenli şekilde doğrulanır. Anahtar panelde düz metin olarak saklanmaz.");
    var badge = document.getElementById("licenseBadge"); badge.textContent = state.valid ? "AKTİF" : "PASİF"; badge.classList.toggle("active", state.valid);
    document.getElementById("licenseDevice").textContent = state.deviceHash ? deviceLabel() : "Hazırlanıyor…";
    document.getElementById("licensePlan").textContent = p ? String(p.plan || "—").toUpperCase() : "—";
    document.getElementById("licenseOffline").textContent = p ? new Date(p.offlineUntil).toLocaleDateString("tr-TR") : "—";
    var managementTitle = document.getElementById("licenseManagementTitle");
    if (managementTitle) managementTitle.textContent = state.valid ? "Bu cihaz kurumsal olarak etkin" : "Aktivasyon bekleniyor";
  }
  function payload(key) {
    return { licenseKey: key || "", productId: PRODUCT, deviceHash: state.deviceHash, deviceName: deviceLabel(), platform: navigator.platform || "Desktop", appVersion: VERSION, osVersion: navigator.userAgent.slice(0, 80) };
  }
  function activate(key) {
    state.error = ""; render();
    return request("/activate", payload(String(key || "").trim())).then(function (result) {
      if (!saveReceipt(result.receipt)) throw new Error("Sunucu makbuzu doğrulanamadı.");
      return result;
    }).catch(function (error) { state.valid = false; state.error = error.message; render(); throw error; });
  }
  function validate() {
    var receipt = state.receipt || storedReceipt();
    if (!receipt || !receipt.payload) return Promise.reject(new Error("Önce lisansı etkinleştir."));
    if (String(receipt.payload.activationId).indexOf("trial:") === 0) return request("/trial", { deviceHash: state.deviceHash }).then(function (result) { if (!saveReceipt(result.receipt)) throw new Error("Deneme makbuzu doğrulanamadı."); return result; });
    return request("/validate", { activationId: receipt.payload.activationId, productId: PRODUCT, deviceHash: state.deviceHash }).then(function (result) {
      if (!saveReceipt(result.receipt)) throw new Error("Yenilenen makbuz doğrulanamadı.");
      return result;
    }).catch(function (error) {
      state.error = error.message;
      state.valid = verifyReceipt(receipt);
      render();
      if (!state.valid) throw error;
      return { ok: true, offline: true };
    });
  }
  function deactivate(key) {
    var receipt = state.receipt || storedReceipt();
    if (!receipt || !receipt.payload) return Promise.reject(new Error("Aktif cihaz lisansı bulunamadı."));
    if (String(receipt.payload.activationId).indexOf("trial:") === 0) { localStorage.removeItem(RECEIPT_KEY); state.valid = false; state.receipt = null; render(); return Promise.resolve(); }
    return request("/deactivate", { activationId: receipt.payload.activationId, deviceHash: state.deviceHash, licenseKey: String(key || "").trim() }).then(function () {
      localStorage.removeItem(RECEIPT_KEY); state.valid = false; state.receipt = null; state.error = ""; render();
    });
  }
  function init() {
    return deviceHash().then(function () { return request("https://dromocob.tr/api/licenses/apps", null, "GET", "", true); }).then(function (config) {
      if (config.receiptPublicKey && normalizePEM(config.receiptPublicKey) !== normalizePEM(publicKey)) throw new Error("Lisans sunucusu imza anahtarı eşleşmiyor.");
      state.receipt = storedReceipt(); state.valid = verifyReceipt(state.receipt); render();
    }).catch(function (error) { state.error = error.message; state.receipt = storedReceipt(); state.valid = verifyReceipt(state.receipt); render(); });
  }

  window.DromocobLicense = {
    init: init, activate: activate, validate: validate, deactivate: deactivate,
    startTrial: function () { return request("/trial", { deviceHash: state.deviceHash }).then(function (result) { if (!saveReceipt(result.receipt)) throw new Error("Deneme makbuzu doğrulanamadı."); return result; }); },
    canUse: function () { return state.valid; }, state: function () { return state; }
  };
})();
