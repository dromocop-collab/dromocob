(function () {
  "use strict";

  var toastTimer;

  var quickActions = [
    ["↗", "YAKINLAŞ", "Dinamik yaklaşma", "zoomIn"],
    ["↙", "UZAKLAŞ", "Akıcı uzaklaşma", "zoomOut"],
    ["◆", "ÜRÜN VURGUSU", "Ürün giriş hareketi", "productPop"],
    ["◌", "YUMUŞAK GİRİŞ", "Yumuşak görünme", "fadeIn"],
    ["⌁", "AKICI EĞRİ", "Seçili anahtar kare", "easyEase"],
    ["◫", "HAREKET BULANIKLIĞI", "Hareket bulanıklığı", "motionBlur"],
    ["↻", "DÖNÜŞLÜ GİRİŞ", "Lüks dönüş girişi", "rotateReveal"],
    ["→", "SAĞA SAVUR", "Hızlı geçiş", "whipRight"]
  ];

  var effects = [
    ["✦", "PARLAMA", "Işık ve neon", "ADBE Glo2"],
    ["◉", "GAUSS BULANIKLIĞI", "Yumuşak bulanıklık", "ADBE Gaussian Blur 2"],
    ["◩", "ALT GÖLGE", "Derinlik gölgesi", "ADBE Drop Shadow"],
    ["⌁", "KESKİNLEŞTİR", "Keskin detay", "ADBE Sharpen"],
    ["◐", "RENKLENDİR", "İki renk tonlama", "ADBE Tint"],
    ["∴", "GÜRÜLTÜ", "Organik doku", "ADBE Noise"],
    ["≈", "TÜRBÜLANS", "Dalgalı deformasyon", "ADBE Turbulent Displace"],
    ["◒", "LUMETRI RENK", "Renk düzenleme", "ADBE Lumetri"],
    ["↗", "YÖNLÜ BULANIKLIK", "Hız çizgisi", "ADBE Motion Blur"],
    ["◎", "RADYAL BULANIKLIK", "Dairesel enerji", "ADBE Radial Blur"],
    ["▤", "ÇİZGİSEL PERDE", "Çizgisel açılma", "ADBE Venetian Blinds"],
    ["⌗", "MOZAİK", "Piksel blokları", "ADBE Mosaic"],
    ["△", "POZLAMA", "Işık kontrolü", "ADBE Exposure2"],
    ["◨", "EĞRİLER", "Profesyonel kontrast", "ADBE CurvesCustom"],
    ["⊹", "ALFA KABARTMA", "Parlak kenarlar", "ADBE Bevel Alpha"],
    ["〰", "DALGA BÜKÜLMESİ", "Akış deformasyonu", "ADBE Wave Warp"]
  ];

  var fxStacks = [
    ["✧", "NEON NABIZ", "Parlama + keskinlik + renk", "neonPulse"],
    ["☁", "RÜYA IŞIĞI", "Yumuşak bulanıklık + parlama", "dreamBloom"],
    ["⌁", "VHS HASARI", "Gürültü + dalga + renk ayrımı", "vhsDamage"],
    ["↯", "HIZ BULANIKLIĞI", "Yönlü hareket enerjisi", "speedBlur"],
    ["◉", "SİNEMA DARBESİ", "Kontrast + vinyet karakteri", "cinemaPunch"],
    ["◇", "NET DETAY", "Keskinlik + mikro kontrast", "crispDetail"],
    ["◐", "ÇİFT TON MAVİ", "Dromocob mavi tonlama", "duotoneBlue"],
    ["※", "DİJİTAL DOKU", "Gürültü + posterize doku", "digitalGrit"],
    ["☼", "ALTIN SAAT", "Sıcak parlama + pozlama", "goldenHour"],
    ["❄", "KUTUP IŞIĞI", "Soğuk ışık + netlik", "arcticGlow"],
    ["◫", "YUMUŞAK PORTRE", "Ten dostu yumuşatma", "softPortrait"],
    ["◈", "SİBER KENAR", "Neon kenar + doku", "cyberEdge"],
    ["▤", "TARAMA ÇİZGİSİ PRO", "Dijital tarama dokusu", "scanlinePro"],
    ["◉", "VİNYET ODAK", "Merkez odak karakteri", "vignetteFocus"],
    ["⚡", "DARBE ENERJİSİ", "Parlama + keskinlik + pozlama", "impactEnergy"],
    ["◇", "FİLM YUMUŞAKLIĞI", "Organik sinema yumuşaklığı", "filmSoftness"]
  ];

  var glowPresets = [
    ["☼", "YUMUŞAK IŞIK", "Yumuşak sinema ışığı", [68, 95, 95, 38, "#ffd6ad"]],
    ["✦", "NEON MAVİ", "Keskin Dromocob neon", [35, 58, 190, 70, "#17c8ff"]],
    ["◉", "RÜYA HALESİ", "Geniş rüya halesi", [52, 145, 125, 66, "#8ecbff"]],
    ["⚡", "ENERJİ ÇEKİRDEĞİ", "Yoğun merkez enerjisi", [70, 38, 240, 48, "#f4fbff"]],
    ["☄", "ATEŞ KENARI", "Sıcak turuncu kenar", [42, 82, 175, 60, "#ff6b18"]],
    ["◇", "KROM PARLAMA", "Metalik vurgu", [78, 34, 155, 28, "#d7efff"]],
    ["♢", "MOR AURA", "Mor atmosfer", [46, 120, 145, 62, "#9b63ff"]],
    ["◎", "LAZER NABZI", "Animasyonlu güçlü nabız", [60, 55, 220, 80, "#24ffe2"]]
  ];

  var energyTransitions = [
    ["ATEŞLİ SİLME", "Alevli yerleşik silme", "fire", "fireWipe"],
    ["FİLM YANIĞI", "Sıcak analog ışık", "burn", "filmBurn"],
    ["FLAŞ KESİM", "Beyaz enerji kesmesi", "flash", "flashCut"],
    ["MAVİ ENERJİ", "Dromocob ışık patlaması", "flash", "blueEnergy"]
  ];

  var motionTransitions = [
    ["SAĞA DÖNÜŞ", "Saat yönü dönüş", "spin", "spinCW"],
    ["SOLA DÖNÜŞ", "Ters yön dönüş", "spin", "spinCCW"],
    ["HIZLI YAKINLAŞMA", "Agresif lens yaklaşma", "zoom", "zoomBurst"],
    ["SOLA SAVUR", "Sola hızlı geçiş", "whip", "whipLeft"],
    ["SAĞA SAVUR", "Sağa hızlı geçiş", "whip", "whipRight"],
    ["YUKARI SAVUR", "Yukarı hızlı geçiş", "whip", "whipUp"],
    ["AŞAĞI SAVUR", "Aşağı hızlı geçiş", "whip", "whipDown"],
    ["ESNEK DÖNÜŞ", "Taşmalı dönüş", "spin", "elasticSpin"]
  ];

  var digitalTransitions = [
    ["GLITCH KESİM", "RGB dijital kırılma", "glitch", "glitchCut"],
    ["DARBE VURGUSU", "Sert ölçek vuruşu", "impact", "impactPunch"],
    ["MİKRO SARSINTI", "Kısa kamera darbesi", "impact", "microShake"],
    ["RGB FLAŞ", "Renk kanalı parlaması", "glitch", "rgbFlash"]
  ];

  var shakes = [
    ["⌁", "HAFİF", "2 / 8 / 0.3", [2, 8, .3]],
    ["≈", "EL KAMERASI", "4 / 24 / 1.2", [4, 24, 1.2]],
    ["✦", "DARBE", "9 / 65 / 2.5", [9, 65, 2.5]],
    ["※", "KAOS", "14 / 110 / 4", [14, 110, 4]]
  ];

  var formats = [
    ["▯", "REEL 9:16", "1080 × 1920", [1080, 1920, 25]],
    ["▥", "GÖNDERİ 4:5", "1080 × 1350", [1080, 1350, 25]],
    ["□", "KARE 1:1", "1080 × 1080", [1080, 1080, 25]],
    ["▭", "YOUTUBE 16:9", "1920 × 1080", [1920, 1080, 25]]
  ];

  var textTools = [
    ["◌", "YUMUŞAK GİRİŞ", "Yumuşak giriş", "fadeIn"],
    ["◆", "CANLI GİRİŞ", "Dinamik vurgu", "productPop"],
    ["↻", "DÖNÜŞLÜ GİRİŞ", "Dönüşlü giriş", "rotateReveal"],
    ["↗", "YAKINLAŞ", "Yaklaşan tipografi", "zoomIn"]
  ];

  var text3DPresets = [
    ["KROM DERİNLİK", "Metal 3D derinlik", "chrome", "chromeExtrude"],
    ["NEON 3D", "Parlak mavi neon", "neon", "neon3D"],
    ["GÖLGE YIĞINI", "Katmanlı uzun gölge", "shadow", "shadowStack"],
    ["SİNEMA KABARTMASI", "Kabartma ve dramatik gölge", "chrome", "cinemaBevel"],
    ["KİNETİK VURGU", "Canlı ölçek animasyonu", "kinetic", "kineticPop"],
    ["3D DÖNÜŞ", "Y ekseninde sinematik dönüş", "kinetic", "spin3D"],
    ["HOLOGRAM", "Dijital ışık karakteri", "neon", "hologram"],
    ["BLOK DERİNLİĞİ", "Güçlü kalın derinlik", "shadow", "blockDepth"]
  ];

  function toast(message, isError) {
    var element = document.getElementById("toast");
    clearTimeout(toastTimer);
    element.textContent = message;
    element.className = "toast show" + (isError ? " error" : "");
    toastTimer = setTimeout(function () { element.className = "toast"; }, 2600);
  }

  function contextPayload(extra) {
    var payload = {
      durationFrames: Number(document.getElementById("duration").value) || 8,
      intensity: Number(document.getElementById("intensity").value) || 30
    };
    Object.keys(extra || {}).forEach(function (key) { payload[key] = extra[key]; });
    return payload;
  }

  function hostCall(method, payload, quiet) {
    if (method !== "context" && window.DromocobLicense && !DromocobLicense.canUse()) {
      document.querySelector('[data-page="license"]').click();
      toast("Bu araç için Dromocob Ultra lisansını etkinleştir.", true);
      return Promise.resolve({ ok: false, message: "Lisans gerekli." });
    }
    return DromocobBridge.call(method, contextPayload(payload)).then(function (result) {
      if (!quiet) toast(result.message || (result.ok ? "İşlem tamamlandı." : "İşlem uygulanamadı."), !result.ok);
      return result;
    });
  }

  function cardMarkup(item) {
    return '<b>' + item[0] + '</b><strong>' + item[1] + '</strong><small>' + item[2] + '</small>';
  }

  function renderActionGrid(id, items, handler) {
    var grid = document.getElementById(id);
    grid.innerHTML = "";
    items.forEach(function (item) {
      var button = document.createElement("button");
      button.className = "action-card";
      button.innerHTML = cardMarkup(item);
      button.addEventListener("click", function () { handler(item); });
      grid.appendChild(button);
    });
  }

  function renderTransitionGrid(id, items) {
    var grid = document.getElementById(id);
    grid.innerHTML = "";
    items.forEach(function (item) {
      var button = document.createElement("button");
      button.className = "transition-card";
      button.setAttribute("data-style", item[2]);
      button.innerHTML = '<div class="transition-preview"></div><div class="transition-info"><strong>' + item[0] + '</strong><small>' + item[1] + '</small></div>';
      button.addEventListener("click", function () { hostCall("transition", { type: item[3] }); });
      grid.appendChild(button);
    });
  }

  function renderTools() {
    renderActionGrid("quickActions", quickActions, function (item) { hostCall(item[3]); });
    renderTransitionGrid("energyTransitions", energyTransitions);
    renderTransitionGrid("motionTransitions", motionTransitions);
    renderTransitionGrid("digitalTransitions", digitalTransitions);
    renderActionGrid("fxStackGrid", fxStacks, function (item) { hostCall("effectStack", { type: item[3], displayName: item[1] }); });
    renderActionGrid("effectGrid", effects, function (item) { hostCall("addEffect", { matchName: item[3], displayName: item[1] }); });
    renderActionGrid("glowPresetGrid", glowPresets, function (item) {
      setGlowControls(item[3]); hostCall("glowLab", glowPayload(item[1], item[1] === "LASER PULSE"));
    });
    renderActionGrid("shakePresets", shakes, function (item) {
      hostCall("shake", { frequency: item[3][0], amount: item[3][1], rotation: item[3][2] });
    });
    renderActionGrid("formatGrid", formats, function (item) {
      hostCall("createComp", { name: "DROMOCOB_" + item[1].replace(/\s+/g, "_"), width: item[3][0], height: item[3][1], fps: item[3][2] });
    });
    renderActionGrid("textGrid", textTools, function (item) { hostCall(item[3]); });
    var textPresetGrid = document.getElementById("text3DGrid");
    textPresetGrid.innerHTML = "";
    text3DPresets.forEach(function (item) {
      var button = document.createElement("button");
      button.className = "text-preset";
      button.setAttribute("data-style", item[2]);
      button.innerHTML = '<div class="type-demo">Aa</div><strong>' + item[0] + '</strong><small>' + item[1] + '</small>';
      button.addEventListener("click", function () { createAdvancedText(false, item[3]); });
      textPresetGrid.appendChild(button);
    });
  }

  function textPayload(update, style) {
    return {
      text: document.getElementById("textContent").value || "DROMOCOB",
      size: Number(document.getElementById("textSize").value) || 120,
      tracking: Number(document.getElementById("textTracking").value) || 0,
      font: document.getElementById("textFont").value,
      align: document.getElementById("textAlign").value,
      leading: Number(document.getElementById("textLeading").value) || 0,
      strokeWidth: Number(document.getElementById("textStroke").value) || 0,
      allCaps: document.getElementById("textAllCaps").checked,
      fauxBold: document.getElementById("textBold").checked,
      color: document.getElementById("textColor").value,
      depth: Number(document.getElementById("textDepth").value) || 0,
      threeD: document.getElementById("text3D").checked,
      update: Boolean(update),
      style: style || "clean3D"
    };
  }

  function createAdvancedText(update, style) {
    hostCall("textStudio", textPayload(update, style));
  }

  function updateTextPreview() {
    var preview = document.getElementById("textPreview");
    var content = document.getElementById("textContent").value || "DROMOCOB";
    var size = Number(document.getElementById("textSize").value) || 120;
    var tracking = Number(document.getElementById("textTracking").value) || 0;
    var color = document.getElementById("textColor").value;
    var depth = Number(document.getElementById("textDepth").value) || 0;
    preview.textContent = document.getElementById("textAllCaps").checked ? content.toUpperCase() : content;
    preview.style.fontSize = Math.max(20, Math.min(70, size * .42)) + "px";
    preview.style.letterSpacing = Math.max(-2, Math.min(15, tracking / 18)) + "px";
    preview.style.color = color;
    preview.style.fontFamily = document.getElementById("textFont").options[document.getElementById("textFont").selectedIndex].text + ", sans-serif";
    preview.style.textAlign = document.getElementById("textAlign").value;
    var shadows = [];
    for (var i = 1; i <= Math.max(1, Math.min(8, depth)); i++) shadows.push(i + "px " + i + "px 0 rgba(4,62,108," + (.95 - i * .07) + ")");
    shadows.push("0 0 28px rgba(17,140,255,.3)");
    preview.style.textShadow = shadows.join(",");
    document.getElementById("textDepthValue").value = depth;
  }

  function glowPayload(name, forceAnimate) {
    return {
      name: name || "ÖZEL PARLAMA", color: document.getElementById("glowColor").value,
      threshold: Number(document.getElementById("glowThreshold").value), radius: Number(document.getElementById("glowRadius").value),
      power: Number(document.getElementById("glowPower").value) / 100, secondary: Number(document.getElementById("glowSecondary").value),
      mode: document.getElementById("glowMode").value, animate: Boolean(forceAnimate || document.getElementById("glowAnimate").checked)
    };
  }

  function setGlowControls(values) {
    ["glowThreshold", "glowRadius", "glowPower", "glowSecondary"].forEach(function (id, index) { document.getElementById(id).value = values[index]; });
    document.getElementById("glowColor").value = values[4]; updateGlowPreview();
  }

  function updateGlowPreview() {
    var color = document.getElementById("glowColor").value;
    var radius = Number(document.getElementById("glowRadius").value);
    var power = Number(document.getElementById("glowPower").value) / 100;
    var orb = document.getElementById("glowPreview");
    orb.style.setProperty("--glow-color", color);
    orb.style.setProperty("--glow-radius", Math.round(radius / 4) + "px");
    orb.style.setProperty("--glow-power", Math.min(1, power / 2));
    document.querySelectorAll(".range-row").forEach(function (row) {
      var input = row.querySelector("input"), output = row.querySelector("output");
      if (input.id === "glowPower") output.value = (Number(input.value) / 100).toFixed(2);
      else if (input.id === "glowSecondary") output.value = input.value + "%";
      else output.value = input.value;
    });
  }

  function timecode(seconds, fps) {
    var totalFrames = Math.max(0, Math.round((seconds || 0) * (fps || 25)));
    var frames = totalFrames % Math.round(fps || 25);
    var totalSeconds = Math.floor(totalFrames / (fps || 25));
    var secs = totalSeconds % 60;
    var mins = Math.floor(totalSeconds / 60) % 60;
    var hours = Math.floor(totalSeconds / 3600);
    function pad(value) { return value < 10 ? "0" + value : String(value); }
    return pad(hours) + ":" + pad(mins) + ":" + pad(secs) + ":" + pad(frames);
  }

  function initNavigation() {
    document.querySelectorAll(".nav-item").forEach(function (button) {
      button.addEventListener("click", function () {
        document.querySelectorAll(".nav-item").forEach(function (item) { item.classList.remove("active"); });
        document.querySelectorAll(".page").forEach(function (page) { page.classList.remove("active"); });
        button.classList.add("active");
        var page = document.getElementById(button.dataset.page);
        page.classList.add("active");
        document.getElementById("pageTitle").textContent = page.dataset.title;
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        button.blur();
      });
    });
  }

  function initGlobalActions() {
    document.getElementById("intensity").addEventListener("input", function (event) {
      document.getElementById("intensityValue").value = event.target.value;
    });
    document.getElementById("duration").addEventListener("input", function (event) {
      document.getElementById("transitionDurationLabel").textContent = (Number(event.target.value) || 8) + " KARE";
    });

    document.addEventListener("click", function (event) {
      var button = event.target.closest("[data-action]");
      if (button) hostCall(button.dataset.action);
    });

    document.getElementById("applyShake").addEventListener("click", function () {
      hostCall("shake", {
        frequency: Number(document.getElementById("shakeFrequency").value) || 4,
        amount: Number(document.getElementById("shakeAmount").value) || 25,
        rotation: Number(document.getElementById("shakeRotation").value) || 0
      });
    });

    document.getElementById("applyCurve").addEventListener("click", function () {
      hostCall("applyCurve", { curve: CurveStudio.getValue() });
    });
    document.getElementById("curveReset").addEventListener("click", CurveStudio.reset);
    document.getElementById("copyCurve").addEventListener("click", function () {
      var text = CurveStudio.getValue().map(function (value) { return value.toFixed(2); }).join(", ");
      var helper = document.createElement("textarea");
      helper.value = text; document.body.appendChild(helper); helper.select(); document.execCommand("copy"); helper.remove();
      toast("Eğri değeri kopyalandı.");
    });
    document.getElementById("pasteCurve").addEventListener("click", function () {
      var pasted = window.prompt("Dört hareket eğrisi değeri:", document.getElementById("bezierCode").textContent);
      if (!pasted) return;
      var parsed = pasted.split(/[ ,]+/).filter(Boolean).map(Number);
      if (!CurveStudio.setValue(parsed)) toast("Eğri formatı geçersiz.", true);
    });
    document.getElementById("saveCurve").addEventListener("click", function () {
      var name = window.prompt("Hazır ayar adı:", "Benim Eğrim");
      if (name && CurveStudio.addPreset(name)) toast("Eğri hazır ayarlara kaydedildi.");
    });

    document.getElementById("refreshContext").addEventListener("click", updateContext);

    ["textContent", "textSize", "textTracking", "textColor", "textDepth", "textFont", "textAlign", "textLeading", "textStroke", "textAllCaps", "textBold"].forEach(function (id) {
      document.getElementById(id).addEventListener("input", updateTextPreview);
    });
    document.getElementById("createText").addEventListener("click", function () { createAdvancedText(false, "clean3D"); });
    document.getElementById("updateText").addEventListener("click", function () { createAdvancedText(true, "clean3D"); });
    ["glowColor", "glowThreshold", "glowRadius", "glowPower", "glowSecondary"].forEach(function (id) { document.getElementById(id).addEventListener("input", updateGlowPreview); });
    document.getElementById("applyGlow").addEventListener("click", function () { hostCall("glowLab", glowPayload("ÖZEL PARLAMA")); });
    document.getElementById("removeGlow").addEventListener("click", function () { hostCall("removeDromocobGlow"); });
    document.getElementById("activateLicense").addEventListener("click", function () {
      var key = document.getElementById("licenseKey").value;
      DromocobLicense.activate(key).then(function () { document.getElementById("licenseKey").value = ""; toast("Dromocob Ultra etkinleştirildi."); }).catch(function (error) { toast(error.message, true); });
    });
    document.getElementById("startTrial").addEventListener("click", function () { DromocobLicense.startTrial().then(function () { toast("Dromocob Ultra deneme sürümü başladı."); }).catch(function (error) { toast(error.message, true); }); });
    document.getElementById("validateLicense").addEventListener("click", function () { DromocobLicense.validate().then(function () { toast("Lisans doğrulandı."); }).catch(function (error) { toast(error.message, true); }); });
    document.getElementById("deactivateLicense").addEventListener("click", function () {
      var key = document.getElementById("licenseKey").value;
      DromocobLicense.deactivate(key).then(function () { document.getElementById("licenseKey").value = ""; toast("Bu cihaz lisansından kaldırıldı."); }).catch(function (error) { toast(error.message, true); });
    });
  }

  function updateContext() {
    hostCall("context", {}, true).then(function (result) {
      var aeStatus = document.getElementById("aeStatus");
      var compStatus = document.getElementById("compStatus");
      if (result.ok) {
        aeStatus.textContent = "AE BAĞLANDI";
        compStatus.textContent = result.compName ? result.compName + " • " + result.selectedLayers + " katman" : "Aktif kompozisyon yok";
        document.getElementById("hudCompName").textContent = result.compName || "KOMPOZİSYON YOK";
        document.getElementById("hudSize").textContent = result.compName ? result.width + "×" + result.height : "—";
        document.getElementById("hudFps").textContent = result.compName ? Math.round(result.fps * 100) / 100 : "—";
        document.getElementById("hudDuration").textContent = result.compName ? Math.round(result.duration * 10) / 10 + "s" : "—";
        document.getElementById("hudSelection").textContent = result.selectedLayers || 0;
        document.getElementById("hudFrames").textContent = result.compName ? result.totalFrames : "—";
        document.getElementById("hudWorkArea").textContent = result.compName ? Math.round(result.workAreaDuration * 10) / 10 + "s" : "—";
        document.getElementById("hudRenderer").textContent = result.renderer || "—";
        document.getElementById("hudMb").textContent = result.compName ? (result.motionBlur ? "HB AÇIK" : "HB KAPALI") : "HB —";
        document.getElementById("hudProgress").style.width = result.duration ? Math.min(100, result.time / result.duration * 100) + "%" : "0%";
        document.getElementById("hudTime").textContent = timecode(result.time, result.fps);
        document.getElementById("diagnosticTitle").textContent = result.compName || "Kompozisyon bekleniyor";
        document.getElementById("diagnosticText").textContent = result.compName ? result.width + " × " + result.height + " • " + (Math.round(result.fps * 100) / 100) + " fps • " + result.renderer + " • " + result.selectedLayers + " katman seçili" : "Aktif kompozisyon açıldığında canlı proje bilgileri burada görünür.";
      } else {
        aeStatus.textContent = result.offline ? "ÖNİZLEME MODU" : "AE HAZIR DEĞİL";
        compStatus.textContent = result.message || "Bağlantı kurulamadı";
      }
    });
  }

  function initSettings() {
    var accents = {
      blue: ["#118cff", "#15c8ff"],
      cyan: ["#00aeb8", "#35f4e8"],
      violet: ["#7652ff", "#b68cff"],
      orange: ["#f05b21", "#ffb13b"]
    };
    var savedAccent = localStorage.getItem("dromocob.accent") || "blue";
    function applyAccent(name) {
      var colors = accents[name] || accents.blue;
      document.documentElement.style.setProperty("--blue", colors[0]);
      document.documentElement.style.setProperty("--cyan", colors[1]);
      document.querySelectorAll("#accentPicker button").forEach(function (button) { button.classList.toggle("active", button.dataset.accent === name); });
      localStorage.setItem("dromocob.accent", name);
    }
    document.querySelectorAll("#accentPicker button").forEach(function (button) { button.addEventListener("click", function () { applyAccent(button.dataset.accent); }); });
    applyAccent(savedAccent);

    var motion = document.getElementById("motionSetting");
    var compact = document.getElementById("compactSetting");
    motion.checked = localStorage.getItem("dromocob.motion") !== "off";
    compact.checked = localStorage.getItem("dromocob.compact") === "on";
    document.body.classList.toggle("reduce-motion", !motion.checked);
    document.body.classList.toggle("compact-mode", compact.checked);
    motion.addEventListener("change", function () { document.body.classList.toggle("reduce-motion", !motion.checked); localStorage.setItem("dromocob.motion", motion.checked ? "on" : "off"); });
    compact.addEventListener("change", function () { document.body.classList.toggle("compact-mode", compact.checked); localStorage.setItem("dromocob.compact", compact.checked ? "on" : "off"); });

    var defaultDuration = Number(localStorage.getItem("dromocob.defaultDuration")) || 8;
    var defaultIntensity = Number(localStorage.getItem("dromocob.defaultIntensity")) || 30;
    document.getElementById("duration").value = defaultDuration;
    document.getElementById("intensity").value = defaultIntensity;
    document.getElementById("intensityValue").value = defaultIntensity;
    document.getElementById("defaultDuration").value = defaultDuration;
    document.getElementById("defaultIntensity").value = defaultIntensity;
    document.getElementById("defaultDuration").addEventListener("change", function (event) { localStorage.setItem("dromocob.defaultDuration", event.target.value); document.getElementById("duration").value = event.target.value; });
    document.getElementById("defaultIntensity").addEventListener("change", function (event) { localStorage.setItem("dromocob.defaultIntensity", event.target.value); document.getElementById("intensity").value = event.target.value; document.getElementById("intensityValue").value = event.target.value; });
    document.getElementById("resetSettings").addEventListener("click", function () {
      ["dromocob.accent", "dromocob.motion", "dromocob.compact", "dromocob.defaultDuration", "dromocob.defaultIntensity"].forEach(function (key) { localStorage.removeItem(key); });
      applyAccent("blue"); motion.checked = true; compact.checked = false;
      document.body.classList.remove("reduce-motion", "compact-mode");
      toast("Arayüz ayarları sıfırlandı.");
    });
  }

  function applyLut(path) {
    hostCall("applyLut", {
      path: path,
      adjustment: document.getElementById("lutAdjustment").checked,
      strength: Number(document.getElementById("lutStrength").value) || 100
    });
  }

  function init() {
    renderTools();
    initNavigation();
    CurveStudio.init();
    initGlobalActions();
    initSettings();
    updateTextPreview();
    updateGlowPreview();
    window.DromocobApp = { toast: toast, applyLut: applyLut };
    LutStudio.init();
    if (window.CarouselLab) CarouselLab.init();
    updateContext();
    if (window.DromocobLicense) DromocobLicense.init();
    if (window.DromocobPacks) DromocobPacks.init();
    setInterval(updateContext, 6000);
  }

  window.DromocobApp = { toast: toast, applyLut: applyLut };
  document.addEventListener("DOMContentLoaded", init);
})();
