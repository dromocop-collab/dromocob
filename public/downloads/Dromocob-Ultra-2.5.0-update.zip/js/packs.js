(function () {
  "use strict";
  var VERSION = "2.5.0", PRODUCT = "dromocob-ultra-ae", config = {}, audioItems = [];
  function node(name) { try { return window.require ? window.require(name) : null; } catch (_) { return null; } }
  function getJSON(url) { return new Promise(function (resolve, reject) { var x = new XMLHttpRequest(); x.open("GET", url, true); x.timeout = 15000; x.onreadystatechange = function () { if (x.readyState === 4) { try { var d = JSON.parse(x.responseText); if (x.status >= 200 && x.status < 300 && d.ok) resolve(d); else reject(new Error(d.error || "Katalog alınamadı.")); } catch (_) { reject(new Error("Katalog yanıtı geçersiz.")); } } }; x.onerror = function () { reject(new Error("Dromocob Cloud bağlantısı kurulamadı.")); }; x.send(); }); }
  function semver(value) { return String(value || "0").split(".").map(function (x) { return Number(x) || 0; }); }
  function newer(a, b) { var x = semver(a), y = semver(b); for (var i = 0; i < 3; i++) { if (x[i] !== y[i]) return x[i] > y[i]; } return false; }
  function packRoot() { var os = node("os"), path = node("path"); return os && path ? path.join(os.homedir(), "Library", "Application Support", "Dromocob Ultra", "packs") : ""; }
  function installed(id) { var fs = node("fs"), path = node("path"), root = packRoot(); return Boolean(fs && root && fs.existsSync(path.join(root, id, "pack.json"))); }
  function download(url, destination) { return new Promise(function (resolve, reject) { var https = node("https"), fs = node("fs"); if (!https || !fs || !/^https:\/\//i.test(url)) return reject(new Error("Yalnızca güvenli HTTPS paketleri kurulabilir.")); var file = fs.createWriteStream(destination); function load(target, redirects) { https.get(target, function (res) { if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects < 4) { file.close(); fs.unlinkSync(destination); file = fs.createWriteStream(destination); load(new URL(res.headers.location, target).toString(), redirects + 1); return; } if (res.statusCode !== 200) return reject(new Error("Paket indirilemedi: HTTP " + res.statusCode)); res.pipe(file); file.on("finish", function () { file.close(); resolve(destination); }); }).on("error", reject); } load(url, 0); }); }
  function hashFile(file) { var fs = node("fs"), crypto = node("crypto"); return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex"); }
  function installPack(pack) {
    if (!window.DromocobLicense || !DromocobLicense.canUse()) return Promise.reject(new Error("Paket kurmak için aktif lisans veya deneme gerekli."));
    var fs = node("fs"), path = node("path"), os = node("os"), cp = node("child_process");
    if (!fs || !path || !os || !cp) return Promise.reject(new Error("CEP paket motoru kullanılamıyor."));
    var temp = path.join(os.tmpdir(), "dromocob-" + Date.now() + ".zip"), root = packRoot(), target = path.join(root, String(pack.id).replace(/[^a-z0-9_-]/gi, ""));
    fs.mkdirSync(root, { recursive: true });
    return download(pack.url, temp).then(function () {
      if (!pack.sha256 || hashFile(temp).toLowerCase() !== String(pack.sha256).toLowerCase()) throw new Error("Paket bütünlük doğrulaması başarısız.");
      var list = cp.execFileSync("/usr/bin/unzip", ["-Z1", temp], { encoding: "utf8" }).split(/\r?\n/).filter(Boolean);
      if (list.some(function (name) { return name.indexOf("..") >= 0 || name.charAt(0) === "/"; })) throw new Error("Güvensiz paket yolu engellendi.");
      fs.rmSync(target, { recursive: true, force: true }); fs.mkdirSync(target, { recursive: true });
      cp.execFileSync("/usr/bin/unzip", ["-q", temp, "-d", target]); fs.unlinkSync(temp);
      if (!fs.existsSync(path.join(target, "pack.json"))) throw new Error("pack.json bulunamadı.");
      loadInstalledAudio(); renderPacks(); return pack;
    });
  }
  function installUpdate(update) {
    if (!window.DromocobLicense || !DromocobLicense.canUse()) return Promise.reject(new Error("Güncelleme için aktif lisans veya deneme gerekli."));
    var fs=node("fs"),path=node("path"),os=node("os"),cp=node("child_process"),root=DromocobBridge.extensionPath();
    if(!fs||!path||!os||!cp||!root) return Promise.reject(new Error("Güncelleme motoru kullanılamıyor."));
    var zip=path.join(os.tmpdir(),"dromocob-update-"+Date.now()+".zip"),stage=path.join(os.tmpdir(),"dromocob-stage-"+Date.now()),backup=root+".backup-"+VERSION;
    return download(update.url,zip).then(function(){
      if(!update.sha256||hashFile(zip).toLowerCase()!==String(update.sha256).toLowerCase()) throw new Error("Güncelleme imzası doğrulanamadı.");
      var list=cp.execFileSync("/usr/bin/unzip",["-Z1",zip],{encoding:"utf8"}).split(/\r?\n/).filter(Boolean);
      if(list.some(function(n){return n.indexOf("..")>=0||n.charAt(0)==="/";})) throw new Error("Güvensiz güncelleme paketi engellendi.");
      fs.mkdirSync(stage,{recursive:true});cp.execFileSync("/usr/bin/unzip",["-q",zip,"-d",stage]);
      if(!fs.existsSync(path.join(stage,"CSXS","manifest.xml"))||!fs.existsSync(path.join(stage,"index.html"))) throw new Error("Güncelleme paketi yapısı geçersiz.");
      fs.rmSync(backup,{recursive:true,force:true});fs.cpSync(root,backup,{recursive:true});fs.cpSync(stage,root,{recursive:true,force:true});
      fs.rmSync(stage,{recursive:true,force:true});fs.unlinkSync(zip);return update;
    });
  }
  function loadInstalledAudio() {
    var fs = node("fs"), path = node("path"), root = packRoot(); audioItems = [];
    if (!fs || !root || !fs.existsSync(root)) { renderAudio("all"); return; }
    fs.readdirSync(root).forEach(function (id) { try { var dir = path.join(root, id), manifest = JSON.parse(fs.readFileSync(path.join(dir, "pack.json"), "utf8")); (manifest.audio || []).forEach(function (item) { var full = path.resolve(dir, item.file); if (full.indexOf(path.resolve(dir)) === 0 && fs.existsSync(full)) audioItems.push({ name: item.name, category: item.category || "sfx", path: full, pack: manifest.name || id }); }); } catch (_) {} });
    renderAudio("all");
  }
  function renderAudio(filter) { var grid = document.getElementById("audioGrid"); if (!grid) return; var items = audioItems.filter(function (x) { return filter === "all" || x.category === filter; }); grid.innerHTML = items.length ? "" : '<div class="empty-state"><b>♫</b><strong>Henüz SFX paketi yok</strong><small>Paket Merkezi’nden bir ses paketi indir veya kendi dosyanı içe aktar</small></div>'; items.forEach(function (item) { var b = document.createElement("button"); b.className = "audio-card"; b.innerHTML = '<span>▶</span><div><strong>' + item.name + '</strong><small>' + item.category.toUpperCase() + ' • ' + item.pack + '</small></div><i>＋</i>'; b.onclick = function () { DromocobBridge.call("importAudio", { path: item.path }).then(function (r) { DromocobApp.toast(r.message, !r.ok); }); }; grid.appendChild(b); }); }
  function renderPacks() { var grid = document.getElementById("packGrid"), packs = config.ultraPacks || []; if (!packs.length) { grid.innerHTML = '<div class="empty-state"><b>⬡</b><strong>Yeni paketler yakında</strong><small>Katalog Dromocob web yönetiminden yayınlanır</small></div>'; return; } grid.innerHTML = ""; packs.forEach(function (p) { var card = document.createElement("article"); card.className = "pack-card"; card.innerHTML = '<div class="pack-art">' + (p.icon || "⬡") + '</div><div><span>' + (p.type || "PACK") + '</span><h3>' + p.name + '</h3><p>' + (p.description || "Dromocob Ultra genişleme paketi") + '</p><small>v' + (p.version || "1.0") + ' • ' + (p.size || "—") + '</small></div><button class="' + (installed(p.id) ? "installed" : "") + '">' + (installed(p.id) ? "KURULU" : "İNDİR") + '</button>'; var button = card.querySelector("button"); if (!installed(p.id)) button.onclick = function () { button.textContent = "İNDİRİLİYOR"; installPack(p).then(function () { DromocobApp.toast(p.name + " kuruldu."); }).catch(function (e) { button.textContent = "TEKRAR DENE"; DromocobApp.toast(e.message, true); }); }; grid.appendChild(card); }); }
  function check() { return getJSON("https://dromocob.tr/api/licenses/apps?product=" + PRODUCT).then(function (data) { config = data; var update = data.ultraUpdate || {}; var available = newer(update.version, VERSION); document.getElementById("updateTitle").textContent = available ? "Yeni sürüm " + update.version + " hazır" : "Sürüm " + VERSION + " • Güncel"; document.getElementById("updateMessage").textContent = available ? (update.changelog || "Yeni özellikler ve iyileştirmeler hazır.") : "En güncel Dromocob Ultra sürümünü kullanıyorsun."; var btn = document.getElementById("installUpdate"); btn.disabled = !available || !update.url || !update.sha256; btn.onclick = function () { btn.textContent="KURULUYOR";installUpdate(update).then(function(){btn.textContent="PANELİ YENİDEN AÇ";DromocobApp.toast("Güncelleme kuruldu. Paneli kapatıp yeniden aç.");}).catch(function(e){btn.textContent="TEKRAR DENE";DromocobApp.toast(e.message,true);}); }; renderPacks(); return data; }); }
  function init() { loadInstalledAudio(); document.getElementById("checkUpdates").onclick = function () { check().then(function () { DromocobApp.toast("Güncelleme kontrolü tamamlandı."); }).catch(function (e) { DromocobApp.toast(e.message, true); }); }; document.getElementById("importAudio").onclick = function () { DromocobBridge.openFile("Ses dosyası seç", ["wav", "aif", "aiff", "mp3", "m4a"]).then(function (path) { if (path) DromocobBridge.call("importAudio", { path: path }).then(function (r) { DromocobApp.toast(r.message, !r.ok); }); }); }; document.querySelectorAll("[data-audio-filter]").forEach(function (b) { b.onclick = function () { document.querySelectorAll("[data-audio-filter]").forEach(function (x) { x.classList.remove("active"); }); b.classList.add("active"); renderAudio(b.dataset.audioFilter); }; }); check().catch(function () { renderPacks(); }); }
  window.DromocobPacks = { init: init, check: check };
})();
