# Dromocob Ultra Extension

After Effects 2026 için ayrıştırılmış CEP panel mimarisi.

Sürüm 2.5.0; 3D Döngü Laboratuvarı, Geçiş Laboratuvarı, hazır efekt zincirleri, canlı kompozisyon bilgi alanı, Ultra Ayarlar, SFX/Paket Merkezi ve 3D Metin Stüdyosu içerir.

## Yapı

- `index.html`: panel iskeleti
- `css/theme.css`: ultra tema ve responsive görünüm
- `js/app.js`: ana arayüz ve komutlar
- `js/curves.js`: canlı cubic-bezier editörü
- `js/luts.js`: LUT tarama, arama, filtre ve favoriler
- `js/carousel.js`: 3D Döngü Laboratuvarı arayüzü, hazır ayar ve eylem yönetimi
- `js/bridge.js`: CEP ↔ ExtendScript köprüsü
- `jsx/host.jsx`: After Effects katman/anahtar kare motoru
- `jsx/carousel.jsx`: controller-driven 3D carousel ve kamera motoru
- `assets/dromocob-logo.png`: marka logosu

## Kurulum

Geliştirme sürümünde klasörün tamamı Adobe CEP extensions dizinine yerleştirilir. Panel After Effects yeniden başlatıldıktan sonra `Window > Extensions (Legacy) > Dromocob Ultra` altında görünür.

Panel `.cube`, `.3dl`, `.look` ve `.csp` LUT arşivlerini alt klasörleriyle birlikte tarar. Seçilen LUT doğrudan katmana veya otomatik oluşturulan ayar katmanına uygulanabilir.

3D Döngü Laboratuvarı seçili kaynak katmanları değiştirmeden kopyalar; `DROMOCOB_CAROUSEL_CTRL` üzerindeki ifade kontrolcüleriyle 10 farklı 3D düzeni canlı yönetir.
