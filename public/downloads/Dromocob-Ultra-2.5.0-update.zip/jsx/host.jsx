/* Dromocob Ultra — After Effects host engine */
var Dromocob = Dromocob || {};

(function (api) {
    var TRANSFORM = "ADBE Transform Group";

    function encode(value) {
        if (value === null) return "null";
        if (typeof value === "string") return '"' + value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
        if (typeof value === "number" || typeof value === "boolean") return String(value);
        if (value instanceof Array) {
            var parts = [];
            for (var i = 0; i < value.length; i++) parts.push(encode(value[i]));
            return "[" + parts.join(",") + "]";
        }
        var fields = [];
        for (var key in value) {
            if (value.hasOwnProperty(key)) fields.push(encode(key) + ":" + encode(value[key]));
        }
        return "{" + fields.join(",") + "}";
    }

    function response(ok, message, extra) {
        var result = extra || {};
        result.ok = ok;
        result.message = message || "";
        return encode(result);
    }

    function activeComp() {
        var item = app.project ? app.project.activeItem : null;
        return item && item instanceof CompItem ? item : null;
    }

    function selectedLayers(comp) {
        return comp ? comp.selectedLayers : [];
    }

    function requireComp() {
        var comp = activeComp();
        if (!comp) throw new Error("Önce bir composition aç.");
        return comp;
    }

    function requireLayers() {
        var comp = requireComp();
        var layers = selectedLayers(comp);
        if (!layers || !layers.length) throw new Error("Önce en az bir layer seç.");
        return { comp: comp, layers: layers };
    }

    function clamp(value, minimum, maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    function durationSeconds(comp, payload) {
        var frames = Number(payload.durationFrames) || 8;
        return Math.max(1, frames) / comp.frameRate;
    }

    function scaleValue(value, multiplier) {
        var result = [];
        for (var i = 0; i < value.length; i++) result.push(value[i] * multiplier);
        return result;
    }

    function zeroValue(value) {
        var result = [];
        for (var i = 0; i < value.length; i++) result.push(0);
        return result;
    }

    function easeKey(property, keyIndex, influence) {
        try {
            var dimensions = property.value instanceof Array ? property.value.length : 1;
            var easeIn = [];
            var easeOut = [];
            for (var i = 0; i < dimensions; i++) {
                easeIn.push(new KeyframeEase(0, influence));
                easeOut.push(new KeyframeEase(0, influence));
            }
            property.setTemporalEaseAtKey(keyIndex, easeIn, easeOut);
        } catch (_) {}
    }

    function enableMotionBlur(layer, comp) {
        try { layer.motionBlur = true; comp.motionBlur = true; } catch (_) {}
    }

    function animateScale(mode, payload) {
        var target = requireLayers();
        var comp = target.comp;
        var duration = durationSeconds(comp, payload);
        var multiplier = 1 + clamp(Number(payload.intensity) || 30, 5, 100) / 100;
        app.beginUndoGroup("Dromocob " + mode);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var scale = target.layers[i].property(TRANSFORM).property("ADBE Scale");
                if (!scale) continue;
                var current = scale.value;
                var start = mode === "Zoom In" ? scaleValue(current, multiplier) : current;
                var end = mode === "Zoom In" ? current : scaleValue(current, multiplier);
                scale.setValueAtTime(comp.time, start);
                scale.setValueAtTime(comp.time + duration, end);
                easeKey(scale, scale.numKeys - 1, 82);
                easeKey(scale, scale.numKeys, 82);
                enableMotionBlur(target.layers[i], comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, mode + " uygulandı.");
    }

    function fadeIn(payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        app.beginUndoGroup("Dromocob Fade In");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var opacity = target.layers[i].property(TRANSFORM).property("ADBE Opacity");
                opacity.setValueAtTime(target.comp.time, 0);
                opacity.setValueAtTime(target.comp.time + duration, 100);
                easeKey(opacity, opacity.numKeys - 1, 80);
                easeKey(opacity, opacity.numKeys, 80);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Fade In uygulandı.");
    }

    function productPop(payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        app.beginUndoGroup("Dromocob Product Pop");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var scale = transform.property("ADBE Scale");
                var opacity = transform.property("ADBE Opacity");
                var original = scale.value;
                scale.setValueAtTime(target.comp.time, zeroValue(original));
                scale.setValueAtTime(target.comp.time + duration * .68, scaleValue(original, 1.12));
                scale.setValueAtTime(target.comp.time + duration, original);
                opacity.setValueAtTime(target.comp.time, 0);
                opacity.setValueAtTime(target.comp.time + duration * .32, 100);
                for (var key = Math.max(1, scale.numKeys - 2); key <= scale.numKeys; key++) easeKey(scale, key, 78);
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Product Pop uygulandı.");
    }

    function rotateReveal(payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        app.beginUndoGroup("Dromocob Rotate Reveal");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var rotation = transform.property("ADBE Rotate Z");
                var scale = transform.property("ADBE Scale");
                var original = scale.value;
                rotation.setValueAtTime(target.comp.time, -10);
                rotation.setValueAtTime(target.comp.time + duration, 0);
                scale.setValueAtTime(target.comp.time, scaleValue(original, .76));
                scale.setValueAtTime(target.comp.time + duration, original);
                easeKey(rotation, rotation.numKeys - 1, 82); easeKey(rotation, rotation.numKeys, 82);
                easeKey(scale, scale.numKeys - 1, 82); easeKey(scale, scale.numKeys, 82);
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Rotate Reveal uygulandı.");
    }

    function whip(payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        var amount = 1200 * clamp(Number(payload.intensity) || 30, 5, 100) / 100;
        app.beginUndoGroup("Dromocob Whip Right");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var position = target.layers[i].property(TRANSFORM).property("ADBE Position");
                var current = position.value;
                var start = current.slice(0); start[0] -= amount;
                position.setValueAtTime(target.comp.time, start);
                position.setValueAtTime(target.comp.time + duration, current);
                easeKey(position, position.numKeys - 1, 88); easeKey(position, position.numKeys, 88);
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Whip Right uygulandı.");
    }

    function easyEase() {
        var comp = requireComp();
        var properties = comp.selectedProperties;
        if (!properties || !properties.length) throw new Error("Keyframe veya property seç.");
        app.beginUndoGroup("Dromocob Easy Ease");
        try {
            for (var i = 0; i < properties.length; i++) {
                if (!properties[i].numKeys) continue;
                var keys = properties[i].selectedKeys;
                if (!keys.length) for (var key = 1; key <= properties[i].numKeys; key++) easeKey(properties[i], key, 75);
                else for (var s = 0; s < keys.length; s++) easeKey(properties[i], keys[s], 75);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Easy Ease uygulandı.");
    }

    function motionBlur() {
        var target = requireLayers();
        app.beginUndoGroup("Dromocob Motion Blur");
        try {
            target.comp.motionBlur = true;
            for (var i = 0; i < target.layers.length; i++) enableMotionBlur(target.layers[i], target.comp);
        } finally { app.endUndoGroup(); }
        return response(true, "Motion Blur açıldı.");
    }

    function valueComponent(value, dimension) {
        return value instanceof Array ? Number(value[Math.min(dimension, value.length - 1)]) : Number(value);
    }

    function averageSpeed(property, keyIndex, dimension, direction) {
        var other = keyIndex + direction;
        if (other < 1 || other > property.numKeys) return 0;
        var deltaTime = Math.abs(property.keyTime(other) - property.keyTime(keyIndex));
        if (!deltaTime) return 0;
        return Math.abs(valueComponent(property.keyValue(other), dimension) - valueComponent(property.keyValue(keyIndex), dimension)) / deltaTime;
    }

    function applyCurve(payload) {
        var comp = requireComp();
        var curve = payload.curve;
        if (!curve || curve.length !== 4) throw new Error("Eğri değeri geçersiz.");
        var properties = comp.selectedProperties;
        if (!properties || !properties.length) throw new Error("Önce animasyonlu property veya keyframe seç.");
        var influenceOut = clamp(Number(curve[0]) * 100, .1, 100);
        var influenceIn = clamp((1 - Number(curve[2])) * 100, .1, 100);
        var slopeOut = Number(curve[0]) > .001 ? Number(curve[1]) / Number(curve[0]) : 0;
        var slopeIn = (1 - Number(curve[2])) > .001 ? (1 - Number(curve[3])) / (1 - Number(curve[2])) : 0;
        var applied = 0;

        app.beginUndoGroup("Dromocob Live Curve");
        try {
            for (var p = 0; p < properties.length; p++) {
                var property = properties[p];
                if (!property.numKeys) continue;
                var keys = property.selectedKeys;
                if (!keys.length) { keys = []; for (var all = 1; all <= property.numKeys; all++) keys.push(all); }
                var dimensions = property.value instanceof Array ? property.value.length : 1;
                for (var k = 0; k < keys.length; k++) {
                    var easeIn = [], easeOut = [];
                    for (var d = 0; d < dimensions; d++) {
                        easeIn.push(new KeyframeEase(averageSpeed(property, keys[k], d, -1) * slopeIn, influenceIn));
                        easeOut.push(new KeyframeEase(averageSpeed(property, keys[k], d, 1) * slopeOut, influenceOut));
                    }
                    try {
                        property.setInterpolationTypeAtKey(keys[k], KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                        property.setTemporalEaseAtKey(keys[k], easeIn, easeOut);
                        applied++;
                    } catch (_) {}
                }
            }
        } finally { app.endUndoGroup(); }
        if (!applied) throw new Error("Bu property türüne eğri uygulanamadı.");
        return response(true, applied + " keyframe güncellendi.");
    }

    function addEffect(payload) {
        var target = requireLayers();
        var applied = 0;
        app.beginUndoGroup("Dromocob " + payload.displayName);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var effects = target.layers[i].property("ADBE Effect Parade");
                if (effects && effects.canAddProperty(payload.matchName)) { effects.addProperty(payload.matchName); applied++; }
            }
        } finally { app.endUndoGroup(); }
        if (!applied) throw new Error(payload.displayName + " bu layer türüne eklenemedi.");
        return response(true, payload.displayName + " eklendi.");
    }

    function addEffectSafe(layer, names) {
        var effects = layer.property("ADBE Effect Parade");
        for (var i = 0; i < names.length; i++) {
            try {
                if (effects.canAddProperty(names[i])) return effects.addProperty(names[i]);
            } catch (_) {}
        }
        return null;
    }

    function setEffectValue(effect, index, value) {
        try { if (effect && effect.property(index)) effect.property(index).setValue(value); } catch (_) {}
    }

    function effectStack(payload) {
        var target = requireLayers();
        var added = 0;
        app.beginUndoGroup("Dromocob FX • " + payload.displayName);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var layer = target.layers[i];
                var first, second, third;
                if (payload.type === "neonPulse") {
                    first = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                    second = addEffectSafe(layer, ["ADBE Sharpen"]);
                    setEffectValue(second, 1, 18);
                } else if (payload.type === "dreamBloom") {
                    first = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                    second = addEffectSafe(layer, ["ADBE Gaussian Blur 2"]);
                    setEffectValue(second, 1, 8);
                } else if (payload.type === "vhsDamage") {
                    first = addEffectSafe(layer, ["ADBE Noise"]);
                    second = addEffectSafe(layer, ["ADBE Wave Warp"]);
                    third = addEffectSafe(layer, ["ADBE Shift Channels"]);
                    setEffectValue(first, 1, 12);
                } else if (payload.type === "speedBlur") {
                    first = addEffectSafe(layer, ["ADBE Motion Blur", "ADBE Gaussian Blur 2"]);
                    setEffectValue(first, 1, 28);
                } else if (payload.type === "cinemaPunch") {
                    first = addEffectSafe(layer, ["ADBE Curves"]);
                    second = addEffectSafe(layer, ["ADBE Exposure"]);
                    third = addEffectSafe(layer, ["ADBE Sharpen"]);
                    setEffectValue(third, 1, 10);
                } else if (payload.type === "crispDetail") {
                    first = addEffectSafe(layer, ["ADBE Unsharp Mask", "ADBE Sharpen"]);
                    second = addEffectSafe(layer, ["ADBE Sharpen"]);
                    setEffectValue(second, 1, 15);
                } else if (payload.type === "duotoneBlue") {
                    first = addEffectSafe(layer, ["ADBE Tint"]);
                    second = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                    setEffectValue(first, 1, [.01,.04,.09]);
                    setEffectValue(first, 2, [.08,.66,1]);
                } else if (payload.type === "digitalGrit") {
                    first = addEffectSafe(layer, ["ADBE Noise"]);
                    second = addEffectSafe(layer, ["ADBE Turbulent Displace"]);
                    third = addEffectSafe(layer, ["ADBE Sharpen"]);
                    setEffectValue(first, 1, 9);
                    setEffectValue(third, 1, 20);
                } else if (payload.type === "goldenHour" || payload.type === "arcticGlow" || payload.type === "impactEnergy") {
                    first = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                    second = addEffectSafe(layer, ["ADBE Exposure2", "ADBE Exposure"]);
                    third = addEffectSafe(layer, ["ADBE Sharpen"]);
                    setEffectValue(first, 2, payload.type === "impactEnergy" ? 75 : 50);
                    setEffectValue(first, 3, payload.type === "impactEnergy" ? 105 : 65);
                    setEffectValue(third, 1, payload.type === "impactEnergy" ? 22 : 8);
                } else if (payload.type === "softPortrait" || payload.type === "filmSoftness") {
                    first = addEffectSafe(layer, ["ADBE Gaussian Blur 2"]);
                    second = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                    third = addEffectSafe(layer, ["ADBE Noise"]);
                    setEffectValue(first, 1, payload.type === "softPortrait" ? 3 : 1.5);
                    setEffectValue(third, 1, payload.type === "filmSoftness" ? 3 : 1);
                } else if (payload.type === "cyberEdge" || payload.type === "scanlinePro") {
                    first = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                    second = addEffectSafe(layer, payload.type === "scanlinePro" ? ["ADBE Venetian Blinds"] : ["ADBE Find Edges"]);
                    third = addEffectSafe(layer, ["ADBE Noise"]);
                    setEffectValue(third, 1, 6);
                } else if (payload.type === "vignetteFocus") {
                    first = addEffectSafe(layer, ["ADBE CC Vignette", "ADBE Vignette"]);
                    if (!first) first = addEffectSafe(layer, ["ADBE Curves"]);
                }
                if (first) added++;
                try { if (first) first.name = "Dromocob • " + payload.displayName; } catch (_) {}
            }
        } finally { app.endUndoGroup(); }
        if (!added) throw new Error("Bu FX stack seçili layer'a eklenemedi.");
        return response(true, payload.displayName + " FX stack kuruldu.");
    }

    function keyEaseRange(property, fromKey, toKey, influence) {
        for (var key = fromKey; key <= toKey; key++) easeKey(property, key, influence);
    }

    function transitionSpin(type, payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        var direction = type === "spinCCW" ? -1 : 1;
        var entrance = type === "elasticSpin";
        app.beginUndoGroup("Dromocob " + type);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var rotation = transform.property("ADBE Rotate Z");
                var scale = transform.property("ADBE Scale");
                var opacity = transform.property("ADBE Opacity");
                var baseRotation = rotation.value;
                var baseScale = scale.value;
                if (entrance) {
                    rotation.setValueAtTime(target.comp.time, baseRotation - 360);
                    rotation.setValueAtTime(target.comp.time + duration * .82, baseRotation + 14);
                    rotation.setValueAtTime(target.comp.time + duration, baseRotation);
                    scale.setValueAtTime(target.comp.time, scaleValue(baseScale, .12));
                    scale.setValueAtTime(target.comp.time + duration * .82, scaleValue(baseScale, 1.08));
                    scale.setValueAtTime(target.comp.time + duration, baseScale);
                    opacity.setValueAtTime(target.comp.time, 0);
                    opacity.setValueAtTime(target.comp.time + duration * .3, 100);
                } else {
                    rotation.setValueAtTime(target.comp.time, baseRotation);
                    rotation.setValueAtTime(target.comp.time + duration, baseRotation + 420 * direction);
                    scale.setValueAtTime(target.comp.time, baseScale);
                    scale.setValueAtTime(target.comp.time + duration, scaleValue(baseScale, .08));
                    opacity.setValueAtTime(target.comp.time + duration * .7, 100);
                    opacity.setValueAtTime(target.comp.time + duration, 0);
                }
                keyEaseRange(rotation, Math.max(1, rotation.numKeys - (entrance ? 2 : 1)), rotation.numKeys, 82);
                keyEaseRange(scale, Math.max(1, scale.numKeys - (entrance ? 2 : 1)), scale.numKeys, 82);
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Spin transition uygulandı.");
    }

    function transitionWhip(type, payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        var intensity = clamp(Number(payload.intensity) || 30, 5, 100) / 100;
        app.beginUndoGroup("Dromocob " + type);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var position = transform.property("ADBE Position");
                var opacity = transform.property("ADBE Opacity");
                var current = position.value;
                var end = current.slice(0);
                var horizontal = (target.comp.width + target.layers[i].width) * intensity;
                var vertical = (target.comp.height + target.layers[i].height) * intensity;
                if (type === "whipLeft") end[0] -= horizontal;
                if (type === "whipRight") end[0] += horizontal;
                if (type === "whipUp") end[1] -= vertical;
                if (type === "whipDown") end[1] += vertical;
                position.setValueAtTime(target.comp.time, current);
                position.setValueAtTime(target.comp.time + duration, end);
                opacity.setValueAtTime(target.comp.time + duration * .72, 100);
                opacity.setValueAtTime(target.comp.time + duration, 0);
                easeKey(position, position.numKeys - 1, 90); easeKey(position, position.numKeys, 90);
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Whip transition uygulandı.");
    }

    function transitionZoom(payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        app.beginUndoGroup("Dromocob Zoom Burst");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var scale = transform.property("ADBE Scale");
                var opacity = transform.property("ADBE Opacity");
                var base = scale.value;
                scale.setValueAtTime(target.comp.time, base);
                scale.setValueAtTime(target.comp.time + duration, scaleValue(base, 2.15));
                opacity.setValueAtTime(target.comp.time + duration * .58, 100);
                opacity.setValueAtTime(target.comp.time + duration, 0);
                var blur = addEffectSafe(target.layers[i], ["ADBE Radial Blur"]);
                if (blur) {
                    setEffectValue(blur, 2, 1);
                    try { blur.property(1).setValueAtTime(target.comp.time, 0); blur.property(1).setValueAtTime(target.comp.time + duration, 70); } catch (_) {}
                }
                easeKey(scale, scale.numKeys - 1, 88); easeKey(scale, scale.numKeys, 88);
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Zoom Burst uygulandı.");
    }

    function transitionImpact(type, payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        app.beginUndoGroup("Dromocob " + type);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var position = transform.property("ADBE Position");
                var scale = transform.property("ADBE Scale");
                var basePosition = position.value;
                var baseScale = scale.value;
                if (type === "impactPunch") {
                    scale.setValueAtTime(target.comp.time, baseScale);
                    scale.setValueAtTime(target.comp.time + duration * .32, scaleValue(baseScale, 1.16));
                    scale.setValueAtTime(target.comp.time + duration, baseScale);
                    keyEaseRange(scale, scale.numKeys - 2, scale.numKeys, 78);
                } else {
                    var offsets = [[0,0],[18,-9],[-13,11],[7,-5],[0,0]];
                    for (var o = 0; o < offsets.length; o++) {
                        var next = basePosition.slice(0); next[0] += offsets[o][0]; next[1] += offsets[o][1];
                        position.setValueAtTime(target.comp.time + duration * o / (offsets.length - 1), next);
                    }
                }
                enableMotionBlur(target.layers[i], target.comp);
            }
        } finally { app.endUndoGroup(); }
        return response(true, type === "impactPunch" ? "Impact Punch uygulandı." : "Micro Shake uygulandı.");
    }

    function transitionGlitch(type, payload) {
        var target = requireLayers();
        var duration = durationSeconds(target.comp, payload);
        app.beginUndoGroup("Dromocob " + type);
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var position = transform.property("ADBE Position");
                var opacity = transform.property("ADBE Opacity");
                var base = position.value;
                var steps = [[0,0],[22,-4],[-31,6],[14,2],[-8,-3],[0,0]];
                for (var s = 0; s < steps.length; s++) {
                    var next = base.slice(0); next[0] += steps[s][0]; next[1] += steps[s][1];
                    position.setValueAtTime(target.comp.time + duration * s / (steps.length - 1), next);
                }
                opacity.setValueAtTime(target.comp.time, 100);
                opacity.setValueAtTime(target.comp.time + duration * .38, type === "rgbFlash" ? 35 : 0);
                opacity.setValueAtTime(target.comp.time + duration * .52, 100);
                var noise = addEffectSafe(target.layers[i], ["ADBE Noise"]);
                setEffectValue(noise, 1, type === "rgbFlash" ? 5 : 18);
            }
        } finally { app.endUndoGroup(); }
        return response(true, type === "rgbFlash" ? "RGB Flash uygulandı." : "Glitch Cut uygulandı.");
    }

    function overlaySolid(comp, name, color, start, end) {
        var layer = comp.layers.addSolid(color, name, comp.width, comp.height, comp.pixelAspect, comp.duration);
        layer.inPoint = start;
        layer.outPoint = Math.min(comp.duration, end + comp.frameDuration);
        layer.label = 9;
        try { layer.blendingMode = BlendingMode.ADD; } catch (_) {}
        return layer;
    }

    function energyOverlay(type, payload) {
        var comp = requireComp();
        var duration = durationSeconds(comp, payload);
        var start = comp.time;
        var middle = start + duration * .5;
        var end = start + duration;
        app.beginUndoGroup("Dromocob " + type);
        try {
            var color = type === "blueEnergy" ? [.02,.35,1] : (type === "flashCut" ? [1,1,1] : [1,.16,0]);
            var layer = overlaySolid(comp, "DROMOCOB • " + type.toUpperCase(), color, start, end);
            var opacity = layer.property(TRANSFORM).property("ADBE Opacity");
            opacity.setValueAtTime(start, 0);
            opacity.setValueAtTime(middle, type === "filmBurn" ? 88 : 100);
            opacity.setValueAtTime(end, 0);
            easeKey(opacity, opacity.numKeys - 2, 76); easeKey(opacity, opacity.numKeys - 1, 76); easeKey(opacity, opacity.numKeys, 76);

            if (type === "fireWipe" || type === "filmBurn") {
                var fractal = addEffectSafe(layer, ["ADBE Fractal Noise", "ADBE Turbulent Noise"]);
                var tint = addEffectSafe(layer, ["ADBE Tint"]);
                var glow = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                setEffectValue(tint, 1, [.08,0,0]);
                setEffectValue(tint, 2, [1,.72,.04]);
                if (type === "fireWipe") {
                    var wipe = addEffectSafe(layer, ["ADBE Linear Wipe"]);
                    try {
                        wipe.property(1).setValueAtTime(start, 100);
                        wipe.property(1).setValueAtTime(middle, 0);
                        wipe.property(1).setValueAtTime(end, 100);
                        setEffectValue(wipe, 2, 0);
                        setEffectValue(wipe, 3, Math.round(comp.width * .18));
                    } catch (_) {}
                }
                if (type === "filmBurn") {
                    var hot = overlaySolid(comp, "DROMOCOB • BURN CORE", [1,.78,.12], start, end);
                    var hotOpacity = hot.property(TRANSFORM).property("ADBE Opacity");
                    hotOpacity.setValueAtTime(start, 0); hotOpacity.setValueAtTime(start + duration * .62, 72); hotOpacity.setValueAtTime(end, 0);
                    var hotScale = hot.property(TRANSFORM).property("ADBE Scale");
                    hotScale.setValueAtTime(start, [15,15]); hotScale.setValueAtTime(end, [180,180]);
                }
            }
        } finally { app.endUndoGroup(); }
        return response(true, type === "fireWipe" ? "Fire Wipe oluşturuldu." : type === "filmBurn" ? "Film Burn oluşturuldu." : type === "blueEnergy" ? "Blue Energy oluşturuldu." : "Flash Cut oluşturuldu.");
    }

    function transition(payload) {
        var type = payload.type;
        if (type === "fireWipe" || type === "filmBurn" || type === "flashCut" || type === "blueEnergy") return energyOverlay(type, payload);
        if (type === "spinCW" || type === "spinCCW" || type === "elasticSpin") return transitionSpin(type, payload);
        if (type === "whipLeft" || type === "whipRight" || type === "whipUp" || type === "whipDown") return transitionWhip(type, payload);
        if (type === "zoomBurst") return transitionZoom(payload);
        if (type === "impactPunch" || type === "microShake") return transitionImpact(type, payload);
        if (type === "glitchCut" || type === "rgbFlash") return transitionGlitch(type, payload);
        throw new Error("Geçiş preset'i bulunamadı.");
    }

    function shake(payload) {
        var target = requireLayers();
        var frequency = clamp(Number(payload.frequency) || 4, .1, 100);
        var amount = clamp(Number(payload.amount) || 25, 0, 5000);
        var rotationAmount = clamp(Number(payload.rotation) || 0, 0, 180);
        app.beginUndoGroup("Dromocob Shake");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var position = transform.property("ADBE Position");
                if (position.canSetExpression) position.expression = "wiggle(" + frequency + "," + amount + ")";
                var rotation = transform.property("ADBE Rotate Z");
                if (rotationAmount && rotation.canSetExpression) rotation.expression = "wiggle(" + frequency + "," + rotationAmount + ")";
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Sarsıntı expression'ı uygulandı.");
    }

    function removeShake() {
        var target = requireLayers();
        app.beginUndoGroup("Dromocob Remove Shake");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var transform = target.layers[i].property(TRANSFORM);
                var names = ["ADBE Position", "ADBE Rotate Z", "ADBE Scale"];
                for (var n = 0; n < names.length; n++) {
                    var property = transform.property(names[n]);
                    try { if (property.expression.indexOf("wiggle(") !== -1) property.expression = ""; } catch (_) {}
                }
            }
        } finally { app.endUndoGroup(); }
        return response(true, "Dromocob sarsıntıları temizlendi.");
    }

    function createAdjustment() {
        var comp = requireComp();
        app.beginUndoGroup("Dromocob Adjustment");
        try {
            var layer = comp.layers.addSolid([1,1,1], "DROMOCOB_ADJUSTMENT", comp.width, comp.height, comp.pixelAspect, comp.duration);
            layer.adjustmentLayer = true; layer.label = 5;
        } finally { app.endUndoGroup(); }
        return response(true, "Adjustment Layer oluşturuldu.");
    }

    function parentToNull() {
        var target = requireLayers();
        app.beginUndoGroup("Dromocob Null Controller");
        try {
            var controller = target.comp.layers.addNull();
            controller.name = "DROMOCOB_MASTER_CTRL"; controller.label = 9;
            for (var i = 0; i < target.layers.length; i++) target.layers[i].parent = controller;
        } finally { app.endUndoGroup(); }
        return response(true, "Null Controller oluşturuldu.");
    }

    function precompose() {
        var target = requireLayers();
        var indices = [];
        for (var i = 0; i < target.layers.length; i++) indices.push(target.layers[i].index);
        app.beginUndoGroup("Dromocob Pre-compose");
        try { target.comp.layers.precompose(indices, "DROMOCOB_PRECOMP", true); }
        finally { app.endUndoGroup(); }
        return response(true, "Layer'lar pre-compose edildi.");
    }

    function createComp(payload) {
        if (!app.project) app.newProject();
        app.beginUndoGroup("Dromocob New Comp");
        try {
            var comp = app.project.items.addComp(payload.name || "DROMOCOB_COMP", Number(payload.width), Number(payload.height), 1, 15, Number(payload.fps) || 25);
            comp.openInViewer();
        } finally { app.endUndoGroup(); }
        return response(true, payload.width + " × " + payload.height + " composition oluşturuldu.");
    }

    function createTitle() {
        var comp = requireComp();
        app.beginUndoGroup("Dromocob Title");
        try {
            var layer = comp.layers.addText("YOUR TITLE");
            layer.name = "DROMOCOB_TITLE"; layer.label = 9;
            var source = layer.property("ADBE Text Properties").property("ADBE Text Document");
            var documentValue = source.value;
            documentValue.fontSize = Math.max(48, Math.round(comp.height * .075));
            documentValue.fillColor = [1,1,1];
            documentValue.justification = ParagraphJustification.CENTER_JUSTIFY;
            source.setValue(documentValue);
            layer.property(TRANSFORM).property("ADBE Position").setValue([comp.width / 2, comp.height / 2]);
        } finally { app.endUndoGroup(); }
        return response(true, "Başlık layer'ı oluşturuldu.");
    }

    function hexColor(value) {
        var hex = String(value || "#ffffff").replace("#", "");
        if (hex.length === 3) hex = hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
        return [parseInt(hex.substr(0,2), 16) / 255, parseInt(hex.substr(2,2), 16) / 255, parseInt(hex.substr(4,2), 16) / 255];
    }

    function isTextLayer(layer) {
        try { return Boolean(layer.property("ADBE Text Properties").property("ADBE Text Document")); }
        catch (_) { return false; }
    }

    function setTextDocument(layer, payload, colorOverride) {
        var source = layer.property("ADBE Text Properties").property("ADBE Text Document");
        var documentValue = source.value;
        documentValue.text = String(payload.text || "DROMOCOB");
        documentValue.fontSize = clamp(Number(payload.size) || 120, 8, 800);
        documentValue.tracking = clamp(Number(payload.tracking) || 0, -200, 1000);
        try { if (payload.font) documentValue.font = String(payload.font); } catch (_) {}
        try { documentValue.leading = clamp(Number(payload.leading) || documentValue.fontSize * 1.2, 0, 1000); documentValue.autoLeading = false; } catch (_) {}
        try { documentValue.allCaps = Boolean(payload.allCaps); } catch (_) {}
        try { documentValue.fauxBold = Boolean(payload.fauxBold); } catch (_) {}
        try {
            if (payload.align === "left") documentValue.justification = ParagraphJustification.LEFT_JUSTIFY;
            else if (payload.align === "right") documentValue.justification = ParagraphJustification.RIGHT_JUSTIFY;
            else documentValue.justification = ParagraphJustification.CENTER_JUSTIFY;
        } catch (_) { documentValue.justification = ParagraphJustification.CENTER_JUSTIFY; }
        documentValue.applyFill = true;
        documentValue.fillColor = colorOverride || hexColor(payload.color);
        var strokeWidth = clamp(Number(payload.strokeWidth) || 0, 0, 40);
        try { documentValue.applyStroke = strokeWidth > 0; documentValue.strokeWidth = strokeWidth; documentValue.strokeColor = [0,0,0]; } catch (_) {}
        source.setValue(documentValue);
    }

    function glowLab(payload) {
        var target = requireLayers();
        var threshold = clamp(Number(payload.threshold) || 50, 0, 100);
        var radius = clamp(Number(payload.radius) || 70, 1, 250);
        var power = clamp(Number(payload.power) || 1.2, .01, 3);
        var secondary = clamp(Number(payload.secondary) || 0, 0, 100) / 100;
        var color = hexColor(payload.color);
        var added = 0;
        app.beginUndoGroup("Dromocob Glow Lab • " + String(payload.name || "Custom"));
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var layer = target.layers[i];
                var glowOne = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
                var glowTwo = secondary > 0 ? addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]) : null;
                if (!glowOne) continue;
                glowOne.name = "DROMOCOB GLOW • CORE";
                setEffectValue(glowOne, 1, threshold); setEffectValue(glowOne, 2, radius); setEffectValue(glowOne, 3, power);
                setEffectValue(glowOne, 5, color);
                if (glowTwo) {
                    glowTwo.name = "DROMOCOB GLOW • AURA";
                    setEffectValue(glowTwo, 1, Math.max(0, threshold - 15)); setEffectValue(glowTwo, 2, radius * 1.8); setEffectValue(glowTwo, 3, power * secondary);
                    setEffectValue(glowTwo, 5, color);
                }
                if (payload.animate) {
                    try {
                        var intensityProperty = glowOne.property(3);
                        var duration = durationSeconds(target.comp, payload);
                        intensityProperty.setValueAtTime(target.comp.time, power * .55);
                        intensityProperty.setValueAtTime(target.comp.time + duration * .5, power * 1.35);
                        intensityProperty.setValueAtTime(target.comp.time + duration, power);
                        keyEaseRange(intensityProperty, intensityProperty.numKeys - 2, intensityProperty.numKeys, 72);
                    } catch (_) {}
                }
                added++;
            }
        } finally { app.endUndoGroup(); }
        if (!added) throw new Error("Glow seçili layer'a eklenemedi.");
        return response(true, "Glow Lab karakteri uygulandı.");
    }

    function removeDromocobGlow() {
        var target = requireLayers();
        var removed = 0;
        app.beginUndoGroup("Dromocob Glow Temizle");
        try {
            for (var i = 0; i < target.layers.length; i++) {
                var effects = target.layers[i].property("ADBE Effect Parade");
                for (var e = effects.numProperties; e >= 1; e--) {
                    if (String(effects.property(e).name).indexOf("DROMOCOB GLOW") === 0) { effects.property(e).remove(); removed++; }
                }
            }
        } finally { app.endUndoGroup(); }
        return response(true, removed + " Dromocob Glow kaldırıldı.");
    }

    function textExtrusion(layer, payload, count, color) {
        var depth = clamp(Number(payload.depth) || count, 1, 20);
        var copies = Math.min(count || depth, depth);
        var mainPosition = layer.property(TRANSFORM).property("ADBE Position").value;
        for (var i = copies; i >= 1; i--) {
            var copy = layer.duplicate();
            copy.name = layer.name + " • DEPTH " + i;
            setTextDocument(copy, payload, color);
            copy.threeDLayer = Boolean(payload.threeD);
            var position = mainPosition.slice(0);
            position[0] += i * 1.5;
            position[1] += i * 1.5;
            if (position.length > 2) position[2] += i * 2;
            copy.property(TRANSFORM).property("ADBE Position").setValue(position);
            try { copy.moveAfter(layer); } catch (_) {}
        }
    }

    function animateTextStyle(layer, style, comp, payload) {
        var duration = durationSeconds(comp, payload);
        var transform = layer.property(TRANSFORM);
        if (style === "kineticPop") {
            var scale = transform.property("ADBE Scale");
            var opacity = transform.property("ADBE Opacity");
            var base = scale.value;
            scale.setValueAtTime(comp.time, zeroValue(base));
            scale.setValueAtTime(comp.time + duration * .7, scaleValue(base, 1.15));
            scale.setValueAtTime(comp.time + duration, base);
            opacity.setValueAtTime(comp.time, 0); opacity.setValueAtTime(comp.time + duration * .25, 100);
            keyEaseRange(scale, scale.numKeys - 2, scale.numKeys, 82);
        }
        if (style === "spin3D") {
            layer.threeDLayer = true;
            var rotateY = transform.property("ADBE Rotate Y");
            var scale3D = transform.property("ADBE Scale");
            var baseScale = scale3D.value;
            rotateY.setValueAtTime(comp.time, -110);
            rotateY.setValueAtTime(comp.time + duration, 0);
            scale3D.setValueAtTime(comp.time, scaleValue(baseScale, .65));
            scale3D.setValueAtTime(comp.time + duration, baseScale);
            easeKey(rotateY, rotateY.numKeys - 1, 86); easeKey(rotateY, rotateY.numKeys, 86);
        }
    }

    function styleTextLayer(layer, style, comp, payload) {
        layer.threeDLayer = Boolean(payload.threeD || style === "spin3D");
        if (style === "chromeExtrude") {
            textExtrusion(layer, payload, 10, [.09,.13,.18]);
            addEffectSafe(layer, ["ADBE Bevel Alpha", "ADBE Bevel Edges"]);
            addEffectSafe(layer, ["ADBE Drop Shadow"]);
        } else if (style === "neon3D") {
            textExtrusion(layer, payload, 5, [.01,.08,.16]);
            var glowOne = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
            var glowTwo = addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
            setEffectValue(glowOne, 3, 35); setEffectValue(glowTwo, 3, 85);
        } else if (style === "shadowStack") {
            textExtrusion(layer, payload, 12, [.02,.18,.34]);
            addEffectSafe(layer, ["ADBE Drop Shadow"]);
        } else if (style === "cinemaBevel") {
            addEffectSafe(layer, ["ADBE Bevel Alpha", "ADBE Bevel Edges"]);
            addEffectSafe(layer, ["ADBE Drop Shadow"]);
            addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
        } else if (style === "hologram") {
            addEffectSafe(layer, ["ADBE Glow", "ADBE Glo2"]);
            addEffectSafe(layer, ["ADBE Noise"]);
            addEffectSafe(layer, ["ADBE Venetian Blinds"]);
        } else if (style === "blockDepth") {
            textExtrusion(layer, payload, 18, [.015,.07,.12]);
            addEffectSafe(layer, ["ADBE Drop Shadow"]);
        }
        animateTextStyle(layer, style, comp, payload);
    }

    function textStudio(payload) {
        var comp = requireComp();
        var layers = selectedLayers(comp);
        var layer = null;
        for (var i = 0; i < layers.length; i++) {
            if (isTextLayer(layers[i])) { layer = layers[i]; break; }
        }
        if (payload.update && !layer) throw new Error("Güncellemek için bir text layer seç.");

        app.beginUndoGroup("Dromocob 3D Text • " + payload.style);
        try {
            if (!layer) {
                layer = comp.layers.addText(String(payload.text || "DROMOCOB"));
                layer.name = "DROMOCOB • " + String(payload.text || "TEXT").substr(0, 24);
                layer.label = 9;
                layer.property(TRANSFORM).property("ADBE Position").setValue([comp.width / 2, comp.height / 2]);
            }
            setTextDocument(layer, payload);
            styleTextLayer(layer, payload.style || "clean3D", comp, payload);
            layer.selected = true;
        } finally { app.endUndoGroup(); }
        return response(true, payload.update ? "Seçili text güncellendi." : "3D text oluşturuldu.");
    }

    function letterbox() {
        var comp = requireComp();
        var height = Math.round(comp.height * .11);
        app.beginUndoGroup("Dromocob Letterbox");
        try {
            var top = comp.layers.addSolid([0,0,0], "DROMOCOB_LETTERBOX_TOP", comp.width, height, 1, comp.duration);
            var bottom = comp.layers.addSolid([0,0,0], "DROMOCOB_LETTERBOX_BOTTOM", comp.width, height, 1, comp.duration);
            top.property(TRANSFORM).property("ADBE Position").setValue([comp.width / 2, height / 2]);
            bottom.property(TRANSFORM).property("ADBE Position").setValue([comp.width / 2, comp.height - height / 2]);
        } finally { app.endUndoGroup(); }
        return response(true, "Cinema Letterbox oluşturuldu.");
    }

    function safeGuide() {
        var comp = requireComp();
        app.beginUndoGroup("Dromocob Safe Guide");
        try {
            var guide = comp.layers.addShape();
            guide.name = "DROMOCOB_SAFE_GUIDE"; guide.guideLayer = true; guide.label = 9;
            var root = guide.property("ADBE Root Vectors Group");
            var rectangle = root.addProperty("ADBE Vector Shape - Rect");
            rectangle.property("ADBE Vector Rect Size").setValue([comp.width * .9, comp.height * .9]);
            var stroke = root.addProperty("ADBE Vector Graphic - Stroke");
            stroke.property("ADBE Vector Stroke Color").setValue([.07,.55,1]);
            stroke.property("ADBE Vector Stroke Width").setValue(3);
            guide.property(TRANSFORM).property("ADBE Position").setValue([comp.width / 2, comp.height / 2]);
        } finally { app.endUndoGroup(); }
        return response(true, "Safe Area Guide oluşturuldu.");
    }

    function applyFFX() {
        var target = requireLayers();
        var preset = File.openDialog("FFX preset seç", "*.ffx");
        if (!preset) return response(false, "Preset seçilmedi.");
        app.beginUndoGroup("Dromocob Apply FFX");
        try { for (var i = 0; i < target.layers.length; i++) target.layers[i].applyPreset(preset); }
        finally { app.endUndoGroup(); }
        return response(true, "FFX preset uygulandı.");
    }

    function applyLut(payload) {
        var comp = requireComp();
        var file = new File(payload.path);
        if (!file.exists) throw new Error("LUT dosyası bulunamadı.");
        var targets = [];
        app.beginUndoGroup("Dromocob Apply LUT");
        try {
            if (payload.adjustment) {
                var adjustment = comp.layers.addSolid([1,1,1], "LUT • " + file.displayName.replace(/\.[^.]+$/, ""), comp.width, comp.height, comp.pixelAspect, comp.duration);
                adjustment.adjustmentLayer = true; adjustment.label = 5;
                adjustment.property(TRANSFORM).property("ADBE Opacity").setValue(clamp(Number(payload.strength) || 100, 0, 100));
                targets.push(adjustment);
            } else {
                targets = selectedLayers(comp);
            }
            if (!targets.length) throw new Error("Layer seç veya Adjustment Layer seçeneğini aç.");
            var applied = 0;
            for (var i = 0; i < targets.length; i++) {
                try {
                    var effects = targets[i].property("ADBE Effect Parade");
                    var effect;
                    try { effect = effects.addProperty("ADBE Color LUT"); }
                    catch (primaryError) { effect = effects.addProperty("ADBE Apply Color LUT"); }
                    effect.name = "Dromocob LUT • " + file.displayName.replace(/\.[^.]+$/, "");
                    effect.property(1).setValue(file.fsName);
                    applied++;
                } catch (_) {}
            }
            if (!applied) throw new Error("Apply Color LUT efekti bu layer'da kullanılamadı.");
        } finally { app.endUndoGroup(); }
        return response(true, file.displayName + " uygulandı.");
    }

    function importAudio(payload) {
        var comp = requireComp();
        var file = new File(String(payload.path || ""));
        if (!file.exists) throw new Error("Ses dosyası bulunamadı.");
        app.beginUndoGroup("Dromocob SFX Import");
        try {
            var footage = app.project.importFile(new ImportOptions(file));
            var layer = comp.layers.add(footage);
            layer.name = "DROMOCOB SFX • " + file.displayName.replace(/\.[^.]+$/, "");
            layer.startTime = comp.time;
            layer.label = 10;
        } finally { app.endUndoGroup(); }
        return response(true, file.displayName + " playhead'e eklendi.");
    }

    var methods = {
        context: function () {
            var comp = activeComp();
            return response(true, "Hazır", {
                compName: comp ? comp.name : "",
                selectedLayers: comp ? comp.selectedLayers.length : 0,
                width: comp ? comp.width : 0,
                height: comp ? comp.height : 0,
                fps: comp ? comp.frameRate : 0,
                duration: comp ? comp.duration : 0,
                time: comp ? comp.time : 0,
                renderer: comp ? comp.renderer : "",
                totalFrames: comp ? Math.round(comp.duration * comp.frameRate) : 0,
                workAreaDuration: comp ? comp.workAreaDuration : 0,
                workAreaStart: comp ? comp.workAreaStart : 0,
                pixelAspect: comp ? comp.pixelAspect : 0,
                motionBlur: comp ? comp.motionBlur : false,
                projectName: app.project && app.project.file ? app.project.file.name : "Untitled Project"
            });
        },
        zoomIn: function (p) { return animateScale("Zoom In", p); },
        zoomOut: function (p) { return animateScale("Zoom Out", p); },
        productPop: productPop,
        fadeIn: fadeIn,
        rotateReveal: rotateReveal,
        whipRight: whip,
        easyEase: easyEase,
        motionBlur: motionBlur,
        applyCurve: applyCurve,
        addEffect: addEffect,
        effectStack: effectStack,
        glowLab: glowLab,
        removeDromocobGlow: removeDromocobGlow,
        transition: transition,
        shake: shake,
        removeShake: removeShake,
        createAdjustment: createAdjustment,
        parentToNull: parentToNull,
        precompose: precompose,
        createComp: createComp,
        createTitle: createTitle,
        textStudio: textStudio,
        letterbox: letterbox,
        safeGuide: safeGuide,
        applyFFX: applyFFX,
        applyLut: applyLut,
        importAudio: importAudio,
        carouselCreate: function (p) { if (!api.Carousel) throw new Error("Carousel motoru yüklenemedi."); return api.Carousel.create(p); },
        carouselUpdate: function (p) { if (!api.Carousel) throw new Error("Carousel motoru yüklenemedi."); return api.Carousel.update(p); },
        carouselCamera: function (p) { if (!api.Carousel) throw new Error("Carousel motoru yüklenemedi."); return api.Carousel.createCamera(p); },
        carouselReplace: function (p) { if (!api.Carousel) throw new Error("Carousel motoru yüklenemedi."); return api.Carousel.replace(p); },
        carouselRemove: function () { if (!api.Carousel) throw new Error("Carousel motoru yüklenemedi."); return api.Carousel.remove(); }
    };

    api.dispatch = function (method, payloadText) {
        try {
            if (!methods[method]) return response(false, "Bilinmeyen komut: " + method);
            var payload = payloadText ? eval("(" + payloadText + ")") : {};
            return methods[method](payload || {});
        } catch (error) {
            return response(false, error && error.message ? error.message : error.toString());
        }
    };
})(Dromocob);

try {
    $.evalFile(new File(new File($.fileName).parent.fsName + "/carousel.jsx"));
} catch (carouselLoadError) {}
