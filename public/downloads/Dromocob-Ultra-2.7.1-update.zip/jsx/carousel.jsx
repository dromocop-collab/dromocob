/* Dromocob Ultra — Carousel Lab host module */
(function (api) {
    var CTRL = "DROMOCOB_CAROUSEL_CTRL";
    var CAMERA = "DROMOCOB_CAROUSEL_CAMERA";
    var CARD_PREFIX = "DROMOCOB_CARD_";
    var TYPES = { "Orbit":1, "Arc":2, "Helix":3, "Tunnel":4, "Coverflow":5, "Stack":6, "Wave":7, "Cylinder":8, "Focus Rail":9, "Infinite Conveyor":10 };

    function encode(value) {
        if (value === null) return "null";
        if (typeof value === "string") return '"' + value.replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\r/g,"\\r").replace(/\n/g,"\\n") + '"';
        if (typeof value === "number" || typeof value === "boolean") return String(value);
        if (value instanceof Array) { var list=[]; for(var i=0;i<value.length;i++) list.push(encode(value[i])); return "["+list.join(",")+"]"; }
        var fields=[]; for(var key in value) if(value.hasOwnProperty(key)) fields.push(encode(key)+":"+encode(value[key])); return "{"+fields.join(",")+"}";
    }
    function response(ok,message,extra){var result=extra||{};result.ok=ok;result.message=message||"";return encode(result);}
    function comp(){var item=app.project&&app.project.activeItem; if(!item || !(item instanceof CompItem)) throw new Error("Önce bir composition aç."); return item;}
    function pad(value){var text="000"+value;return text.substr(text.length-3);}
    function num(value,fallback){value=Number(value);return isNaN(value)?fallback:value;}
    function bool(value){return value===true || value===1 || value==="1";}
    function getLayer(target,name){try{return target.layer(name);}catch(_){return null;}}
    function effect(layer,name){try{return layer.property("ADBE Effect Parade").property(name);}catch(_){return null;}}
    function addControl(layer,matchName,name,value){var fx=effect(layer,name);if(!fx){fx=layer.property("ADBE Effect Parade").addProperty(matchName);fx.name=name;}try{fx.property(1).setValue(value);}catch(_){}return fx;}
    function setControl(layer,name,value){var fx=effect(layer,name);if(!fx)return;try{fx.property(1).setValue(value);}catch(_){} }
    function easeId(value){return value==="snap"?3:value==="linear"?4:value==="smooth"?2:1;}
    function typeId(value){return TYPES[value] || 1;}

    var SLIDERS = [
        ["Type",1],["Card Count",8],["Radius",720],["Spacing",320],["Card Scale",72],["Card Width",640],["Card Height",900],["Depth",420],["Arc Amount",180],
        ["Vertical Offset",120],["Perspective",1000],["Randomness",0],["Duration",4],["Speed",1],["Direction",1],["Stagger",.06],["Start Offset",0],["Ease Mode",1],
        ["Overshoot",8],["Active Card",1],["Focus Scale",115],["Inactive Scale",82],["Focus Depth",160],["Camera Distance",1800],["Camera Height",0],["Focal Length",50],["Aperture",80]
    ];
    var CHECKS = [["Motion Blur",1],["Infinite Loop",0],["Auto Rotate",0],["Snap To Card",1],["Auto Camera",1],["Depth Of Field",0],["Focus Follow",1]];

    function ensureController(target,payload){
        var ctrl=getLayer(target,CTRL);
        if(!ctrl){ctrl=target.layers.addNull(target.duration);ctrl.name=CTRL;ctrl.label=9;ctrl.guideLayer=true;try{ctrl.shy=true;}catch(_){} }
        for(var i=0;i<SLIDERS.length;i++) addControl(ctrl,"ADBE Slider Control",SLIDERS[i][0],SLIDERS[i][1]);
        addControl(ctrl,"ADBE Angle Control","Rotation Offset",0);
        for(i=0;i<CHECKS.length;i++) addControl(ctrl,"ADBE Checkbox Control",CHECKS[i][0],CHECKS[i][1]);
        updateControls(ctrl,payload);
        return ctrl;
    }

    function updateControls(ctrl,p){
        var values={
            "Type":typeId(p.type),"Card Count":num(p.cardCount,8),"Radius":num(p.radius,720),"Spacing":num(p.spacing,320),"Card Scale":num(p.cardScale,72),
            "Card Width":num(p.cardWidth,640),"Card Height":num(p.cardHeight,900),"Depth":num(p.depth,420),"Arc Amount":num(p.arcAmount,180),
            "Rotation Offset":num(p.rotationOffset,0),"Vertical Offset":num(p.verticalOffset,120),"Perspective":num(p.perspective,1000),"Randomness":num(p.randomness,0),
            "Duration":Math.max(.01,num(p.duration,4)),"Speed":num(p.speed,1),"Direction":num(p.direction,1),"Stagger":num(p.stagger,.06),"Start Offset":num(p.startOffset,0),
            "Ease Mode":easeId(p.ease),"Overshoot":num(p.overshoot,8),"Active Card":num(p.activeCard,1),"Focus Scale":num(p.focusScale,115),
            "Inactive Scale":num(p.inactiveScale,82),"Focus Depth":num(p.focusDepth,160),"Camera Distance":num(p.cameraDistance,1800),
            "Camera Height":num(p.cameraHeight,0),"Focal Length":num(p.focalLength,50),"Aperture":num(p.aperture,80),
            "Motion Blur":bool(p.motionBlur)?1:0,"Infinite Loop":bool(p.infiniteLoop)?1:0,"Auto Rotate":bool(p.autoRotate)?1:0,"Snap To Card":bool(p.snapToCard)?1:0,
            "Auto Camera":bool(p.autoCamera)?1:0,"Depth Of Field":bool(p.depthOfField)?1:0,"Focus Follow":bool(p.focusFollow)?1:0
        };
        for(var key in values) if(values.hasOwnProperty(key)) setControl(ctrl,key,values[key]);
    }

    function activePrelude(index){
        return 'var c=thisComp.layer("'+CTRL+'");\nvar i='+index+';\nvar n=Math.max(1,Math.round(c.effect("Card Count")("Slider")));\n'+
        'var active=c.effect("Active Card")("Slider")+c.effect("Start Offset")("Slider");\n'+
        'if(c.effect("Auto Rotate")("Checkbox")==1){active+=(time-inPoint)*c.effect("Speed")("Slider")*c.effect("Direction")("Slider")*n/Math.max(.01,c.effect("Duration")("Slider"));}\n'+
        'if(c.effect("Snap To Card")("Checkbox")==1 && c.effect("Auto Rotate")("Checkbox")==0) active=Math.round(active);\n'+
        'var d=i-active;if(c.effect("Auto Rotate")("Checkbox")==1)d+=(i-1)*c.effect("Stagger")("Slider")*c.effect("Direction")("Slider");if(c.effect("Infinite Loop")("Checkbox")==1)d=((d+n/2)%n+n)%n-n/2;\n';
    }
    function positionExpression(index){
        return activePrelude(index)+
        'var t=Math.round(c.effect("Type")("Slider"));var R=c.effect("Radius")("Slider");var sp=c.effect("Spacing")("Slider");var dep=c.effect("Depth")("Slider");var v=c.effect("Vertical Offset")("Slider");var ro=c.effect("Rotation Offset")("Angle");var arc=c.effect("Arc Amount")("Slider");\n'+
        'var a=degreesToRadians(ro+(i-active)*360/n);var x=0,y=v,z=0;\n'+
        'if(t==1||t==8){x=Math.sin(a)*R;z=Math.cos(a)*R;}\n'+
        'else if(t==2){var aa=degreesToRadians(ro+d*arc/Math.max(1,n-1));x=Math.sin(aa)*R;z=Math.cos(aa)*R-R;}\n'+
        'else if(t==3){x=Math.sin(a)*R;y=v+d*v;z=Math.cos(a)*R;}\n'+
        'else if(t==4){var ta=degreesToRadians((i-1)*137.5+ro);x=Math.sin(ta)*R;y=Math.cos(ta)*R*.55+v;z=d*sp;}\n'+
        'else if(t==5){x=d*sp;z=-Math.abs(d)*dep;}\n'+
        'else if(t==6){x=d*sp*.16;y=v-d*v*.22;z=-Math.abs(d)*dep;}\n'+
        'else if(t==7){x=d*sp;y=v+Math.sin(d*1.15)*v;z=Math.cos(d*.8)*dep;}\n'+
        'else if(t==9){x=d*sp;z=Math.abs(d)*dep;}\n'+
        'else {var span=Math.max(sp*n,1);x=((d*sp+span/2)%span+span)%span-span/2;z=Math.sin(d*1.2)*dep*.25;}\n'+
        'seedRandom(i,true);var rnd=c.effect("Randomness")("Slider");x+=(random()-.5)*rnd*10;y+=(random()-.5)*rnd*5;z+=(random()-.5)*rnd*10;\n'+
        'var focus=Math.max(0,1-Math.min(1,Math.abs(d)));z-=focus*c.effect("Focus Depth")("Slider");[thisComp.width/2+x,thisComp.height/2+y,z];';
    }
    function scaleExpression(index){
        return activePrelude(index)+
        'var focus=Math.max(0,1-Math.min(1,Math.abs(d)));var fs=c.effect("Focus Scale")("Slider");var ins=c.effect("Inactive Scale")("Slider");var emphasis=ins+(fs-ins)*focus;\n'+
        'var r;try{r=sourceRectAtTime(time,false);}catch(e){r={width:width,height:height};}var rw=Math.max(1,r.width),rh=Math.max(1,r.height);var fit=Math.min(c.effect("Card Width")("Slider")/rw,c.effect("Card Height")("Slider")/rh)*100;var s=fit*c.effect("Card Scale")("Slider")/100*emphasis/100;[s,s,s];';
    }
    function orientationExpression(index){return activePrelude(index)+'var t=Math.round(c.effect("Type")("Slider"));[t==3?d*2:0,0,t==7?Math.sin(d)*2:0];';}
    function rotationYExpression(index){
        return activePrelude(index)+'var t=Math.round(c.effect("Type")("Slider"));var a=c.effect("Rotation Offset")("Angle")+(i-active)*360/n;var r=0;if(t==1||t==3||t==8)r=-a;else if(t==5||t==9)r=(d==0?0:(d>0?-55:55));else if(t==6)r=d*9;r;';
    }
    function rotationZExpression(index){return activePrelude(index)+'var t=Math.round(c.effect("Type")("Slider"));var r=0;if(t==7)r=Math.sin(d)*10;else if(t==2)r=-d*c.effect("Arc Amount")("Slider")/Math.max(1,n-1)*.25;r;';}

    function safeCenterAnchor(layer){
        try{
            var tr=layer.property("ADBE Transform Group"),anchor=tr.property("ADBE Anchor Point"),position=tr.property("ADBE Position");
            if(anchor.expressionEnabled || position.expressionEnabled) return;
            var rect=layer.sourceRectAtTime(layer.containingComp.time,false),old=anchor.value,next=[rect.left+rect.width/2,rect.top+rect.height/2];
            if(old.length===3)next.push(old[2]);var delta=[next[0]-old[0],next[1]-old[1],next.length>2?next[2]-old[2]:0],pos=position.value;
            anchor.setValue(next);position.setValue(pos.length===3?[pos[0]+delta[0],pos[1]+delta[1],pos[2]+delta[2]]:[pos[0]+delta[0],pos[1]+delta[1]]);
        }catch(_){}
    }
    function applyCardExpressions(cards){
        for(var i=0;i<cards.length;i++){
            var layer=cards[i],index=i+1,tr=layer.property("ADBE Transform Group");layer.threeDLayer=true;safeCenterAnchor(layer);
            tr.property("ADBE Position").expression=positionExpression(index);
            tr.property("ADBE Scale").expression=scaleExpression(index);
            tr.property("ADBE Orientation").expression=orientationExpression(index);
            tr.property("ADBE Rotate Y").expression=rotationYExpression(index);
            tr.property("ADBE Rotate Z").expression=rotationZExpression(index);
            try{layer.motionBlur=true;}catch(_){}
        }
    }
    function setTypeAndApply(cards,id,ctrl){setControl(ctrl,"Type",id);applyCardExpressions(cards);}
    function createOrbitCarousel(cards,ctrl){setTypeAndApply(cards,1,ctrl);}
    function createArcCarousel(cards,ctrl){setTypeAndApply(cards,2,ctrl);}
    function createHelixCarousel(cards,ctrl){setTypeAndApply(cards,3,ctrl);}
    function createTunnelCarousel(cards,ctrl){setTypeAndApply(cards,4,ctrl);}
    function createCoverflowCarousel(cards,ctrl){setTypeAndApply(cards,5,ctrl);}
    function createStackCarousel(cards,ctrl){setTypeAndApply(cards,6,ctrl);}
    function createWaveCarousel(cards,ctrl){setTypeAndApply(cards,7,ctrl);}
    function createCylinderCarousel(cards,ctrl){setTypeAndApply(cards,8,ctrl);}
    function createFocusRailCarousel(cards,ctrl){setTypeAndApply(cards,9,ctrl);}
    function createInfiniteConveyorCarousel(cards,ctrl){setTypeAndApply(cards,10,ctrl);setControl(ctrl,"Infinite Loop",1);}
    function applyByType(cards,ctrl,id){var f=[createOrbitCarousel,createArcCarousel,createHelixCarousel,createTunnelCarousel,createCoverflowCarousel,createStackCarousel,createWaveCarousel,createCylinderCarousel,createFocusRailCarousel,createInfiniteConveyorCarousel];f[Math.max(0,Math.min(9,id-1))](cards,ctrl);}

    function cardLayers(target){var cards=[];for(var i=1;i<=target.numLayers;i++)if(target.layer(i).name.indexOf(CARD_PREFIX)===0)cards.push(target.layer(i));cards.sort(function(a,b){return a.name>b.name?1:-1;});return cards;}
    function makeCards(target,sources,count){var cards=[];for(var i=0;i<count;i++){var duplicate=sources[i%sources.length].duplicate();duplicate.name=CARD_PREFIX+pad(i+1);duplicate.label=12;duplicate.comment="Dromocob Ultra Carousel Card";duplicate.threeDLayer=true;cards.push(duplicate);}return cards;}
    function cameraTargetExpression(){return 'var c=thisComp.layer("'+CTRL+'");var n=Math.max(1,Math.round(c.effect("Card Count")("Slider")));var a=Math.round(c.effect("Active Card")("Slider"));a=((a-1)%n+n)%n+1;var nm="'+CARD_PREFIX+'"+("000"+a).slice(-3);try{var l=thisComp.layer(nm);l.toWorld(l.anchorPoint);}catch(e){[thisComp.width/2,thisComp.height/2,0];}';}
    function cameraFocusExpression(){return 'var c=thisComp.layer("'+CTRL+'");if(c.effect("Focus Follow")("Checkbox")==1){var n=Math.max(1,Math.round(c.effect("Card Count")("Slider")));var a=Math.round(c.effect("Active Card")("Slider"));a=((a-1)%n+n)%n+1;var nm="'+CARD_PREFIX+'"+("000"+a).slice(-3);var target;try{var l=thisComp.layer(nm);target=l.toWorld(l.anchorPoint);}catch(e){target=[thisComp.width/2,thisComp.height/2,0];}length(transform.position,target);}else value;';}
    function ensureCamera(target,ctrl){
        var camera=getLayer(target,CAMERA);if(!camera){camera=target.layers.addCamera(CAMERA,[target.width/2,target.height/2]);camera.label=9;}
        var tr=camera.property("ADBE Transform Group"),options=camera.property("ADBE Camera Options Group");
        tr.property("ADBE Position").expression='var c=thisComp.layer("'+CTRL+'");[thisComp.width/2,thisComp.height/2+c.effect("Camera Height")("Slider"),-c.effect("Camera Distance")("Slider")];';
        try{tr.property("ADBE Point of Interest").expression=cameraTargetExpression();}catch(_){}
        try{options.property("ADBE Camera Zoom").expression='thisComp.width*thisComp.layer("'+CTRL+'").effect("Focal Length")("Slider")/36;';}catch(_){}
        try{options.property("ADBE Camera Depth of Field").expression='thisComp.layer("'+CTRL+'").effect("Depth Of Field")("Checkbox");';}catch(_){}
        try{options.property("ADBE Camera Aperture").expression='thisComp.layer("'+CTRL+'").effect("Aperture")("Slider");';}catch(_){}
        try{options.property("ADBE Camera Focus Distance").expression=cameraFocusExpression();}catch(_){}
        return camera;
    }

    function create(payload){
        var target=comp(),sources=target.selectedLayers;if(!sources || !sources.length)throw new Error("Carousel için en az bir source layer seç.");
        var sourceCopy=[];for(var s=0;s<sources.length;s++)if(sources[s].name!==CTRL && sources[s].name!==CAMERA && sources[s].name.indexOf(CARD_PREFIX)!==0)sourceCopy.push(sources[s]);
        if(!sourceCopy.length)throw new Error("Original source layer seç; mevcut carousel kartları source olarak kullanılamaz.");
        app.beginUndoGroup("Dromocob Ultra - Carousel");
        try{
            var existing=cardLayers(target);for(var e=0;e<existing.length;e++)existing[e].remove();
            var count=Math.max(1,Math.min(100,Math.round(num(payload.cardCount,sourceCopy.length)))),ctrl=ensureController(target,payload);setControl(ctrl,"Card Count",count);
            var cards=makeCards(target,sourceCopy,count);applyByType(cards,ctrl,typeId(payload.type));
            try{target.motionBlur=bool(payload.motionBlur);}catch(_){}
            if(bool(payload.autoCamera))ensureCamera(target,ctrl);
            return response(true,count+" kartlı "+payload.type+" carousel oluşturuldu. Controller üzerinden canlı düzenlenebilir.",{count:count,controller:CTRL});
        }finally{app.endUndoGroup();}
    }
    function update(payload){
        var target=comp(),ctrl=getLayer(target,CTRL);if(!ctrl)throw new Error("Güncellenecek carousel bulunamadı. Önce CREATE CAROUSEL kullan.");
        app.beginUndoGroup("Dromocob Ultra - Carousel");try{
            updateControls(ctrl,payload);var cards=cardLayers(target),wanted=Math.max(1,Math.min(100,Math.round(num(payload.cardCount,cards.length))));
            if(!cards.length)throw new Error("Carousel kartları bulunamadı. Source layer seçip yeniden oluştur.");
            while(cards.length<wanted){var extra=cards[cards.length%cards.length].duplicate();extra.name=CARD_PREFIX+pad(cards.length+1);extra.label=12;extra.comment="Dromocob Ultra Carousel Card";extra.threeDLayer=true;cards.push(extra);}
            while(cards.length>wanted){cards[cards.length-1].remove();cards.pop();}
            setControl(ctrl,"Card Count",wanted);applyCardExpressions(cards);try{target.motionBlur=bool(payload.motionBlur);}catch(_){}if(bool(payload.autoCamera))ensureCamera(target,ctrl);
            return response(true,"Carousel controller değerleri ve kart sayısı yerinde güncellendi.",{count:cards.length});
        }finally{app.endUndoGroup();}
    }
    function createCamera(payload){var target=comp();app.beginUndoGroup("Dromocob Ultra - Carousel");try{var ctrl=ensureController(target,payload);ensureCamera(target,ctrl);return response(true,"DROMOCOB_CAROUSEL_CAMERA oluşturuldu ve Active Card'a bağlandı.");}finally{app.endUndoGroup();}}
    function replace(payload){
        var target=comp(),file=new File(String(payload.path||""));if(!file.exists)throw new Error("Medya dosyası bulunamadı.");
        app.beginUndoGroup("Dromocob Ultra - Carousel");try{var footage=app.project.importFile(new ImportOptions(file)),targets=[],selected=target.selectedLayers;for(var i=0;i<selected.length;i++)if(selected[i].name.indexOf(CARD_PREFIX)===0)targets.push(selected[i]);if(!targets.length){var ctrl=getLayer(target,CTRL),active=ctrl?Math.round(effect(ctrl,"Active Card").property(1).value):1,card=getLayer(target,CARD_PREFIX+pad(active));if(card)targets.push(card);}if(!targets.length)throw new Error("Değiştirilecek carousel kartını seç.");for(i=0;i<targets.length;i++)targets[i].replaceSource(footage,false);return response(true,targets.length+" kart medyası değiştirildi.");}finally{app.endUndoGroup();}
    }
    function remove(){var target=comp();app.beginUndoGroup("Dromocob Ultra - Carousel");try{var cards=cardLayers(target),count=cards.length;for(var i=0;i<cards.length;i++)cards[i].remove();var camera=getLayer(target,CAMERA);if(camera)camera.remove();var ctrl=getLayer(target,CTRL);if(ctrl)ctrl.remove();return response(true,count+" kart ve carousel controller'ları kaldırıldı.");}finally{app.endUndoGroup();}}

    api.Carousel={create:create,update:update,createCamera:createCamera,replace:replace,remove:remove};
})(Dromocob);
