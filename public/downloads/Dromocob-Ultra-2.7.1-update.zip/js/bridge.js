(function () {
  "use strict";

  function parseResult(raw) {
    if (typeof raw !== "string") return raw;
    try { return JSON.parse(raw); }
    catch (_) { return { ok: false, message: raw || "After Effects yanıt vermedi." }; }
  }

  function evaluate(method, payload) {
    return new Promise(function (resolve) {
      if (!window.__adobe_cep__ || !window.__adobe_cep__.evalScript) {
        resolve({ ok: false, offline: true, message: "CEP köprüsü yalnızca After Effects içinde çalışır." });
        return;
      }

      var payloadText = JSON.stringify(payload || {});
      var expression = "Dromocob.dispatch(" + JSON.stringify(method) + "," + JSON.stringify(payloadText) + ")";
      window.__adobe_cep__.evalScript(expression, function (result) {
        resolve(parseResult(result));
      });
    });
  }

  function openFolderDialog(title) {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) return Promise.resolve(null);
    var result = window.cep.fs.showOpenDialog(false, true, title || "Klasör seç", "", []);
    return Promise.resolve(result && result.data && result.data[0] ? result.data[0] : null);
  }

  function openFileDialog(title, extensions) {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) return Promise.resolve(null);
    var result = window.cep.fs.showOpenDialog(false, false, title || "Dosya seç", "", extensions || []);
    return Promise.resolve(result && result.data && result.data[0] ? result.data[0] : null);
  }

  function extensionPath() {
    try {
      var raw = window.__adobe_cep__.getSystemPath("extension");
      return decodeURI(raw.replace(/^file:\/\//, ""));
    } catch (_) {
      return "";
    }
  }

  function openExternal(url) {
    if (!/^https:\/\//i.test(String(url || ""))) return false;
    try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return true; } } catch (_) {}
    try { window.open(url, "_blank"); return true; } catch (_) { return false; }
  }

  window.DromocobBridge = {
    call: evaluate,
    openFolder: openFolderDialog,
    openFile: openFileDialog,
    openExternal: openExternal,
    extensionPath: extensionPath,
    isHost: function () { return Boolean(window.__adobe_cep__); }
  };
})();
