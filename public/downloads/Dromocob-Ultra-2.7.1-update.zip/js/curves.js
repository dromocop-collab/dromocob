(function () {
  "use strict";

  var presets = [
    { name: "Dromocob Smooth", value: [0.20, 0.20, 0.80, 0.80] },
    { name: "Fast Out", value: [0.10, 0.72, 0.28, 1.00] },
    { name: "Fast In", value: [0.72, 0.00, 0.90, 0.28] },
    { name: "Cinematic", value: [0.16, 1.00, 0.30, 1.00] },
    { name: "Linear", value: [0.00, 0.00, 1.00, 1.00] },
    { name: "Soft Landing", value: [0.22, 0.78, 0.36, 1.00] },
    { name: "Power Launch", value: [0.64, 0.00, 0.78, 0.25] },
    { name: "Snap", value: [0.14, 0.90, 0.22, 1.00] },
    { name: "Luxury", value: [0.65, 0.00, 0.18, 1.00] },
    { name: "Balanced", value: [0.42, 0.00, 0.58, 1.00] }
  ];

  try {
    var savedPresets = JSON.parse(localStorage.getItem("dromocob.curvePresets") || "[]");
    if (savedPresets && savedPresets.length) presets = presets.concat(savedPresets);
  } catch (_) {}

  var value = presets[0].value.slice();
  var canvas;
  var context;
  var pixelRatio = 1;
  var dragPoint = 0;
  var animationFrame = 0;
  var lastPresetFrame = 0;

  function bezierPoint(t, p0, p1, p2, p3) {
    var u = 1 - t;
    return u*u*u*p0 + 3*u*u*t*p1 + 3*u*t*t*p2 + t*t*t*p3;
  }

  function fitCanvas(target) {
    var rect = target.getBoundingClientRect();
    pixelRatio = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    target.width = Math.round(rect.width * pixelRatio);
    target.height = Math.round(rect.height * pixelRatio);
    var ctx = target.getContext("2d");
    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    return { ctx: ctx, width: rect.width, height: rect.height };
  }

  function drawGrid(ctx, width, height, padding) {
    ctx.clearRect(0, 0, width, height);
    ctx.strokeStyle = "rgba(255,255,255,.065)";
    ctx.lineWidth = 1;
    for (var i = 0; i <= 4; i++) {
      var x = padding + (width - padding * 2) * i / 4;
      var y = padding + (height - padding * 2) * i / 4;
      ctx.beginPath(); ctx.moveTo(x, padding); ctx.lineTo(x, height - padding); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(padding, y); ctx.lineTo(width - padding, y); ctx.stroke();
    }
  }

  function coordinates(v, width, height, padding) {
    return {
      start: [padding, height - padding],
      first: [padding + v[0] * (width - padding * 2), height - padding - v[1] * (height - padding * 2)],
      second: [padding + v[2] * (width - padding * 2), height - padding - v[3] * (height - padding * 2)],
      end: [width - padding, padding]
    };
  }

  function strokeCurve(ctx, points, width, height, phase, compact) {
    var gradient = ctx.createLinearGradient(0, height, width, 0);
    gradient.addColorStop(0, "#107cf0");
    gradient.addColorStop(.55, "#18d5ff");
    gradient.addColorStop(1, "#eefaff");

    ctx.save();
    ctx.shadowColor = "rgba(17,140,255,.9)";
    ctx.shadowBlur = compact ? 11 : 18;
    ctx.strokeStyle = "rgba(17,140,255,.2)";
    ctx.lineWidth = compact ? 8 : 12;
    ctx.beginPath();
    ctx.moveTo(points.start[0], points.start[1]);
    ctx.bezierCurveTo(points.first[0], points.first[1], points.second[0], points.second[1], points.end[0], points.end[1]);
    ctx.stroke();
    ctx.shadowBlur = compact ? 6 : 10;
    ctx.strokeStyle = gradient;
    ctx.lineWidth = compact ? 3 : 4;
    ctx.setLineDash(compact ? [1000] : [7, 0]);
    ctx.lineDashOffset = -phase;
    ctx.stroke();
    ctx.restore();
  }

  function drawHandles(ctx, points, compact, phase) {
    ctx.save();
    ctx.setLineDash([4, 5]);
    ctx.strokeStyle = "rgba(120,174,220,.35)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(points.start[0], points.start[1]); ctx.lineTo(points.first[0], points.first[1]); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(points.end[0], points.end[1]); ctx.lineTo(points.second[0], points.second[1]); ctx.stroke();
    ctx.setLineDash([]);
    var nodes = compact ? [points.start, points.end] : [points.start, points.first, points.second, points.end];
    for (var i = 0; i < nodes.length; i++) {
      var radius = compact ? 3 : (i === 0 || i === nodes.length - 1 ? 4 : 8);
      ctx.beginPath(); ctx.arc(nodes[i][0], nodes[i][1], radius, 0, Math.PI * 2);
      ctx.fillStyle = (i === 1 || i === 2) && !compact ? "#15c8ff" : "#dff8ff";
      ctx.shadowColor = "#118cff"; ctx.shadowBlur = compact ? 8 : 14 + Math.sin(phase / 18) * 3; ctx.fill();
      ctx.shadowBlur = 0;
    }
    ctx.restore();
  }

  function drawEditor(time) {
    if (!canvas) return;
    var size = fitCanvas(canvas);
    var padding = 22;
    var points = coordinates(value, size.width, size.height, padding);
    drawGrid(size.ctx, size.width, size.height, padding);
    strokeCurve(size.ctx, points, size.width, size.height, time / 24, false);
    drawHandles(size.ctx, points, false, time / 24);
    if (time - lastPresetFrame > 45 && document.getElementById("curves").classList.contains("active")) {
      document.querySelectorAll(".curve-card canvas").forEach(function (presetCanvas) {
        var presetIndex = Number(presetCanvas.getAttribute("data-preset-index"));
        if (presets[presetIndex]) drawPreset(presetCanvas, presets[presetIndex], time / 28 + presetIndex * 7);
      });
      lastPresetFrame = time;
    }
    animationFrame = requestAnimationFrame(drawEditor);
  }

  function drawPreset(target, preset, phase) {
    var size = fitCanvas(target);
    var padding = 18;
    var points = coordinates(preset.value, size.width, size.height, padding);
    drawGrid(size.ctx, size.width, size.height, padding);
    strokeCurve(size.ctx, points, size.width, size.height, phase, true);
    drawHandles(size.ctx, points, true, phase);
  }

  function renderPresets() {
    var container = document.getElementById("curvePresets");
    container.innerHTML = "";
    presets.forEach(function (preset, index) {
      var card = document.createElement("button");
      card.className = "curve-card" + (index === 0 ? " active" : "");
      card.innerHTML = '<canvas data-preset-index="' + index + '"></canvas><span class="curve-name">' + preset.name.toUpperCase() + "</span>";
      card.addEventListener("click", function () {
        value = preset.value.slice();
        document.querySelectorAll(".curve-card").forEach(function (item) { item.classList.remove("active"); });
        card.classList.add("active");
        updateCode();
      });
      container.appendChild(card);
      drawPreset(card.querySelector("canvas"), preset, index * 6);
    });
  }

  function updateCode() {
    document.getElementById("bezierCode").textContent = value.map(function (part) { return part.toFixed(2); }).join(", ");
  }

  function pointerPosition(event) {
    var rect = canvas.getBoundingClientRect();
    var padding = 22;
    return [
      Math.max(0, Math.min(1, (event.clientX - rect.left - padding) / (rect.width - padding * 2))),
      Math.max(0, Math.min(1, 1 - (event.clientY - rect.top - padding) / (rect.height - padding * 2)))
    ];
  }

  function beginDrag(event) {
    var position = pointerPosition(event);
    var distanceOne = Math.hypot(position[0] - value[0], position[1] - value[1]);
    var distanceTwo = Math.hypot(position[0] - value[2], position[1] - value[3]);
    dragPoint = distanceOne < distanceTwo ? 1 : 2;
    moveDrag(event);
  }

  function moveDrag(event) {
    if (!dragPoint) return;
    var position = pointerPosition(event);
    if (dragPoint === 1) { value[0] = position[0]; value[1] = position[1]; }
    else { value[2] = position[0]; value[3] = position[1]; }
    updateCode();
  }

  function setValue(next) {
    if (!next || next.length !== 4) return false;
    var parsed = next.map(Number);
    if (parsed.some(function (part) { return !isFinite(part); })) return false;
    value = parsed.map(function (part) { return Math.max(0, Math.min(1, part)); });
    updateCode();
    return true;
  }

  function init() {
    canvas = document.getElementById("curveCanvas");
    context = canvas.getContext("2d");
    renderPresets();
    updateCode();
    canvas.addEventListener("mousedown", beginDrag);
    window.addEventListener("mousemove", moveDrag);
    window.addEventListener("mouseup", function () { dragPoint = 0; });
    window.addEventListener("resize", renderPresets);
    cancelAnimationFrame(animationFrame);
    animationFrame = requestAnimationFrame(drawEditor);
  }

  window.CurveStudio = {
    init: init,
    getValue: function () { return value.slice(); },
    setValue: setValue,
    reset: function () { setValue(presets[0].value); },
    addPreset: function (name) {
      if (!name) return false;
      var preset = { name: name, value: value.slice() };
      presets.push(preset);
      var custom = [];
      try { custom = JSON.parse(localStorage.getItem("dromocob.curvePresets") || "[]"); } catch (_) {}
      custom.push(preset);
      localStorage.setItem("dromocob.curvePresets", JSON.stringify(custom));
      renderPresets();
      return true;
    }
  };
})();
