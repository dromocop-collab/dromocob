(function () {
  "use strict";

  var TYPES = ["Orbit", "Arc", "Helix", "Tunnel", "Coverflow", "Stack", "Wave", "Cylinder", "Focus Rail", "Infinite Conveyor"];
  var TYPE_NAMES = { "Orbit":"Yörünge", "Arc":"Yay", "Helix":"Sarmal", "Tunnel":"Tünel", "Coverflow":"Kapak Akışı", "Stack":"Kart Destesi", "Wave":"Dalga", "Cylinder":"Silindir", "Focus Rail":"Odak Rayı", "Infinite Conveyor":"Sonsuz Bant" };
  var TYPE_META = {
    "Orbit": ["360° halka", "Kartlar merkezin çevresinde döner"], "Arc": ["Sinematik yay", "Kontrollü kavis üzerinde odak"],
    "Helix": ["Spiral derinlik", "Dikey akış ve güçlü perspektif"], "Tunnel": ["Sonsuz tünel", "Kameraya doğru derinlik hareketi"],
    "Coverflow": ["Premium galeri", "Merkez kartı güçlü biçimde vurgular"], "Stack": ["Katmanlı deste", "Kompakt ürün ve hikâye sunumu"],
    "Wave": ["Organik dalga", "Akıcı ve ritmik kart koreografisi"], "Cylinder": ["3D silindir", "Kesintisiz çevresel medya duvarı"],
    "Focus Rail": ["Odak rayı", "Aktif karta sinematik yaklaşım"], "Infinite Conveyor": ["Sonsuz bant", "Atlama olmadan sürekli döngü akışı"]
  };
  var GROUPS = [
    { title: "YERLEŞİM", icon: "⌗", fields: [
      ["cardCount", "Kart Sayısı", "number", 8, 1, 100, 1], ["radius", "Yarıçap", "number", 720, 0, 10000, 10],
      ["spacing", "Kart Aralığı", "number", 320, 0, 4000, 10], ["cardScale", "Kart Ölçeği", "number", 72, 1, 500, 1],
      ["cardWidth", "Kart Genişliği", "number", 640, 10, 8000, 10], ["cardHeight", "Kart Yüksekliği", "number", 900, 10, 8000, 10],
      ["depth", "Derinlik", "number", 420, -5000, 5000, 10], ["arcAmount", "Yay Miktarı", "number", 180, -720, 720, 5],
      ["rotationOffset", "Dönüş Başlangıcı", "number", 0, -3600, 3600, 1], ["verticalOffset", "Dikey Konum", "number", 120, -4000, 4000, 10],
      ["perspective", "Perspektif", "number", 1000, 1, 10000, 10], ["randomness", "Rastlantısallık", "number", 0, 0, 100, 1]
    ]},
    { title: "ANİMASYON", icon: "↯", fields: [
      ["duration", "Süre", "number", 4, .1, 300, .1], ["speed", "Hız", "number", 1, -20, 20, .1],
      ["direction", "Yön", "select", 1, [[1,"İleri"],[-1,"Geri"]]], ["stagger", "Kart Gecikmesi", "number", .06, 0, 10, .01],
      ["startOffset", "Başlangıç Konumu", "number", 0, -1000, 1000, .1], ["ease", "Hareket Eğrisi", "select", "luxury", [["luxury","Lüks Akış"],["smooth","Yumuşak"],["snap","Teknolojik Keskin"],["linear","Doğrusal"]]],
      ["overshoot", "Taşma", "number", 8, 0, 100, 1], ["motionBlur", "Hareket Bulanıklığı", "checkbox", true],
      ["infiniteLoop", "Sonsuz Döngü", "checkbox", false]
    ]},
    { title: "ODAK", icon: "◎", fields: [
      ["activeCard", "Aktif Kart", "number", 1, 1, 100, .01], ["focusScale", "Odak Ölçeği", "number", 115, 1, 500, 1],
      ["inactiveScale", "Pasif Kart Ölçeği", "number", 82, 1, 500, 1], ["focusDepth", "Odak Derinliği", "number", 160, -3000, 3000, 10],
      ["autoRotate", "Otomatik Döndür", "checkbox", false], ["snapToCard", "Karta Kilitlen", "checkbox", true]
    ]},
    { title: "KAMERA", icon: "◈", fields: [
      ["autoCamera", "Otomatik Kamera", "checkbox", true], ["cameraDistance", "Kamera Uzaklığı", "number", 1800, 1, 30000, 10],
      ["cameraHeight", "Kamera Yüksekliği", "number", 0, -10000, 10000, 10], ["focalLength", "Odak Uzaklığı", "number", 50, 5, 500, 1],
      ["depthOfField", "Alan Derinliği", "checkbox", false], ["aperture", "Diyafram", "number", 80, 0, 1000, 1],
      ["focusFollow", "Odağı Takip Et", "checkbox", true]
    ]}
  ];
  var PRESETS = {
    "Luxury Smooth": { radius: 760, spacing: 330, cardScale: 76, depth: 460, duration: 5, speed: .7, stagger: .08, ease: "luxury", overshoot: 4, focusScale: 112, inactiveScale: 86, focalLength: 65 },
    "Dynamic Commercial": { radius: 640, spacing: 360, cardScale: 82, depth: 520, duration: 2.5, speed: 1.35, stagger: .035, ease: "smooth", overshoot: 14, focusScale: 124, inactiveScale: 78, focalLength: 42 },
    "Cinematic Float": { radius: 900, spacing: 380, cardScale: 68, depth: 620, duration: 7, speed: .45, stagger: .12, ease: "luxury", overshoot: 3, focusScale: 108, inactiveScale: 88, focalLength: 85, depthOfField: true, aperture: 110 },
    "Tech Snap": { radius: 620, spacing: 300, cardScale: 78, depth: 380, duration: 1.4, speed: 1.8, stagger: .02, ease: "snap", overshoot: 18, focusScale: 118, inactiveScale: 72, focalLength: 35, snapToCard: true },
    "Social Reel": { radius: 520, spacing: 255, cardScale: 72, cardWidth: 760, cardHeight: 1040, depth: 340, duration: 2.2, speed: 1.1, focusScale: 116, inactiveScale: 80, cameraDistance: 1650, focalLength: 45 },
    "Product Showcase": { radius: 820, spacing: 410, cardScale: 74, depth: 680, duration: 4.5, speed: .65, focusScale: 122, inactiveScale: 74, focusDepth: 220, cameraDistance: 2100, focalLength: 70, depthOfField: true, aperture: 90 }
  };
  var currentType = "Orbit", currentLayout = "auto";

  function fieldMarkup(field) {
    var id = "carousel-" + field[0], type = field[2], html = '<label class="carousel-field"><span>' + field[1] + '</span>';
    if (type === "checkbox") html += '<input id="' + id + '" type="checkbox"' + (field[3] ? " checked" : "") + '><i class="mini-toggle"></i>';
    else if (type === "select") { html += '<select id="' + id + '">'; field[4].forEach(function (option) { html += '<option value="' + option[0] + '"' + (option[0] === field[3] ? " selected" : "") + '>' + option[1] + '</option>'; }); html += '</select>'; }
    else html += '<input id="' + id + '" type="number" value="' + field[3] + '" min="' + field[4] + '" max="' + field[5] + '" step="' + field[6] + '">';
    return html + '</label>';
  }
  function renderControls() {
    var root = document.getElementById("carouselControls"); root.innerHTML = "";
    GROUPS.forEach(function (group, index) {
      var section = document.createElement("section"); section.className = "carousel-group glass-card" + (index === 0 ? " open" : "");
      section.innerHTML = '<button class="carousel-group-head"><b>' + group.icon + '</b><span>' + group.title + '</span><i>⌄</i></button><div class="carousel-fields">' + group.fields.map(fieldMarkup).join("") + '</div>';
      section.querySelector(".carousel-group-head").onclick = function () { section.classList.toggle("open"); };
      root.appendChild(section);
    });
  }
  function renderTypes() {
    var root = document.getElementById("carouselTypes");
    root.innerHTML = "";
    TYPES.forEach(function (type, index) {
      var key = type.toLowerCase().replace(/\s/g,"-");
      var button = document.createElement("button");
      button.className = "carousel-type-card" + (type === currentType ? " active" : "");
      button.dataset.type = type;
      button.innerHTML = '<span class="type-index">' + (index < 9 ? "0" : "") + (index + 1) + '</span><div class="type-visual" data-shape="' + key + '"><i></i><i></i><i></i><i></i><i></i><i></i><em></em></div><div class="type-copy"><strong>' + TYPE_NAMES[type] + '</strong><small>' + type + ' • ' + TYPE_META[type][0] + '</small><p>' + TYPE_META[type][1] + '</p></div><b class="type-live">CANLI</b>';
      button.onclick = function () {
        currentType = type;
        root.querySelectorAll("button").forEach(function (b) { b.classList.toggle("active", b === button); });
        document.getElementById("carouselPreview").dataset.type = key;
        document.getElementById("carouselPreviewLabel").textContent = TYPE_NAMES[type].toUpperCase();
      };
      root.appendChild(button);
    });
  }
  function renderPresets() {
    var root = document.getElementById("carouselPresets");
    var presetNames = ["Lüks Akış", "Dinamik Reklam", "Sinematik Süzülme", "Teknolojik Keskinlik", "Sosyal Medya", "Ürün Vitrini"];
    Object.keys(PRESETS).forEach(function (name, index) { var button = document.createElement("button"); button.className = "carousel-preset"; button.innerHTML = '<b>0' + (index + 1) + '</b><strong>' + presetNames[index] + '</strong><small>' + ["Premium akış", "Reklam enerjisi", "Yavaş atmosfer", "Keskin teknoloji", "Dikey sosyal", "Ürün odaklı"][index] + '</small>'; button.onclick = function () { setValues(PRESETS[name]); DromocobApp.toast(presetNames[index] + " hazır ayarı yüklendi."); }; root.appendChild(button); });
  }
  function getField(name) { return document.getElementById("carousel-" + name); }
  function values() {
    var output = { type: currentType, layoutMode: currentLayout };
    GROUPS.forEach(function (group) { group.fields.forEach(function (field) { var el = getField(field[0]); output[field[0]] = field[2] === "checkbox" ? el.checked : field[2] === "number" ? Number(el.value) : el.value; }); });
    return output;
  }
  function setValues(data) { Object.keys(data).forEach(function (key) { var el = getField(key); if (!el) return; if (el.type === "checkbox") el.checked = Boolean(data[key]); else el.value = data[key]; }); }
  function defaults() { var data = {}; GROUPS.forEach(function (g) { g.fields.forEach(function (f) { data[f[0]] = f[3]; }); }); return data; }
  function autoLayout(mode) {
    return DromocobBridge.call("context", {}).then(function (context) {
      var portrait = mode === "reel" || (mode === "auto" && context.height > context.width);
      setValues(portrait ? { radius: 500, spacing: 250, cardScale: 68, cardWidth: 760, cardHeight: 1080, depth: 360, cameraDistance: 1700, focalLength: 45, verticalOffset: 90 } : { radius: 820, spacing: 390, cardScale: 74, cardWidth: 720, cardHeight: 900, depth: 540, cameraDistance: 2200, focalLength: 60, verticalOffset: 120 });
      return context;
    });
  }
  function call(method, extra) {
    if (window.DromocobLicense && !DromocobLicense.canUse()) { document.querySelector('[data-page="license"]').click(); DromocobApp.toast("3D Döngü Laboratuvarı için aktif lisans veya deneme gerekli.", true); return Promise.resolve(); }
    var payload = values(); Object.keys(extra || {}).forEach(function (key) { payload[key] = extra[key]; });
    document.getElementById("carouselStatus").textContent = "İŞLENİYOR";
    return DromocobBridge.call(method, payload).then(function (result) { document.getElementById("carouselStatus").textContent = result.ok ? "AKTİF" : "HATA"; DromocobApp.toast(result.message || "3D döngü işlemi tamamlandı.", !result.ok); return result; });
  }
  function bind() {
    document.querySelectorAll("[data-carousel-layout]").forEach(function (button) { button.onclick = function () { currentLayout = button.dataset.carouselLayout; document.querySelectorAll("[data-carousel-layout]").forEach(function (b) { b.classList.toggle("active", b === button); }); autoLayout(currentLayout); }; });
    document.getElementById("carouselCreate").onclick = function () { call("carouselCreate"); };
    document.getElementById("carouselUpdate").onclick = function () { call("carouselUpdate"); };
    document.getElementById("carouselFill").onclick = function () { call("carouselCreate", { fillSelected: true }); };
    document.getElementById("carouselReplace").onclick = function () { DromocobBridge.openFile("Yeni medya seç", ["*.png","*.jpg","*.jpeg","*.webp","*.mov","*.mp4"]).then(function (path) { if (path) call("carouselReplace", { path: path }); }); };
    document.getElementById("carouselCamera").onclick = function () { call("carouselCamera"); };
    document.getElementById("carouselReverse").onclick = function () { var direction = getField("direction"); direction.value = Number(direction.value) > 0 ? -1 : 1; call("carouselUpdate"); };
    document.getElementById("carouselRandomize").onclick = function () { setValues({ rotationOffset: Math.round(Math.random() * 360), randomness: 8 + Math.round(Math.random() * 32), activeCard: 1 + Math.round(Math.random() * Math.max(1, Number(getField("cardCount").value) - 1)) }); call("carouselUpdate"); };
    document.getElementById("carouselReset").onclick = function () { currentType = "Orbit"; setValues(defaults()); document.querySelectorAll("#carouselTypes button").forEach(function (b) { b.classList.toggle("active", b.dataset.type === "Orbit"); }); document.getElementById("carouselPreview").dataset.type = "orbit"; document.getElementById("carouselPreviewLabel").textContent = "YÖRÜNGE"; call("carouselUpdate"); };
    document.getElementById("carouselRemove").onclick = function () { call("carouselRemove"); };
  }
  function init() { renderTypes(); renderControls(); renderPresets(); bind(); autoLayout("auto").catch(function () {}); }
  window.CarouselLab = { init: init, values: values, setValues: setValues };
})();
