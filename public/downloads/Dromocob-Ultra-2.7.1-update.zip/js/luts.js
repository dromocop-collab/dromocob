(function () {
  "use strict";

  var allLuts = [];
  var selectedPath = "";
  var folderPath = localStorage.getItem("dromocob.lutFolder") || "";
  var filter = "all";
  var favorites = {};
  var builtInFiles = [
    ["Dromocob Clean", "Dromocob_Clean.cube"],
    ["Dromocob Warm Film", "Dromocob_Warm_Film.cube"],
    ["Dromocob Teal Orange", "Dromocob_Teal_Orange.cube"],
    ["Dromocob Cool Fade", "Dromocob_Cool_Fade.cube"],
    ["Dromocob Mono Punch", "Dromocob_Mono_Punch.cube"],
    ["Dromocob Night Blue", "Dromocob_Night_Blue.cube"]
  ];

  try { favorites = JSON.parse(localStorage.getItem("dromocob.lutFavorites") || "{}"); }
  catch (_) { favorites = {}; }

  function nodeModule(name) {
    try {
      if (window.cep_node && window.cep_node.require) return window.cep_node.require(name);
      if (window.require) return window.require(name);
    } catch (_) {}
    return null;
  }

  function extensionOf(name) {
    var match = name.toLowerCase().match(/\.([^.]+)$/);
    return match ? match[1] : "";
  }

  function scanWithNode(root) {
    var fs = nodeModule("fs");
    var pathModule = nodeModule("path");
    if (!fs || !pathModule) return [];
    var output = [];

    function walk(directory) {
      var entries;
      try { entries = fs.readdirSync(directory); }
      catch (_) { return; }
      entries.forEach(function (entry) {
        var absolute = pathModule.join(directory, entry);
        var stat;
        try { stat = fs.statSync(absolute); }
        catch (_) { return; }
        if (stat.isDirectory()) walk(absolute);
        else if (/\.(cube|3dl|look|csp)$/i.test(entry)) {
          output.push({ path: absolute, name: entry.replace(/\.[^.]+$/, ""), ext: extensionOf(entry) });
        }
      });
    }

    walk(root);
    return output;
  }

  function builtIns() {
    var root = DromocobBridge.extensionPath();
    return builtInFiles.map(function (item) {
      return { path: root + "/assets/luts/" + item[1], name: item[0], ext: "cube", builtIn: true };
    });
  }

  function hash(text) {
    var result = 0;
    for (var i = 0; i < text.length; i++) result = ((result << 5) - result) + text.charCodeAt(i) | 0;
    return Math.abs(result);
  }

  function gradientFor(name) {
    var seed = hash(name);
    var hueOne = seed % 360;
    var hueTwo = (hueOne + 48 + seed % 90) % 360;
    var hueThree = (hueTwo + 110) % 360;
    return "linear-gradient(135deg,hsl(" + hueOne + ",48%,16%),hsl(" + hueTwo + ",78%,52%) 54%,hsl(" + hueThree + ",62%,23%))";
  }

  function visibleLuts() {
    var query = document.getElementById("lutSearch").value.trim().toLowerCase();
    return allLuts.filter(function (lut) {
      var matchesQuery = !query || lut.name.toLowerCase().indexOf(query) !== -1;
      var matchesFilter = filter === "all" || (filter === "favorites" ? favorites[lut.path] : lut.ext === filter);
      return matchesQuery && matchesFilter;
    });
  }

  function render() {
    var grid = document.getElementById("lutGrid");
    var results = visibleLuts();
    grid.innerHTML = "";
    document.getElementById("lutCount").textContent = allLuts.length ? results.length + " / " + allLuts.length + " LUT" : "LUT bulunamadı";
    document.getElementById("lutFolderName").textContent = folderPath ? folderPath.split(/[\\/]/).pop() : "—";

    if (!results.length) {
      grid.innerHTML = '<div class="empty-state"><b>◐</b><strong>' + (folderPath ? "Eşleşen LUT bulunamadı" : "LUT arşivini bağla") + '</strong><small>.cube, .3dl, .look ve .csp desteklenir</small></div>';
      return;
    }

    results.forEach(function (lut) {
      var card = document.createElement("div");
      card.className = "lut-card" + (selectedPath === lut.path ? " selected" : "");
      card.setAttribute("role", "button");
      card.tabIndex = 0;
      card.style.setProperty("--lut-gradient", gradientFor(lut.name));
      card.innerHTML = '<div class="lut-preview"></div><div class="lut-info"><strong>' + escapeText(lut.name) + '</strong><small>' + (lut.builtIn ? "DROMOCOB • " : "") + lut.ext + '</small></div><button class="favorite ' + (favorites[lut.path] ? "on" : "") + '" title="Favori">◆</button>';
      card.addEventListener("click", function (event) {
        if (event.target.classList.contains("favorite")) return;
        selectedPath = lut.path;
        render();
      });
      card.addEventListener("dblclick", function () {
        selectedPath = lut.path;
        document.getElementById("applySelectedLut").click();
      });
      card.querySelector(".favorite").addEventListener("click", function (event) {
        event.stopPropagation();
        if (favorites[lut.path]) delete favorites[lut.path]; else favorites[lut.path] = true;
        localStorage.setItem("dromocob.lutFavorites", JSON.stringify(favorites));
        render();
      });
      grid.appendChild(card);
    });
  }

  function escapeText(text) {
    return text.replace(/[&<>"']/g, function (character) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character];
    });
  }

  function loadFolder(path) {
    folderPath = path || folderPath;
    if (!folderPath) return false;
    allLuts = builtIns().concat(scanWithNode(folderPath)).sort(function (a, b) { return a.name.localeCompare(b.name); });
    selectedPath = allLuts.length ? allLuts[0].path : "";
    localStorage.setItem("dromocob.lutFolder", folderPath);
    render();
    return true;
  }

  function init() {
    document.getElementById("lutSearch").addEventListener("input", render);
    document.querySelectorAll("#lutFilters button").forEach(function (button) {
      button.addEventListener("click", function () {
        document.querySelectorAll("#lutFilters button").forEach(function (item) { item.classList.remove("active"); });
        button.classList.add("active");
        filter = button.dataset.filter;
        render();
      });
    });

    document.getElementById("chooseLutFolder").addEventListener("click", function () {
      DromocobBridge.openFolder("LUT arşivini seç").then(function (path) {
        if (path) {
          loadFolder(path);
          window.DromocobApp.toast(allLuts.length + " LUT tarandı.");
        }
      });
    });
    document.getElementById("refreshLuts").addEventListener("click", function () {
      if (!loadFolder()) window.DromocobApp.toast("Önce LUT klasörü seç.", true);
      else window.DromocobApp.toast("LUT kütüphanesi yenilendi.");
    });
    document.getElementById("chooseSingleLut").addEventListener("click", function () {
      DromocobBridge.openFile("LUT dosyası seç", ["*.cube", "*.3dl", "*.look", "*.csp"]).then(function (path) {
        if (!path) return;
        selectedPath = path;
        window.DromocobApp.applyLut(path);
      });
    });
    document.getElementById("applySelectedLut").addEventListener("click", function () {
      if (!selectedPath) { window.DromocobApp.toast("Önce bir LUT seç.", true); return; }
      window.DromocobApp.applyLut(selectedPath);
    });

    var strength = document.getElementById("lutStrength");
    strength.addEventListener("input", function () { strength.nextElementSibling.value = strength.value + "%"; });
    if (folderPath) loadFolder(folderPath);
    else { allLuts = builtIns(); selectedPath = allLuts[0].path; render(); }
  }

  window.LutStudio = {
    init: init,
    selected: function () { return selectedPath; },
    count: function () { return allLuts.length; }
  };
})();
