(function () {
  "use strict";
  var KEY = "dromocob.transitionLibrary.v1";
  function empty() { return { favorites: [], recent: [], saved: [] }; }
  function read() {
    try {
      var data = JSON.parse(localStorage.getItem(KEY));
      if (!data || !Array.isArray(data.favorites) || !Array.isArray(data.recent) || !Array.isArray(data.saved)) return empty();
      data.saved = data.saved.filter(function (x) { return x && typeof x.key === "string" && typeof x.id === "string" && isFinite(x.duration) && x.duration >= 1 && x.duration <= 500 && isFinite(x.intensity) && x.intensity >= 5 && x.intensity <= 100; }).slice(0, 50);
      return data;
    } catch (_) { return empty(); }
  }
  function write(data) { try { localStorage.setItem(KEY, JSON.stringify(data)); return true; } catch (_) { return false; } }
  function key(item) { return item.family + ":" + item.profile + ":" + item.name; }
  window.DromocobLibrary = {
    read: read, key: key,
    favorite: function (id) { var d = read(), n = d.favorites.indexOf(id); if (n < 0) d.favorites.push(id); else d.favorites.splice(n, 1); return write(d); },
    used: function (id) { var d = read(); d.recent = [id].concat(d.recent.filter(function (x) { return x !== id; })).slice(0, 20); return write(d); },
    save: function (item, duration, intensity) { var d = read(); if (d.saved.length >= 50) return false; d.saved.unshift({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8), key: key(item), duration: Math.max(1, Math.min(500, Math.round(Number(duration) || 8))), intensity: Math.max(5, Math.min(100, Number(intensity) || 30)) }); return write(d); },
    remove: function (id) { var d = read(); d.saved = d.saved.filter(function (x) { return x.id !== id; }); return write(d); }
  };
}());
