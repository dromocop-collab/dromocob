#!/bin/zsh
set -e
setopt NULL_GLOB

XROOT="${DROMOCOB_FCP_XCODE_ROOT:-/Users/cihaterdem/Desktop/Dromocob/DromocobUltraFinalCut-Xcode/DromocobUltraFinalCut}"
PROJECT="$XROOT/DromocobUltraFinalCut.xcodeproj"
SCHEME="DromocobUltraFinalCut"

BUILDROOT="/tmp/DromocobUltraFinalCut-0.2.0-Debug"
DEST="/Applications/DromocobUltraFinalCut.app"

pkill -x "Final Cut Pro" 2>/dev/null || true
pkill -x "DromocobUltraFinalCutExtension" 2>/dev/null || true
pkill -x "DromocobUltraFinalCut" 2>/dev/null || true

rm -rf "$BUILDROOT"

cd "$XROOT"

xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Debug \
  -destination "platform=macOS" \
  -derivedDataPath "$BUILDROOT" \
  clean build

APP="$BUILDROOT/Build/Products/Debug/DromocobUltraFinalCut.app"
APPEX="$APP/Contents/PlugIns/DromocobUltraFinalCutExtension.appex"

test -d "$APP"
test -d "$APPEX"

codesign --verify --deep --strict --verbose=2 "$APP"
codesign --verify --strict --verbose=2 "$APPEX"

[[ "$(defaults read "$APP/Contents/Info.plist" CFBundleIdentifier)" == "com.dromocob.ultra.finalcut" ]]
[[ "$(defaults read "$APPEX/Contents/Info.plist" CFBundleIdentifier)" == "com.dromocob.ultra.finalcut.workflow" ]]

if ! codesign -d --entitlements :- "$APPEX" 2>/dev/null \
  | grep -q "com.apple.security.cs.disable-library-validation"; then
  echo "❌ Disable Library Validation entitlement missing"
  exit 1
fi

if [ -d "$DEST/Contents/PlugIns/DromocobUltraFinalCutExtension.appex" ]; then
  pluginkit -r \
    "$DEST/Contents/PlugIns/DromocobUltraFinalCutExtension.appex" \
    2>/dev/null || true
fi

rm -rf "$DEST"
ditto "$APP" "$DEST"

/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
  -f "$DEST"

pluginkit -a \
  "$DEST/Contents/PlugIns/DromocobUltraFinalCutExtension.appex" || true

pluginkit -r "$APPEX" 2>/dev/null || true
rm -rf "$BUILDROOT"

echo
pluginkit -m -A -D -v \
  | grep -i "com.dromocob.ultra.finalcut.workflow" || true

echo
echo "✅ DROMOCOB ULTRA FINAL CUT 0.2.0 INSTALLED"
open "$DEST"
