#!/bin/zsh
set -e
setopt NULL_GLOB

VERSION="${1:-0.2.0}"

XROOT="${DROMOCOB_FCP_XCODE_ROOT:-/Users/cihaterdem/Desktop/Dromocob/DromocobUltraFinalCut-Xcode/DromocobUltraFinalCut}"
PROJECT="$XROOT/DromocobUltraFinalCut.xcodeproj"
SCHEME="DromocobUltraFinalCut"

OUTPUT_ROOT="${DROMOCOB_RELEASE_ROOT:-$HOME/Documents/DromocobUltraReleases/finalcut}"
OUTPUT="$OUTPUT_ROOT/$VERSION"

BUILDROOT="/tmp/DromocobUltraFinalCut-Release-$VERSION"
PUBLIC_BASE="https://dromocob.tr/downloads/finalcut"
ZIP_NAME="DromocobUltraFinalCut-$VERSION.zip"

rm -rf "$BUILDROOT"
rm -rf "$OUTPUT"
mkdir -p "$OUTPUT"

cd "$XROOT"

xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -destination "platform=macOS" \
  -derivedDataPath "$BUILDROOT" \
  clean build

APP="$BUILDROOT/Build/Products/Release/DromocobUltraFinalCut.app"
APPEX="$APP/Contents/PlugIns/DromocobUltraFinalCutExtension.appex"

test -d "$APP"
test -d "$APPEX"

codesign --verify --deep --strict --verbose=2 "$APP"
codesign --verify --strict --verbose=2 "$APPEX"

ditto \
  -c \
  -k \
  --sequesterRsrc \
  --keepParent \
  "$APP" \
  "$OUTPUT/$ZIP_NAME"

SHA="$(shasum -a 256 "$OUTPUT/$ZIP_NAME" | awk '{print $1}')"

PUBLISHED="$(
  date "+%Y-%m-%dT%H:%M:%S%z" \
  | sed -E 's/([+-][0-9]{2})([0-9]{2})$/\1:\2/'
)"

python3 - \
  "$OUTPUT/manifest.json" \
  "$VERSION" \
  "$SHA" \
  "$PUBLIC_BASE/$ZIP_NAME" \
  "$PUBLIC_BASE/$VERSION-notes.html" \
  "$PUBLISHED" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])

manifest = {
    "schemaVersion": 1,
    "productId": "dromocob-ultra-finalcut",
    "platform": "finalcut",
    "channel": "stable",
    "version": sys.argv[2],
    "build": 2,
    "minimumFinalCutVersion": "11.0",
    "minimumMacOSVersion": "14.0",
    "downloadURL": sys.argv[4],
    "notesURL": sys.argv[5],
    "sha256": sys.argv[3],
    "mandatory": False,
    "publishedAt": sys.argv[6],
}

path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8"
)
PY

cp "$OUTPUT/manifest.json" "$OUTPUT_ROOT/manifest.json"

cat > "$OUTPUT/RELEASE-SUMMARY.txt" <<EOF
Dromocob Ultra Final Cut
Version: $VERSION
Artifact: $ZIP_NAME
SHA256: $SHA
Manifest: $OUTPUT/manifest.json

Release Center output:
$OUTPUT_ROOT

Public target:
$PUBLIC_BASE/
EOF

rm -rf "$BUILDROOT"

echo
echo "✅ RELEASE READY"
echo "Artifact: $OUTPUT/$ZIP_NAME"
echo "SHA256  : $SHA"
echo "Manifest: $OUTPUT/manifest.json"
