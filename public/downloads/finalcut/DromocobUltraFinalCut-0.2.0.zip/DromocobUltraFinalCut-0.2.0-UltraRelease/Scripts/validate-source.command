#!/bin/zsh
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

required=(
  "Config/UltraConfig.swift"
  "Sources/Extension/Core/UltraState.swift"
  "Sources/Extension/Host/FinalCutHostAdapter.swift"
  "Sources/Extension/Network/ReleaseCenterClient.swift"
  "Sources/Extension/Network/RequestCenterClient.swift"
  "Sources/Extension/Modules/UltraHomeView.swift"
  "Sources/Extension/Modules/UltraTimelineView.swift"
  "Sources/Extension/Modules/UltraUpdateCenterView.swift"
  "Sources/Extension/Modules/UltraRequestCenterView.swift"
  "Sources/Extension/UltraRootView.swift"
  "Sources/Extension/DromocobUltraFinalCutExtensionViewController.swift"
  "Release/manifest.json"
  "Release/release-center-target.json"
)

for file in "${required[@]}"; do
  test -f "$ROOT/$file"
  echo "✅ $file"
done

python3 -m json.tool "$ROOT/Release/manifest.json" >/dev/null
python3 -m json.tool "$ROOT/Release/release-center-target.json" >/dev/null

grep -q "ProExtensionHostSingleton" \
  "$ROOT/Sources/Extension/Host/FinalCutHostAdapter.swift"

grep -q "FCPXTimelineObserver" \
  "$ROOT/Sources/Extension/Host/FinalCutHostAdapter.swift"

grep -q "movePlayhead" \
  "$ROOT/Sources/Extension/Host/FinalCutHostAdapter.swift"

grep -q "https://dromocob.tr/api/ultra/requests" \
  "$ROOT/Config/UltraConfig.swift"

grep -q "https://dromocob.tr/downloads/finalcut/manifest.json" \
  "$ROOT/Config/UltraConfig.swift"

echo
echo "✅ DROMOCOB ULTRA FINAL CUT 0.2.0 SOURCE READY"
