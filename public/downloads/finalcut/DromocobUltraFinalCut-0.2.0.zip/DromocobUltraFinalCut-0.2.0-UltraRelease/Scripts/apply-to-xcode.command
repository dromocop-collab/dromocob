#!/bin/zsh
set -e
setopt NULL_GLOB

PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
XROOT="${DROMOCOB_FCP_XCODE_ROOT:-/Users/cihaterdem/Desktop/Dromocob/DromocobUltraFinalCut-Xcode/DromocobUltraFinalCut}"

APP="$XROOT/DromocobUltraFinalCut"
EXT="$XROOT/DromocobUltraFinalCutExtension"
PBX="$XROOT/DromocobUltraFinalCut.xcodeproj/project.pbxproj"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/Desktop/DromocobUltra-Source-Backups/finalcut-ultra-0.2.0-$STAMP"

echo "========================================"
echo "DROMOCOB ULTRA FINAL CUT 0.2.0"
echo "APPLY TO XCODE"
echo "========================================"

test -d "$APP"
test -d "$EXT"
test -f "$PBX"

mkdir -p "$BACKUP"
ditto "$XROOT" "$BACKUP/DromocobUltraFinalCut-Xcode"

find "$EXT" -maxdepth 1 -name "Ultra*.swift" -delete

cp "$PACKAGE_ROOT/Config/UltraConfig.swift" "$EXT/UltraConfig.swift"
cp "$PACKAGE_ROOT/Sources/Extension/Core/"*.swift "$EXT/"
cp "$PACKAGE_ROOT/Sources/Extension/Host/"*.swift "$EXT/"
cp "$PACKAGE_ROOT/Sources/Extension/Network/"*.swift "$EXT/"
cp "$PACKAGE_ROOT/Sources/Extension/Shared/"*.swift "$EXT/"
cp "$PACKAGE_ROOT/Sources/Extension/Modules/"*.swift "$EXT/"
cp "$PACKAGE_ROOT/Sources/Extension/UltraRootView.swift" "$EXT/UltraRootView.swift"

cp "$PACKAGE_ROOT/Sources/Extension/DromocobUltraFinalCutExtensionViewController.swift" \
   "$EXT/DromocobUltraFinalCutExtensionViewController.swift"

cp "$PACKAGE_ROOT/Config/UltraConfig.swift" "$APP/UltraConfig.swift"
cp "$PACKAGE_ROOT/Sources/Container/ContentView.swift" "$APP/ContentView.swift"

python3 - "$EXT/DromocobUltraFinalCutExtension.entitlements" <<'PY'
import plistlib
import sys
from pathlib import Path

path = Path(sys.argv[1])

with path.open("rb") as f:
    data = plistlib.load(f)

data["com.apple.security.app-sandbox"] = True
data["com.apple.security.network.client"] = True
data["com.apple.security.cs.disable-library-validation"] = True
data["com.apple.security.automation.apple-events"] = True

data["com.apple.security.scripting-targets"] = {
    "com.apple.FinalCut": [
        "com.apple.FinalCut.library.inspection"
    ],
    "com.apple.FinalCutApp": [
        "com.apple.FinalCut.library.inspection"
    ],
    "com.apple.FinalCutTrial": [
        "com.apple.FinalCut.library.inspection"
    ],
}

with path.open("wb") as f:
    plistlib.dump(data, f, sort_keys=False)

print("✅ Entitlements")
PY

PLIST="$EXT/Info.plist"

/usr/libexec/PlistBuddy \
  -c "Set :NSExtension:NSExtensionPointIdentifier com.apple.FinalCut.WorkflowExtension" \
  "$PLIST"

/usr/libexec/PlistBuddy \
  -c 'Set :NSExtension:ProExtensionPrincipalViewControllerClass $(PRODUCT_MODULE_NAME).DromocobUltraFinalCutExtensionViewController' \
  "$PLIST"

if /usr/libexec/PlistBuddy -c "Print :CFBundleDisplayName" "$PLIST" >/dev/null 2>&1; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Dromocob Ultra" "$PLIST"
else
  /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string Dromocob Ultra" "$PLIST"
fi

python3 - "$PBX" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")

text = text.replace(
    "com.dromocob.ultra.DromocobUltraFinalCut.DromocobUltraFinalCutExtension",
    "com.dromocob.ultra.finalcut.workflow"
)

text = re.sub(
    r'PRODUCT_BUNDLE_IDENTIFIER = com\.dromocob\.ultra\.DromocobUltraFinalCut;',
    'PRODUCT_BUNDLE_IDENTIFIER = com.dromocob.ultra.finalcut;',
    text
)

path.write_text(text, encoding="utf-8")
print("✅ Bundle IDs")
PY

plutil -lint "$EXT/Info.plist"
plutil -lint "$EXT/DromocobUltraFinalCutExtension.entitlements"

echo "✅ Sources applied"
echo "Backup: $BACKUP"
