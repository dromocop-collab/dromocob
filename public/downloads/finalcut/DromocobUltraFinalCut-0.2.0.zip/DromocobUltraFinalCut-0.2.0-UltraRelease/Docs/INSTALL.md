# Dromocob Ultra Final Cut 0.2.0 — Install

Varsayılan çalışan Xcode projesi:

`/Users/cihaterdem/Desktop/Dromocob/DromocobUltraFinalCut-Xcode/DromocobUltraFinalCut`

Sıra:

1. `Scripts/validate-source.command`
2. `Scripts/apply-to-xcode.command`
3. `Scripts/build-debug-install.command`
4. Final Cut Pro:
   `Window → Extensions → Dromocob Ultra`

`apply-to-xcode.command` Apple'ın Workflow Extension template dosyalarını korur ve Ultra Swift kaynaklarını senkronize eder.

Extension bundle:
`com.dromocob.ultra.finalcut.workflow`

Container bundle:
`com.dromocob.ultra.finalcut`

Geliştirme imzalı extension ile Final Cut içindeki host support framework farklı Team ID'lere sahip olduğundan çalışan kurulumda gereken `Disable Library Validation` entitlement'ı korunur.
