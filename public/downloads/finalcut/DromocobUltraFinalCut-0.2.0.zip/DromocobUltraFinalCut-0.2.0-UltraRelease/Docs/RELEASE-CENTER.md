# Release Center Integration

## Runtime Update Center

Manifest:
`https://dromocob.tr/downloads/finalcut/manifest.json`

Desteklenen alanlar:
- productId
- platform
- channel
- version
- build
- minimumFinalCutVersion
- minimumMacOSVersion
- downloadURL
- notesURL
- sha256
- mandatory
- publishedAt

## Release build

`Scripts/build-release.command 0.2.0`

Çıktı:
`~/Documents/DromocobUltraReleases/finalcut/0.2.0`

Latest manifest:
`~/Documents/DromocobUltraReleases/finalcut/manifest.json`

Release Center / deployment tarafının public olarak yayınlaması gerekenler:
- `DromocobUltraFinalCut-<version>.zip`
- `manifest.json`
- opsiyonel release notes HTML

Public hedef:
`https://dromocob.tr/downloads/finalcut/`

Release scripti artifact SHA-256 değerini manifest'e otomatik yazar.

Bu paket deploy token, private key veya secret içermez.
