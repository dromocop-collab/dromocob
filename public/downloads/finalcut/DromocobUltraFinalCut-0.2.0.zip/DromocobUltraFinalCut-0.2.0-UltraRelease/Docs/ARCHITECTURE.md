# Architecture

## Host
- ProExtensionHostSingleton
- FCPXHost
- FCPXTimeline
- FCPXTimelineObserver

## Gerçek Timeline API
- activeSequence
- sequenceTimeRange
- playheadTime
- movePlayhead
- sequence / range / playhead observers
- sequence name
- start time
- duration
- frame duration
- FPS
- ±frame / ±second
- start / end

## Cloud
- Request Center
- Update Center
- release manifest

## Studio modules
- Motion
- Audio
- Color

Workflow Extension API'sinde bulunmayan native editor mutation özellikleri aktifmiş gibi gösterilmez. İleri özellikler desteklenen FxPlug, Motion Template veya FCPXML yüzeyleriyle eklenir.
