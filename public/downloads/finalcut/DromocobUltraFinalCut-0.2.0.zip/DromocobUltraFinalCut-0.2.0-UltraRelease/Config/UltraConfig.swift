import Foundation

enum UltraConfig {
    static let productID = "dromocob-ultra-finalcut"
    static let version = "0.2.0"
    static let build = 2
    static let releaseChannel = "stable"

    static let containerBundleID = "com.dromocob.ultra.finalcut"
    static let extensionBundleID = "com.dromocob.ultra.finalcut.workflow"

    static let requestCenterURL =
        URL(string: "https://dromocob.tr/api/ultra/requests")!

    static let updateManifestURL =
        URL(string: "https://dromocob.tr/downloads/finalcut/manifest.json")!

    static let releaseBaseURL =
        URL(string: "https://dromocob.tr/downloads/finalcut/")!
}
