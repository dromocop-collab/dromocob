import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color.black,
                    Color(red: 0.025, green: 0.060, blue: 0.095)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 18) {
                Image(systemName: "bolt.horizontal.fill")
                    .font(.system(size: 40, weight: .black))
                    .foregroundStyle(.cyan)

                Text("DROMOCOB ULTRA")
                    .font(.system(size: 25, weight: .black))
                    .tracking(2)

                Text("FINAL CUT PRO")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(1.6)
                    .foregroundStyle(.secondary)

                Text("v\(UltraConfig.version) • Release Center Ready")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.cyan)

                Text("Final Cut Pro → Window → Extensions → Dromocob Ultra")
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
            }
            .padding(40)
        }
        .preferredColorScheme(.dark)
    }
}
