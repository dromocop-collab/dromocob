import Foundation
import CoreMedia
import ProExtensionHost

@MainActor
final class FinalCutHostAdapter:
    NSObject,
    FCPXTimelineObserver
{
    private weak var state:
        UltraState?

    private var host:
        FCPXHost?

    private var observing =
        false


    init(
        state: UltraState
    ) {
        self.state =
            state

        super.init()
    }


    func connect() {

        guard
            let resolved =
                ProExtensionHostSingleton()
                    as? FCPXHost
        else {

            state?.applyHost(
                HostSnapshot()
            )

            state?.showToast(
                "Final Cut Pro host proxy bulunamadı.",
                kind:
                    .error
            )

            return
        }


        if observing,
           let previousHost =
                host,
           let previousTimeline =
                previousHost.timeline
        {
            previousTimeline.remove(
                self
            )
        }


        host =
            resolved


        guard
            let timeline =
                resolved.timeline
        else {

            observing =
                false

            var snapshot =
                HostSnapshot()

            snapshot.connected =
                true

            snapshot.hostName =
                resolved.name

            snapshot.hostVersion =
                resolved.versionString

            snapshot.bundleIdentifier =
                resolved.bundleIdentifier

            state?.applyHost(
                snapshot
            )

            state?.showToast(
                "Final Cut timeline proxy henüz hazır değil.",
                kind:
                    .info
            )

            return
        }


        timeline.add(
            self
        )

        observing =
            true


        refresh(
            reason:
                "connect"
        )
    }


    func disconnect() {

        if observing,
           let host,
           let timeline =
                host.timeline
        {
            timeline.remove(
                self
            )
        }


        observing =
            false

        host =
            nil
    }


    func refresh(
        reason: String = "manual"
    ) {

        guard
            let host
        else {

            state?.applyHost(
                HostSnapshot()
            )

            return
        }


        guard
            let timeline =
                host.timeline
        else {

            var snapshot =
                HostSnapshot()

            snapshot.connected =
                true

            snapshot.hostName =
                host.name

            snapshot.hostVersion =
                host.versionString

            snapshot.bundleIdentifier =
                host.bundleIdentifier

            state?.applyHost(
                snapshot
            )

            return
        }


        let sequence =
            timeline.activeSequence

        let playhead =
            timeline.playheadTime()

        let range =
            timeline.sequenceTimeRange


        var snapshot =
            HostSnapshot()


        snapshot.connected =
            true

        snapshot.hostName =
            host.name

        snapshot.hostVersion =
            host.versionString

        snapshot.bundleIdentifier =
            host.bundleIdentifier


        if let sequence {

            snapshot.sequenceAvailable =
                true

            snapshot.sequenceName =
                sequence.name

            snapshot.sequenceStartSeconds =
                sequence.startTime
                    .ultraSeconds

            snapshot.sequenceDurationSeconds =
                sequence.duration
                    .ultraSeconds

            snapshot.frameDurationSeconds =
                sequence.frameDuration
                    .ultraSeconds


            if snapshot.frameDurationSeconds > 0 {

                snapshot.fps =
                    1.0 /
                    snapshot.frameDurationSeconds
            }

        } else {

            snapshot.sequenceAvailable =
                false

            snapshot.sequenceName =
                "NO SEQUENCE"


            if range.isValid {

                snapshot.sequenceStartSeconds =
                    range.start
                        .ultraSeconds

                snapshot.sequenceDurationSeconds =
                    range.duration
                        .ultraSeconds
            }
        }


        if playhead.isValid {

            snapshot.playheadSeconds =
                playhead
                    .ultraSeconds
        }


        state?.applyHost(
            snapshot
        )


        NSLog(
            "[Dromocob Ultra] host refresh %@ • %@ • %@",
            reason,
            snapshot.hostVersion,
            snapshot.sequenceName
        )
    }


    func moveToStart() {

        guard
            state?.host.sequenceAvailable ==
                true
        else {

            state?.showToast(
                "Aktif timeline yok.",
                kind:
                    .error
            )

            return
        }


        movePlayhead(
            toSeconds:
                state?
                    .host
                    .sequenceStartSeconds
                ?? 0
        )
    }


    func moveToEnd() {

        guard
            state?.host.sequenceAvailable ==
                true
        else {

            state?.showToast(
                "Aktif timeline yok.",
                kind:
                    .error
            )

            return
        }


        movePlayhead(
            toSeconds:
                state?
                    .host
                    .sequenceEndSeconds
                ?? 0
        )
    }


    func moveBy(
        seconds delta: Double
    ) {

        guard
            state?.host.sequenceAvailable ==
                true
        else {

            state?.showToast(
                "Aktif timeline yok.",
                kind:
                    .error
            )

            return
        }


        let current =
            state?
                .host
                .playheadSeconds
            ?? 0


        movePlayhead(
            toSeconds:
                current +
                delta
        )
    }


    func moveByFrames(
        _ frames: Int
    ) {

        guard
            let state,
            state
                .host
                .sequenceAvailable,
            state
                .host
                .frameDurationSeconds
                > 0
        else {

            self.state?.showToast(
                "Frame bilgisi hazır değil.",
                kind:
                    .error
            )

            return
        }


        moveBy(
            seconds:
                Double(
                    frames
                )
                *
                state
                    .host
                    .frameDurationSeconds
        )
    }


    func movePlayhead(
        toSeconds requested: Double
    ) {

        guard
            let host
        else {

            state?.showToast(
                "Final Cut bağlantısı hazır değil.",
                kind:
                    .error
            )

            return
        }


        guard
            let timeline =
                host.timeline
        else {

            state?.showToast(
                "Final Cut timeline proxy hazır değil.",
                kind:
                    .error
            )

            return
        }


        let start =
            state?
                .host
                .sequenceStartSeconds
            ?? 0


        let end =
            state?
                .host
                .sequenceEndSeconds
            ?? requested


        let bounded =
            min(
                max(
                    requested,
                    start
                ),
                max(
                    start,
                    end
                )
            )


        let time =
            CMTime(
                seconds:
                    bounded,
                preferredTimescale:
                    600
            )


        _ =
            timeline
                .movePlayhead(
                    to:
                        time
                )


        refresh(
            reason:
                "movePlayhead"
        )
    }


    nonisolated
    func activeSequenceChanged() {

        Task {
            @MainActor
            [weak self] in

            self?.refresh(
                reason:
                    "activeSequenceChanged"
            )
        }
    }


    nonisolated
    func playheadTimeChanged() {

        Task {
            @MainActor
            [weak self] in

            self?.refresh(
                reason:
                    "playheadTimeChanged"
            )
        }
    }


    nonisolated
    func sequenceTimeRangeChanged() {

        Task {
            @MainActor
            [weak self] in

            self?.refresh(
                reason:
                    "sequenceTimeRangeChanged"
            )
        }
    }
}


private extension CMTime {

    var ultraSeconds:
        Double
    {

        guard
            isValid
        else {
            return 0
        }


        let value =
            CMTimeGetSeconds(
                self
            )


        return value.isFinite
            ? value
            : 0
    }
}
