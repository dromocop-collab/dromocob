import SwiftUI

struct UltraStatusBadge: View {
    let connected: Bool

    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(connected ? UltraTheme.success : UltraTheme.danger)
                .frame(width: 7, height: 7)

            Text(connected ? "LIVE" : "OFFLINE")
                .font(.system(size: 9, weight: .black))
                .tracking(1.2)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(.white.opacity(0.045), in: Capsule())
        .overlay(
            Capsule()
                .stroke(.white.opacity(0.09), lineWidth: 1)
        )
    }
}

struct UltraSectionTitle: View {
    let eyebrow: String
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(eyebrow.uppercased())
                .font(.system(size: 9, weight: .black))
                .tracking(1.6)
                .foregroundStyle(UltraTheme.cyan)

            Text(title)
                .font(.system(size: 24, weight: .black, design: .rounded))
                .foregroundStyle(UltraTheme.text)

            if let subtitle {
                Text(subtitle)
                    .font(.system(size: 10))
                    .foregroundStyle(UltraTheme.muted)
            }
        }
    }
}

struct UltraMetric: View {
    let label: String
    let value: String
    var accent: Color = UltraTheme.cyan

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label.uppercased())
                .font(.system(size: 9, weight: .black))
                .tracking(1.2)
                .foregroundStyle(accent)

            Text(value)
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(UltraTheme.text)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .ultraPanel()
    }
}

struct UltraToolCard: View {
    let icon: String
    let title: String
    let subtitle: String
    var enabled = true
    var badge: String? = nil
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(UltraTheme.blue.opacity(0.13))
                        .frame(width: 42, height: 42)

                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(UltraTheme.cyan)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        Text(title)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(UltraTheme.text)

                        if let badge {
                            Text(badge)
                                .font(.system(size: 7, weight: .black))
                                .tracking(0.7)
                                .foregroundStyle(UltraTheme.cyan)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 3)
                                .background(
                                    UltraTheme.blue.opacity(0.11),
                                    in: Capsule()
                                )
                        }
                    }

                    Text(subtitle)
                        .font(.system(size: 9))
                        .foregroundStyle(UltraTheme.muted)
                        .lineLimit(2)
                }

                Spacer()
            }
            .padding(13)
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .opacity(enabled ? 1 : 0.42)
        .ultraPanel(glow: enabled)
    }
}

struct UltraCapabilityCard: View {
    let title: String
    let message: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(title, systemImage: "shield.lefthalf.filled")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(UltraTheme.warning)

            Text(message)
                .font(.system(size: 10))
                .foregroundStyle(UltraTheme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .ultraPanel()
    }
}

struct UltraPrimaryButton: View {
    let title: String
    let icon: String
    var disabled = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.system(size: 11, weight: .black))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
        }
        .buttonStyle(.borderedProminent)
        .tint(UltraTheme.blue)
        .disabled(disabled)
    }
}
