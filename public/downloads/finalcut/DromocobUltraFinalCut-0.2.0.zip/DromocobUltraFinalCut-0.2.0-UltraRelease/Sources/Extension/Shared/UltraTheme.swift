import SwiftUI

enum UltraTheme {
    static let background = Color(red: 0.012, green: 0.017, blue: 0.023)
    static let sidebar = Color(red: 0.006, green: 0.009, blue: 0.013)
    static let panel = Color(red: 0.028, green: 0.041, blue: 0.057)
    static let panelStrong = Color(red: 0.038, green: 0.061, blue: 0.086)

    static let blue = Color(red: 0.067, green: 0.549, blue: 1.000)
    static let cyan = Color(red: 0.082, green: 0.784, blue: 1.000)
    static let success = Color(red: 0.318, green: 0.906, blue: 0.667)
    static let warning = Color(red: 1.000, green: 0.702, blue: 0.302)
    static let danger = Color(red: 1.000, green: 0.314, blue: 0.404)

    static let text = Color.white.opacity(0.96)
    static let muted = Color.white.opacity(0.46)
    static let border = Color.white.opacity(0.075)
    static let borderBlue = blue.opacity(0.26)
}

struct UltraPanelModifier: ViewModifier {
    var glow = false

    func body(content: Content) -> some View {
        content
            .background(
                LinearGradient(
                    colors: [
                        UltraTheme.panelStrong.opacity(0.95),
                        UltraTheme.panel.opacity(0.96)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 18)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 18)
                    .stroke(
                        glow ? UltraTheme.borderBlue : UltraTheme.border,
                        lineWidth: 1
                    )
            )
    }
}

extension View {
    func ultraPanel(glow: Bool = false) -> some View {
        modifier(UltraPanelModifier(glow: glow))
    }
}
