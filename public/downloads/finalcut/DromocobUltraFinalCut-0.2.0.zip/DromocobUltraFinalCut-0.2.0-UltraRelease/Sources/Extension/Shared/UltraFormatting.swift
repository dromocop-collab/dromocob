import Foundation

extension Double {
    var ultraSecondsLabel: String {
        guard isFinite else { return "—" }
        return String(format: "%.2fs", self)
    }

    var ultraFPSLabel: String {
        guard isFinite, self > 0 else { return "—" }
        return String(format: "%.2f", self)
    }

    var ultraTimecodeLike: String {
        guard isFinite else { return "—" }

        let safe = max(0, self)
        let hours = Int(safe / 3600)
        let minutes = Int(safe.truncatingRemainder(dividingBy: 3600) / 60)
        let seconds = Int(safe.truncatingRemainder(dividingBy: 60))
        let millis = Int((safe - floor(safe)) * 1000)

        return String(
            format: "%02d:%02d:%02d.%03d",
            hours,
            minutes,
            seconds,
            millis
        )
    }
}
