import Foundation
import Combine

@MainActor
final class UltraState: ObservableObject {
    @Published var activePage: UltraPage = .home
    @Published var host = HostSnapshot()
    @Published var release = ReleaseState()
    @Published var toast: UltraToast?
    @Published var requestSending = false

    private var toastTask: Task<Void, Never>?

    func applyHost(_ snapshot: HostSnapshot) {
        host = snapshot
    }

    func showToast(
        _ message: String,
        kind: UltraToast.Kind = .success,
        duration: Double = 3.2
    ) {
        toastTask?.cancel()
        toast = UltraToast(message: message, kind: kind)

        toastTask = Task { @MainActor in
            try? await Task.sleep(for: .seconds(duration))
            guard !Task.isCancelled else { return }

            if self.toast?.message == message {
                self.toast = nil
            }
        }
    }

    func checkForUpdates(silent: Bool = false) {
        guard !release.checking else { return }

        release.checking = true
        release.lastError = nil

        Task {
            do {
                let manifest =
                    try await ReleaseCenterClient.shared.fetchManifest()

                let available =
                    SemanticVersion(manifest.version) >
                    SemanticVersion(UltraConfig.version)

                await MainActor.run {
                    self.release.checking = false
                    self.release.latestVersion = manifest.version
                    self.release.updateAvailable = available
                    self.release.downloadURL = URL(string: manifest.downloadURL)
                    self.release.notesURL =
                        manifest.notesURL.flatMap(URL.init(string:))
                    self.release.publishedAt = manifest.publishedAt
                    self.release.mandatory = manifest.mandatory ?? false

                    if !silent {
                        self.showToast(
                            available
                                ? "Yeni sürüm hazır • \(manifest.version)"
                                : "Dromocob Ultra güncel.",
                            kind: available ? .info : .success
                        )
                    }
                }
            } catch {
                await MainActor.run {
                    self.release.checking = false
                    self.release.lastError = error.localizedDescription

                    if !silent {
                        self.showToast(
                            "Update Center • \(error.localizedDescription)",
                            kind: .error,
                            duration: 5
                        )
                    }
                }
            }
        }
    }
}
