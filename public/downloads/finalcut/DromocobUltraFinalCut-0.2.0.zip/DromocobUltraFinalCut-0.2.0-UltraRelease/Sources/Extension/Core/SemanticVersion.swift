import Foundation

struct SemanticVersion: Comparable, Equatable {
    private let parts: [Int]

    init(_ value: String) {
        parts = value
            .split(separator: ".")
            .map { part in
                Int(part.prefix { $0.isNumber }) ?? 0
            }
    }

    static func < (lhs: SemanticVersion, rhs: SemanticVersion) -> Bool {
        let count = max(lhs.parts.count, rhs.parts.count)

        for index in 0..<count {
            let left = index < lhs.parts.count ? lhs.parts[index] : 0
            let right = index < rhs.parts.count ? rhs.parts[index] : 0

            if left != right {
                return left < right
            }
        }

        return false
    }
}
