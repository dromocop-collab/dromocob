import Foundation
import CoreMedia

enum UltraPage: String, CaseIterable, Identifiable {
    case home, timeline, motion, audio, color, updates, request

    var id: String { rawValue }

    var title: String {
        switch self {
        case .home: "Home"
        case .timeline: "Timeline"
        case .motion: "Motion"
        case .audio: "Audio"
        case .color: "Color"
        case .updates: "Update Center"
        case .request: "İstek Merkezi"
        }
    }

    var icon: String {
        switch self {
        case .home: "house.fill"
        case .timeline: "timeline.selection"
        case .motion: "sparkles.rectangle.stack"
        case .audio: "waveform"
        case .color: "circle.lefthalf.filled"
        case .updates: "arrow.triangle.2.circlepath.circle.fill"
        case .request: "paperplane.fill"
        }
    }
}

struct HostSnapshot: Equatable {
    var connected = false
    var hostName = "Final Cut Pro"
    var hostVersion = "—"
    var bundleIdentifier = "—"

    var sequenceAvailable = false
    var sequenceName = "NO SEQUENCE"
    var sequenceStartSeconds: Double = 0
    var sequenceDurationSeconds: Double = 0
    var frameDurationSeconds: Double = 0
    var fps: Double = 0
    var playheadSeconds: Double = 0

    var sequenceEndSeconds: Double {
        sequenceStartSeconds + sequenceDurationSeconds
    }
}

struct UltraToast: Equatable {
    enum Kind { case success, error, info }
    let message: String
    let kind: Kind
}

struct ReleaseState: Equatable {
    var checking = false
    var latestVersion = UltraConfig.version
    var updateAvailable = false
    var downloadURL: URL?
    var notesURL: URL?
    var publishedAt: String?
    var mandatory = false
    var lastError: String?
}

struct ReleaseManifest: Codable, Equatable {
    let schemaVersion: Int?
    let productId: String
    let platform: String?
    let channel: String?
    let version: String
    let build: Int?
    let minimumFinalCutVersion: String?
    let minimumMacOSVersion: String?
    let downloadURL: String
    let notesURL: String?
    let sha256: String?
    let mandatory: Bool?
    let publishedAt: String?
}
