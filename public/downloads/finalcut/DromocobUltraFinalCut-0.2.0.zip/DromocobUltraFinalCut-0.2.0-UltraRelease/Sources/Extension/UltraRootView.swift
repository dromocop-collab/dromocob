import SwiftUI

struct UltraRootView: View {
    @ObservedObject var state: UltraState
    let hostAdapter: FinalCutHostAdapter

    var body: some View {
        ZStack(alignment: .bottom) {
            HStack(spacing: 0) {
                sidebar

                Rectangle()
                    .fill(UltraTheme.blue.opacity(0.22))
                    .frame(width: 1)

                VStack(spacing: 0) {
                    topbar
                    Divider().overlay(UltraTheme.border)

                    content
                        .frame(
                            maxWidth: .infinity,
                            maxHeight: .infinity
                        )
                }
            }

            if let toast = state.toast {
                HStack(spacing: 8) {
                    Image(
                        systemName:
                            toast.kind == .error
                                ? "exclamationmark.triangle.fill"
                                : toast.kind == .info
                                    ? "info.circle.fill"
                                    : "checkmark.circle.fill"
                    )

                    Text(toast.message)
                        .font(.system(size: 10, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(
                    toast.kind == .error
                        ? UltraTheme.danger
                        : toast.kind == .info
                            ? UltraTheme.warning
                            : UltraTheme.blue,
                    in: Capsule()
                )
                .padding(.bottom, 15)
            }
        }
        .background(UltraTheme.background)
        .preferredColorScheme(.dark)
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11)
                        .fill(UltraTheme.blue.opacity(0.15))
                        .frame(width: 42, height: 42)

                    Image(systemName: "bolt.horizontal.fill")
                        .foregroundStyle(UltraTheme.cyan)
                }

                VStack(alignment: .leading, spacing: 1) {
                    Text("DROMOCOB")
                        .font(.system(size: 10, weight: .black))
                        .tracking(1.2)

                    Text("ULTRA FINAL CUT")
                        .font(.system(size: 7, weight: .black))
                        .tracking(0.9)
                        .foregroundStyle(UltraTheme.cyan)
                }
            }
            .padding(.bottom, 8)

            ForEach(UltraPage.allCases) { page in
                Button {
                    state.activePage = page
                } label: {
                    HStack(spacing: 9) {
                        Image(systemName: page.icon)
                            .frame(width: 18)

                        Text(page.title)
                            .font(.system(size: 10, weight: .bold))
                            .lineLimit(1)

                        Spacer()

                        if page == .updates &&
                            state.release.updateAvailable
                        {
                            Circle()
                                .fill(UltraTheme.warning)
                                .frame(width: 6, height: 6)
                        }
                    }
                    .padding(.horizontal, 11)
                    .padding(.vertical, 10)
                    .foregroundStyle(
                        state.activePage == page
                            ? UltraTheme.text
                            : UltraTheme.muted
                    )
                    .background(
                        state.activePage == page
                            ? UltraTheme.blue.opacity(0.14)
                            : Color.clear,
                        in: RoundedRectangle(cornerRadius: 11)
                    )
                }
                .buttonStyle(.plain)
            }

            Spacer()

            UltraStatusBadge(connected: state.host.connected)

            Text("v\(UltraConfig.version)")
                .font(.system(size: 8))
                .foregroundStyle(UltraTheme.muted)
        }
        .padding(13)
        .frame(width: 194)
        .background(UltraTheme.sidebar)
    }

    private var topbar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(state.activePage.title.uppercased())
                    .font(.system(size: 8, weight: .black))
                    .tracking(1.3)
                    .foregroundStyle(UltraTheme.cyan)

                Text(
                    state.host.sequenceAvailable
                        ? state.host.sequenceName
                        : "Dromocob Ultra"
                )
                .font(.system(size: 12, weight: .bold))
                .lineLimit(1)
            }

            Spacer()

            if state.release.updateAvailable {
                Button {
                    state.activePage = .updates
                } label: {
                    Text("UPDATE \(state.release.latestVersion)")
                        .font(.system(size: 8, weight: .black))
                }
                .buttonStyle(.bordered)
                .tint(UltraTheme.warning)
            }

            Text(
                state.host.hostVersion == "—"
                    ? "Final Cut Pro"
                    : "Final Cut Pro \(state.host.hostVersion)"
            )
            .font(.system(size: 9))
            .foregroundStyle(UltraTheme.muted)

            UltraStatusBadge(connected: state.host.connected)
        }
        .padding(.horizontal, 17)
        .frame(height: 64)
        .background(UltraTheme.background)
    }

    @ViewBuilder
    private var content: some View {
        switch state.activePage {
        case .home:
            UltraHomeView(
                state: state,
                refreshHost: {
                    hostAdapter.refresh(reason: "home")
                }
            )

        case .timeline:
            UltraTimelineView(
                state: state,
                moveStart: hostAdapter.moveToStart,
                moveEnd: hostAdapter.moveToEnd,
                moveSeconds: hostAdapter.moveBy(seconds:),
                moveFrames: hostAdapter.moveByFrames(_:),
                refresh: {
                    hostAdapter.refresh(reason: "timeline")
                }
            )

        case .motion:
            UltraMotionView()

        case .audio:
            UltraAudioView()

        case .color:
            UltraColorView()

        case .updates:
            UltraUpdateCenterView(state: state)

        case .request:
            UltraRequestCenterView(state: state)
        }
    }
}
