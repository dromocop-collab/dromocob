import Foundation

struct UltraRequestResponse: Decodable {
    let ok: Bool
    let requestId: String?
    let id: String?
    let message: String?
}

actor RequestCenterClient {
    static let shared = RequestCenterClient()

    func send(
        title: String,
        description: String,
        module: String,
        host: HostSnapshot
    ) async throws -> String {
        let payload: [String: Any] = [
            "type": "feature",
            "title": title,
            "description": description,
            "priority": "normal",
            "module": module,
            "source": "dromocob-ultra-finalcut",
            "diagnostics": [
                "appVersion": "\(host.hostName) \(host.hostVersion)",
                "extensionVersion": UltraConfig.version,
                "platform": "macOS",
                "renderer": "Workflow Extension",
                "compName": host.sequenceAvailable ? host.sequenceName : ""
            ]
        ]

        var request = URLRequest(url: UltraConfig.requestCenterURL)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody =
            try JSONSerialization.data(withJSONObject: payload)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        let decoded =
            try? JSONDecoder().decode(UltraRequestResponse.self, from: data)

        guard (200...299).contains(http.statusCode), decoded?.ok == true else {
            throw NSError(
                domain: "DromocobRequestCenter",
                code: http.statusCode,
                userInfo: [
                    NSLocalizedDescriptionKey:
                        decoded?.message ?? "Talep gönderilemedi."
                ]
            )
        }

        return decoded?.requestId ?? decoded?.id ?? "Dromocob Request"
    }
}
