import Foundation
import AppKit

enum ReleaseCenterError: LocalizedError {
    case invalidResponse
    case http(Int)
    case invalidProduct

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            "Release manifest cevabı geçersiz."
        case .http(let status):
            "Release Center HTTP \(status)"
        case .invalidProduct:
            "Manifest farklı bir Dromocob ürünü için."
        }
    }
}

actor ReleaseCenterClient {
    static let shared = ReleaseCenterClient()

    func fetchManifest() async throws -> ReleaseManifest {
        var request = URLRequest(url: UltraConfig.updateManifestURL)
        request.timeoutInterval = 15
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse else {
            throw ReleaseCenterError.invalidResponse
        }

        guard (200...299).contains(http.statusCode) else {
            throw ReleaseCenterError.http(http.statusCode)
        }

        let manifest =
            try JSONDecoder().decode(ReleaseManifest.self, from: data)

        guard manifest.productId == UltraConfig.productID else {
            throw ReleaseCenterError.invalidProduct
        }

        return manifest
    }

    @MainActor
    static func open(_ url: URL?) {
        guard let url else { return }
        NSWorkspace.shared.open(url)
    }
}
