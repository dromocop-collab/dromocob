import Cocoa
import SwiftUI
import ProExtensionHost

@MainActor
@objc class DromocobUltraFinalCutExtensionViewController:
    NSViewController
{
    private let ultraState = UltraState()

    private lazy var hostAdapter =
        FinalCutHostAdapter(state: ultraState)

    private var hostingController:
        NSHostingController<UltraRootView>?

    override var nibName: NSNib.Name? { nil }

    override func loadView() {
        let root =
            NSView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: 980,
                        height: 760
                    )
            )

        root.wantsLayer = true
        root.layer?.backgroundColor =
            NSColor(
                calibratedRed: 0.012,
                green: 0.017,
                blue: 0.023,
                alpha: 1
            ).cgColor

        self.view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let rootView =
            UltraRootView(
                state: ultraState,
                hostAdapter: hostAdapter
            )

        let controller =
            NSHostingController(rootView: rootView)

        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(controller.view)

        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: view.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        hostingController = controller

        DispatchQueue.main.async { [weak self] in
            self?.hostAdapter.connect()
            self?.ultraState.checkForUpdates(silent: true)
        }

        NSLog("[Dromocob Ultra] 0.2.0 SwiftUI ready")
    }

    override func viewDidAppear() {
        super.viewDidAppear()
        hostAdapter.connect()
    }

    override func viewWillDisappear() {
        hostAdapter.disconnect()
        super.viewWillDisappear()
    }
}
