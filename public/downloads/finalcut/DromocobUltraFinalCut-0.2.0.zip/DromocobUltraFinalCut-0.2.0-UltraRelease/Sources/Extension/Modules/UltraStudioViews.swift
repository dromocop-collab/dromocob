import SwiftUI

struct UltraMotionView: View {
    var body: some View {
        studio(
            eyebrow: "ULTRA MOTION",
            title: "Motion Studio",
            message:
                "Motion Templates, FxPlug ve FCPXML tabanlı Dromocob motion paketleri için modüler çalışma alanı.",
            cards: [
                ("sparkles.rectangle.stack", "Transition Library", "Dromocob transition paketleri", "PACK"),
                ("textformat", "Title Studio", "Final Cut / Motion title paketleri", "PACK"),
                ("wand.and.stars", "Motion Presets", "Motion preset kataloğu", "PACK"),
                ("bolt.fill", "Ultra FX", "FxPlug genişleme yüzeyi", "FX")
            ]
        )
    }
}

struct UltraAudioView: View {
    var body: some View {
        studio(
            eyebrow: "ULTRA AUDIO",
            title: "Audio Studio",
            message:
                "Audio analiz, beat ve utility workflow'ları için ayrı adapter katmanı.",
            cards: [
                ("waveform.badge.magnifyingglass", "Audio Inspector", "Sequence tabanlı analiz", "LAB"),
                ("metronome", "Beat Engine", "Beat analiz workflow'u", "LAB"),
                ("speaker.wave.3.fill", "Level Tools", "Audio utility katmanı", "LAB"),
                ("waveform.path.ecg", "Cleanup", "Gelecek processing adapter", "LAB")
            ]
        )
    }
}

struct UltraColorView: View {
    var body: some View {
        studio(
            eyebrow: "ULTRA COLOR",
            title: "Color Studio",
            message:
                "LUT metadata, Motion/FxPlug ve desteklenen FCPXML color workflow'ları.",
            cards: [
                ("camera.filters", "LUT Library", "Dromocob LUT kataloğu", "COLOR"),
                ("star.fill", "Favorites", "Favori look koleksiyonu", "COLOR"),
                ("slider.horizontal.3", "Look Manager", "Look preset alanı", "COLOR"),
                ("circle.hexagongrid.fill", "Ultra Color FX", "FxPlug genişleme noktası", "FX")
            ]
        )
    }
}

private func studio(
    eyebrow: String,
    title: String,
    message: String,
    cards: [(String, String, String, String)]
) -> some View {
    ScrollView {
        VStack(alignment: .leading, spacing: 18) {
            UltraSectionTitle(
                eyebrow: eyebrow,
                title: title,
                subtitle: message
            )

            LazyVGrid(
                columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ],
                spacing: 10
            ) {
                ForEach(Array(cards.enumerated()), id: \.offset) { _, card in
                    UltraToolCard(
                        icon: card.0,
                        title: card.1,
                        subtitle: card.2,
                        enabled: false,
                        badge: card.3,
                        action: {}
                    )
                }
            }

            UltraCapabilityCard(
                title: "Host güvenliği",
                message:
                    "Workflow Extension API'sinin sunmadığı native editor mutation davranışları aktif araç gibi gösterilmez. İleri seviye edit özellikleri desteklenen FxPlug, Motion Template veya FCPXML katmanları üzerinden eklenir."
            )
        }
        .padding(20)
    }
}
