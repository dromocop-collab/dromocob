import SwiftUI

struct UltraUpdateCenterView: View {
    @ObservedObject var state: UltraState

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                UltraSectionTitle(
                    eyebrow: "DROMOCOB RELEASE CLOUD",
                    title: "Update Center",
                    subtitle: "Dromocob Ultra Release Center bağlantısı"
                )

                HStack(spacing: 12) {
                    UltraMetric(label: "Installed", value: UltraConfig.version)
                    UltraMetric(
                        label: "Latest",
                        value: state.release.latestVersion,
                        accent:
                            state.release.updateAvailable
                                ? UltraTheme.warning
                                : UltraTheme.success
                    )
                    UltraMetric(
                        label: "Channel",
                        value: UltraConfig.releaseChannel.uppercased()
                    )
                }

                VStack(alignment: .leading, spacing: 12) {
                    Text(
                        state.release.updateAvailable
                            ? "YENİ SÜRÜM HAZIR"
                            : "SÜRÜM DURUMU"
                    )
                    .font(.system(size: 9, weight: .black))
                    .tracking(1.3)
                    .foregroundStyle(
                        state.release.updateAvailable
                            ? UltraTheme.warning
                            : UltraTheme.success
                    )

                    Text(
                        state.release.updateAvailable
                            ? "Dromocob Ultra \(state.release.latestVersion)"
                            : "Dromocob Ultra \(UltraConfig.version) güncel"
                    )
                    .font(.system(size: 18, weight: .black))

                    if let error = state.release.lastError {
                        Text(error)
                            .font(.system(size: 10))
                            .foregroundStyle(UltraTheme.danger)
                    }

                    HStack(spacing: 10) {
                        UltraPrimaryButton(
                            title: "Güncellemeyi kontrol et",
                            icon: "arrow.clockwise",
                            disabled: state.release.checking
                        ) {
                            state.checkForUpdates()
                        }

                        if state.release.updateAvailable {
                            UltraPrimaryButton(
                                title: "İndirme sayfasını aç",
                                icon: "arrow.down.circle.fill",
                                disabled: state.release.downloadURL == nil
                            ) {
                                ReleaseCenterClient.open(
                                    state.release.downloadURL
                                )
                            }
                        }
                    }

                    if state.release.notesURL != nil {
                        Button("Sürüm notlarını aç") {
                            ReleaseCenterClient.open(
                                state.release.notesURL
                            )
                        }
                        .buttonStyle(.link)
                    }
                }
                .padding(17)
                .ultraPanel(glow: state.release.updateAvailable)

                UltraCapabilityCard(
                    title: "Release sözleşmesi",
                    message:
                        "Update Center, dromocob.tr/downloads/finalcut/manifest.json manifest'ini okur. Release scripti ZIP, SHA-256 ve manifest üretimini ~/Documents/DromocobUltraReleases/finalcut altında hazırlar."
                )
            }
            .padding(20)
        }
    }
}
