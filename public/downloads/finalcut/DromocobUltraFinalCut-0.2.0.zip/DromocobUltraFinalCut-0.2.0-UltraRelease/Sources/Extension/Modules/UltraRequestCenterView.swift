import SwiftUI

struct UltraRequestCenterView: View {
    @ObservedObject var state: UltraState

    @State private var title = ""
    @State private var detail = ""
    @State private var module = "final-cut"

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                UltraSectionTitle(
                    eyebrow: "USER REQUEST CLOUD",
                    title: "İstek Merkezi",
                    subtitle: "Final Cut taleplerini Dromocob backend'e gönder"
                )

                VStack(alignment: .leading, spacing: 13) {
                    TextField("Talep başlığı", text: $title)
                        .textFieldStyle(.roundedBorder)

                    Picker("Modül", selection: $module) {
                        Text("Final Cut").tag("final-cut")
                        Text("Timeline").tag("timeline")
                        Text("Motion").tag("motion")
                        Text("Audio").tag("audio")
                        Text("Color").tag("color")
                        Text("Release").tag("release")
                    }

                    TextEditor(text: $detail)
                        .font(.system(size: 11))
                        .frame(minHeight: 160)
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .background(
                            Color.black.opacity(0.18),
                            in: RoundedRectangle(cornerRadius: 12)
                        )

                    UltraPrimaryButton(
                        title:
                            state.requestSending
                                ? "Gönderiliyor"
                                : "Talebi gönder",
                        icon: "paperplane.fill",
                        disabled:
                            state.requestSending ||
                            title.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty ||
                            detail.trimmingCharacters(
                                in: .whitespacesAndNewlines
                            ).isEmpty
                    ) {
                        submit()
                    }
                }
                .padding(17)
                .ultraPanel()
            }
            .padding(20)
        }
    }

    private func submit() {
        let cleanTitle =
            title.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanDetail =
            detail.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !cleanTitle.isEmpty, !cleanDetail.isEmpty else { return }

        state.requestSending = true
        let host = state.host

        Task {
            do {
                let requestID =
                    try await RequestCenterClient.shared.send(
                        title: cleanTitle,
                        description: cleanDetail,
                        module: module,
                        host: host
                    )

                await MainActor.run {
                    state.requestSending = false
                    title = ""
                    detail = ""
                    state.showToast("Talep gönderildi • \(requestID)")
                }
            } catch {
                await MainActor.run {
                    state.requestSending = false
                    state.showToast(
                        "İstek Merkezi • \(error.localizedDescription)",
                        kind: .error,
                        duration: 5
                    )
                }
            }
        }
    }
}
