import SwiftUI

struct UltraTimelineView: View {
    @ObservedObject var state: UltraState

    let moveStart: () -> Void
    let moveEnd: () -> Void
    let moveSeconds: (Double) -> Void
    let moveFrames: (Int) -> Void
    let refresh: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                UltraSectionTitle(
                    eyebrow: "ULTRA TIMELINE",
                    title: "Timeline Control",
                    subtitle:
                        "Workflow SDK ile gerçek sequence ve playhead kontrolü"
                )

                LazyVGrid(
                    columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ],
                    spacing: 10
                ) {
                    UltraMetric(label: "Sequence", value: state.host.sequenceName)
                    UltraMetric(label: "Playhead", value: state.host.playheadSeconds.ultraTimecodeLike)
                    UltraMetric(label: "Duration", value: state.host.sequenceDurationSeconds.ultraTimecodeLike)
                    UltraMetric(label: "Start", value: state.host.sequenceStartSeconds.ultraSecondsLabel)
                    UltraMetric(label: "End", value: state.host.sequenceEndSeconds.ultraSecondsLabel)
                    UltraMetric(label: "FPS", value: state.host.fps.ultraFPSLabel)
                }

                LazyVGrid(
                    columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ],
                    spacing: 10
                ) {
                    UltraToolCard(
                        icon: "backward.end.fill",
                        title: "Sequence Start",
                        subtitle: "Timeline başlangıcına git",
                        enabled: state.host.sequenceAvailable,
                        badge: "REAL",
                        action: moveStart
                    )

                    UltraToolCard(
                        icon: "forward.end.fill",
                        title: "Sequence End",
                        subtitle: "Timeline sonuna git",
                        enabled: state.host.sequenceAvailable,
                        badge: "REAL",
                        action: moveEnd
                    )

                    UltraToolCard(
                        icon: "backward.frame.fill",
                        title: "-1 Frame",
                        subtitle: "Bir kare geri",
                        enabled: state.host.sequenceAvailable,
                        badge: "REAL"
                    ) {
                        moveFrames(-1)
                    }

                    UltraToolCard(
                        icon: "forward.frame.fill",
                        title: "+1 Frame",
                        subtitle: "Bir kare ileri",
                        enabled: state.host.sequenceAvailable,
                        badge: "REAL"
                    ) {
                        moveFrames(1)
                    }

                    UltraToolCard(
                        icon: "gobackward",
                        title: "-1 Second",
                        subtitle: "Bir saniye geri",
                        enabled: state.host.sequenceAvailable,
                        badge: "REAL"
                    ) {
                        moveSeconds(-1)
                    }

                    UltraToolCard(
                        icon: "goforward",
                        title: "+1 Second",
                        subtitle: "Bir saniye ileri",
                        enabled: state.host.sequenceAvailable,
                        badge: "REAL"
                    ) {
                        moveSeconds(1)
                    }
                }

                UltraPrimaryButton(
                    title: "Timeline bilgisini yenile",
                    icon: "arrow.clockwise",
                    action: refresh
                )

                UltraCapabilityCard(
                    title: "Public Workflow SDK sınırı",
                    message:
                        "Blade, trim, ripple delete ve native clip duplicate gibi mutation işlemleri public Workflow Extension timeline API'sinde yoksa Ultra bunları sahte şekilde çalıştırmaz. Bu sürüm sequence, range, playhead ve observer yüzeylerini gerçek API ile kullanır."
                )
            }
            .padding(20)
        }
    }
}
