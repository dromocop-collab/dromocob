import SwiftUI

struct UltraHomeView: View {
    @ObservedObject var state: UltraState
    let refreshHost: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                UltraSectionTitle(
                    eyebrow: "FINAL CUT CONTROL",
                    title: "Ultra Host Center",
                    subtitle: "Final Cut Pro host, timeline ve release durumu"
                )

                HStack(spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(
                            state.host.connected
                                ? "FINAL CUT PRO BAĞLANTISI HAZIR"
                                : "HOST BEKLENİYOR"
                        )
                        .font(.system(size: 9, weight: .black))
                        .tracking(1.3)
                        .foregroundStyle(
                            state.host.connected
                                ? UltraTheme.success
                                : UltraTheme.warning
                        )

                        Text(
                            state.host.connected
                                ? "\(state.host.hostName) \(state.host.hostVersion)"
                                : "Workflow Extension"
                        )
                        .font(.system(size: 19, weight: .black, design: .rounded))

                        Text(
                            state.host.sequenceAvailable
                                ? "\(state.host.sequenceName) • \(state.host.playheadSeconds.ultraTimecodeLike)"
                                : "Timeline açıldığında canlı sequence bilgisi burada görünür."
                        )
                        .font(.system(size: 10))
                        .foregroundStyle(UltraTheme.muted)
                    }

                    Spacer()

                    UltraStatusBadge(connected: state.host.connected)
                }
                .padding(18)
                .ultraPanel(glow: true)

                LazyVGrid(
                    columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ],
                    spacing: 12
                ) {
                    UltraMetric(label: "Application", value: state.host.hostName)
                    UltraMetric(label: "Host Version", value: state.host.hostVersion)
                    UltraMetric(label: "Sequence", value: state.host.sequenceName)
                    UltraMetric(label: "FPS", value: state.host.fps.ultraFPSLabel)
                    UltraMetric(label: "Ultra", value: UltraConfig.version)
                    UltraMetric(
                        label: "Release",
                        value:
                            state.release.updateAvailable
                                ? "UPDATE \(state.release.latestVersion)"
                                : "STABLE",
                        accent:
                            state.release.updateAvailable
                                ? UltraTheme.warning
                                : UltraTheme.success
                    )
                }

                HStack(spacing: 10) {
                    UltraPrimaryButton(
                        title: "Final Cut bağlantısını yenile",
                        icon: "arrow.clockwise",
                        action: refreshHost
                    )

                    UltraPrimaryButton(
                        title:
                            state.release.checking
                                ? "Kontrol ediliyor"
                                : "Güncelleme kontrolü",
                        icon: "arrow.triangle.2.circlepath",
                        disabled: state.release.checking
                    ) {
                        state.checkForUpdates()
                    }
                }
            }
            .padding(20)
        }
        .task {
            state.checkForUpdates(silent: true)
        }
    }
}
