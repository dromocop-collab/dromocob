# Dromocob Ultra Final Cut 0.2.0 — Ultra Release

After Effects'teki Dromocob Ultra yaklaşımını Final Cut Pro Workflow Extension'a taşıyan modüler paket.

## İçerik
- Ultra blue/cyan UI
- Home Host Center
- Final Cut Pro LIVE host
- gerçek Timeline observer
- gerçek playhead navigation
- sequence / duration / FPS diagnostics
- Motion Studio
- Audio Studio
- Color Studio
- İstek Merkezi
- Update Center
- Release Center manifest
- release ZIP + SHA-256 üretimi
- Xcode apply script
- debug install script
- release build script
- Library Validation fix

## Endpoints
Requests:
`https://dromocob.tr/api/ultra/requests`

Updates:
`https://dromocob.tr/downloads/finalcut/manifest.json`

## Başlangıç
`Scripts/validate-source.command`

ardından:

`Scripts/apply-to-xcode.command`

ve:

`Scripts/build-debug-install.command`
