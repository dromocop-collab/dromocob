(function () {
  "use strict";

  var toastTimer;

  var quickActions = [
    ["↗", "YAKINLAŞ", "Dinamik yaklaşma", "zoomIn"],
    ["↙", "UZAKLAŞ", "Akıcı uzaklaşma", "zoomOut"],
    ["◆", "ÜRÜN VURGUSU", "Ürün giriş hareketi", "productPop"],
    ["◌", "YUMUŞAK GİRİŞ", "Yumuşak görünme", "fadeIn"],
    ["⌁", "AKICI EĞRİ", "Seçili anahtar kare", "easyEase"],
    ["◫", "HAREKET BULANIKLIĞI", "Hareket bulanıklığı", "motionBlur"],
    ["↻", "DÖNÜŞLÜ GİRİŞ", "Lüks dönüş girişi", "rotateReveal"],
    ["→", "SAĞA SAVUR", "Hızlı geçiş", "whipRight"]
  ];

  var effects = [
    ["✦", "PARLAMA", "Işık ve neon", "ADBE Glo2"],
    ["◉", "GAUSS BULANIKLIĞI", "Yumuşak bulanıklık", "ADBE Gaussian Blur 2"],
    ["◩", "ALT GÖLGE", "Derinlik gölgesi", "ADBE Drop Shadow"],
    ["⌁", "KESKİNLEŞTİR", "Keskin detay", "ADBE Sharpen"],
    ["◐", "RENKLENDİR", "İki renk tonlama", "ADBE Tint"],
    ["∴", "GÜRÜLTÜ", "Organik doku", "ADBE Noise"],
    ["≈", "TÜRBÜLANS", "Dalgalı deformasyon", "ADBE Turbulent Displace"],
    ["◒", "LUMETRI RENK", "Renk düzenleme", "ADBE Lumetri"],
    ["↗", "YÖNLÜ BULANIKLIK", "Hız çizgisi", "ADBE Motion Blur"],
    ["◎", "RADYAL BULANIKLIK", "Dairesel enerji", "ADBE Radial Blur"],
    ["▤", "ÇİZGİSEL PERDE", "Çizgisel açılma", "ADBE Venetian Blinds"],
    ["⌗", "MOZAİK", "Piksel blokları", "ADBE Mosaic"],
    ["△", "POZLAMA", "Işık kontrolü", "ADBE Exposure2"],
    ["◨", "EĞRİLER", "Profesyonel kontrast", "ADBE CurvesCustom"],
    ["⊹", "ALFA KABARTMA", "Parlak kenarlar", "ADBE Bevel Alpha"],
    ["〰", "DALGA BÜKÜLMESİ", "Akış deformasyonu", "ADBE Wave Warp"]
  ];

  var fxStacks = [
    ["✧", "NEON NABIZ", "Parlama + keskinlik + renk", "neonPulse"],
    ["☁", "RÜYA IŞIĞI", "Yumuşak bulanıklık + parlama", "dreamBloom"],
    ["⌁", "VHS HASARI", "Gürültü + dalga + renk ayrımı", "vhsDamage"],
    ["↯", "HIZ BULANIKLIĞI", "Yönlü hareket enerjisi", "speedBlur"],
    ["◉", "SİNEMA DARBESİ", "Kontrast + vinyet karakteri", "cinemaPunch"],
    ["◇", "NET DETAY", "Keskinlik + mikro kontrast", "crispDetail"],
    ["◐", "ÇİFT TON MAVİ", "Dromocob mavi tonlama", "duotoneBlue"],
    ["※", "DİJİTAL DOKU", "Gürültü + posterize doku", "digitalGrit"],
    ["☼", "ALTIN SAAT", "Sıcak parlama + pozlama", "goldenHour"],
    ["❄", "KUTUP IŞIĞI", "Soğuk ışık + netlik", "arcticGlow"],
    ["◫", "YUMUŞAK PORTRE", "Ten dostu yumuşatma", "softPortrait"],
    ["◈", "SİBER KENAR", "Neon kenar + doku", "cyberEdge"],
    ["▤", "TARAMA ÇİZGİSİ PRO", "Dijital tarama dokusu", "scanlinePro"],
    ["◉", "VİNYET ODAK", "Merkez odak karakteri", "vignetteFocus"],
    ["⚡", "DARBE ENERJİSİ", "Parlama + keskinlik + pozlama", "impactEnergy"],
    ["◇", "FİLM YUMUŞAKLIĞI", "Organik sinema yumuşaklığı", "filmSoftness"]
  ];

  var glowPresets = [
    ["☼", "YUMUŞAK IŞIK", "Yumuşak sinema ışığı", [68, 95, 95, 38, "#ffd6ad"]],
    ["✦", "NEON MAVİ", "Keskin Dromocob neon", [35, 58, 190, 70, "#17c8ff"]],
    ["◉", "RÜYA HALESİ", "Geniş rüya halesi", [52, 145, 125, 66, "#8ecbff"]],
    ["⚡", "ENERJİ ÇEKİRDEĞİ", "Yoğun merkez enerjisi", [70, 38, 240, 48, "#f4fbff"]],
    ["☄", "ATEŞ KENARI", "Sıcak turuncu kenar", [42, 82, 175, 60, "#ff6b18"]],
    ["◇", "KROM PARLAMA", "Metalik vurgu", [78, 34, 155, 28, "#d7efff"]],
    ["♢", "MOR AURA", "Mor atmosfer", [46, 120, 145, 62, "#9b63ff"]],
    ["◎", "LAZER NABZI", "Animasyonlu güçlü nabız", [60, 55, 220, 80, "#24ffe2"]]
  ];

  function tp(name, detail, style, family, profile) { return { name: name, detail: detail, style: style, family: family, profile: profile || {} }; }
  var transitionCategories = [
    { id: "camera", name: "KAMERA", icon: "⌖", hint: "Sinematik kadraj hareketleri", items: [
      tp("DOLLY IN", "Yumuşak lens yaklaşması", "zoom", "camera", { scale: 1.34 }), tp("DOLLY OUT", "Derinlikten geri açılma", "zoom", "camera", { scale: .68 }),
      tp("PARALLAX SOL", "Katmanlı sola akış", "whip", "camera", { x: -1.1, scale: 1.08 }), tp("PARALLAX SAĞ", "Katmanlı sağa akış", "whip", "camera", { x: 1.1, scale: 1.08 }),
      tp("TILT YUKARI", "Dikey kamera yükselişi", "whip", "camera", { y: -1.05, rotation: -2 }), tp("TILT AŞAĞI", "Dikey kamera inişi", "whip", "camera", { y: 1.05, rotation: 2 }),
      tp("HANDHELD PUSH", "Organik yaklaşma hissi", "impact", "camera", { scale: 1.2, jitter: 14 }), tp("CINEMA DRIFT", "Yavaş çapraz süzülme", "whip", "camera", { x: .35, y: -.22, scale: 1.12 }) ] },
    { id: "whip", name: "SAVURMA", icon: "➜", hint: "Hızlı yönlü kesmeler", items: [
      tp("WHIP SOL", "Sola hızlı savurma", "whip", "motion", { x: -1.35, blur: 65 }), tp("WHIP SAĞ", "Sağa hızlı savurma", "whip", "motion", { x: 1.35, blur: 65 }),
      tp("WHIP YUKARI", "Yukarı hızlı savurma", "whip", "motion", { y: -1.35, blur: 72 }), tp("WHIP AŞAĞI", "Aşağı hızlı savurma", "whip", "motion", { y: 1.35, blur: 72 }),
      tp("ÇAPRAZ KUZEYBATI", "Çapraz dinamik çıkış", "whip", "motion", { x: -.9, y: -.9, blur: 82 }), tp("ÇAPRAZ KUZEYDOĞU", "Çapraz dinamik çıkış", "whip", "motion", { x: .9, y: -.9, blur: 82 }),
      tp("ÇAPRAZ GÜNEYBATI", "Çapraz hızlı akış", "whip", "motion", { x: -.9, y: .9, blur: 82 }), tp("ÇAPRAZ GÜNEYDOĞU", "Çapraz hızlı akış", "whip", "motion", { x: .9, y: .9, blur: 82 }) ] },
    { id: "spin", name: "DÖNÜŞ", icon: "↻", hint: "Spin, roll ve burgu hareketleri", items: [
      tp("SPIN SAĞ", "Saat yönünde tam dönüş", "spin", "spin", { rotation: 380, scale: .12 }), tp("SPIN SOL", "Saat yönü tersine dönüş", "spin", "spin", { rotation: -380, scale: .12 }),
      tp("BARREL ROLL", "Yatay namlu dönüşü", "spin", "spin", { rotation: 720, scale: .42 }), tp("HALF TURN", "Temiz yarım tur geçiş", "spin", "spin", { rotation: 180, scale: .72 }),
      tp("ELASTIC SPIN", "Taşmalı esnek dönüş", "spin", "spin", { rotation: 410, scale: 1.16, entrance: true }), tp("CORKSCREW", "Burgu ve lens hareketi", "spin", "spin", { rotation: -640, scale: .18, x: .28 }),
      tp("ORBIT KICK", "Yörüngesel vurgu", "spin", "spin", { rotation: 245, scale: 1.22, entrance: true }), tp("SPIN ZOOM", "Dönüşlü crash zoom", "spin", "spin", { rotation: 520, scale: 1.72 }) ] },
    { id: "light", name: "IŞIK", icon: "✦", hint: "Flare, burn ve enerji kaplamaları", items: [
      tp("BEYAZ FLAŞ", "Temiz beyaz kesme", "flash", "overlay", { color: [1,1,1], peak: 100 }), tp("SİYAH FLAŞ", "Sinematik siyah blink", "flash", "overlay", { color: [0,0,0], peak: 100, blend: "normal" }),
      tp("MAVİ ENERJİ", "Dromocob enerji patlaması", "flash", "overlay", { color: [.02,.35,1], peak: 100, glow: true }), tp("SICAK FLARE", "Altın lens sızıntısı", "burn", "overlay", { color: [1,.32,.03], peak: 92, glow: true }),
      tp("FİLM YANIĞI", "Analog sıcak film burn", "burn", "overlay", { color: [1,.14,0], peak: 88, noise: true }), tp("ATEŞLİ SİLME", "Alev karakterli wipe", "fire", "overlay", { color: [1,.08,0], peak: 100, noise: true, wipe: true }),
      tp("NEON ÇİZGİ", "Mavi ışık taraması", "flash", "overlay", { color: [0,.75,1], peak: 82, wipe: true, glow: true }), tp("EXPOSURE PULSE", "Kısa pozlama darbesi", "flash", "overlay", { color: [1,.86,.62], peak: 74, glow: true }) ] },
    { id: "glitch", name: "DİJİTAL", icon: "⌁", hint: "Glitch ve sinyal bozulmaları", items: [
      tp("GLITCH CUT", "RGB dijital kırılma", "glitch", "digital", { jitter: 31, noise: 18 }), tp("RGB FLAŞ", "Kromatik kısa vurgu", "glitch", "digital", { jitter: 18, noise: 5, flash: true }),
      tp("DATA MOSH", "Akışkan veri kayması", "glitch", "digital", { jitter: 52, noise: 11, smear: true }), tp("SCAN TEAR", "Yatay sinyal yırtılması", "glitch", "digital", { jitter: 66, noise: 22, scan: true }),
      tp("PIXEL BURST", "Mozaik patlama", "glitch", "digital", { jitter: 26, noise: 8, mosaic: true }), tp("CHROMATIC HIT", "Renk kanalı darbesi", "glitch", "digital", { jitter: 12, noise: 3, flash: true }),
      tp("SIGNAL DROP", "Kayıp sinyal kesmesi", "glitch", "digital", { jitter: 8, noise: 34, drop: true }), tp("DIGITAL ROLL", "Dikey dijital tarama", "glitch", "digital", { y: .22, jitter: 20, scan: true }) ] },
    { id: "shape", name: "ŞEKİL", icon: "◩", hint: "Geometrik maskesiz silmeler", items: [
      tp("CIRCLE IRIS", "Merkezden dairesel açılma", "shape", "shape", { shape: "circle", rotation: 0 }), tp("DIAMOND IRIS", "Elmas formunda açılma", "shape", "shape", { shape: "diamond", rotation: 45 }),
      tp("SQUARE REVEAL", "Kare ölçek geçişi", "shape", "shape", { shape: "square", rotation: 0 }), tp("DIAGONAL WIPE", "Keskin çapraz silme", "shape", "shape", { shape: "wipe", angle: 45 }),
      tp("RADIAL SWEEP", "Dairesel saat taraması", "shape", "shape", { shape: "radial", angle: 0 }), tp("VENETIAN", "Çizgisel perde geçişi", "shape", "shape", { shape: "blinds", angle: 0 }),
      tp("SPLIT SCREEN", "Merkezden ikiye açılma", "shape", "shape", { shape: "split", angle: 90 }), tp("CROSS WIPE", "Çapraz kesişen perde", "shape", "shape", { shape: "cross", angle: 45 }) ] },
    { id: "blur", name: "BLUR", icon: "◌", hint: "Optik ve yönlü bulanıklıklar", items: [
      tp("ZOOM BLUR", "Merkeze hızlı optik akış", "zoom", "blur", { scale: 1.52, blur: 48 }), tp("DEFOCUS", "Lens odağından çıkış", "zoom", "blur", { scale: 1.06, blur: 72 }),
      tp("DIRECTIONAL SOL", "Sola yönlü hız izi", "whip", "blur", { x: -.38, blur: 92, angle: 90 }), tp("DIRECTIONAL SAĞ", "Sağa yönlü hız izi", "whip", "blur", { x: .38, blur: 92, angle: 90 }),
      tp("RADIAL TWIST", "Dönüşlü radyal blur", "spin", "blur", { rotation: 120, blur: 58 }), tp("DREAM BLOOM", "Yumuşak rüya geçişi", "flash", "blur", { scale: 1.15, blur: 34, glow: true }),
      tp("FOCUS RACK", "Odağı önden arkaya taşı", "zoom", "blur", { scale: .94, blur: 46, return: true }), tp("SMEAR FLOW", "Akışkan görüntü sürükleme", "glitch", "blur", { x: .24, blur: 110, smear: true }) ] },
    { id: "impact", name: "DARBE", icon: "◆", hint: "Beat ve vurgu odaklı hareketler", items: [
      tp("IMPACT PUNCH", "Sert ölçek vuruşu", "impact", "impact", { scale: 1.24, jitter: 12 }), tp("BASS SLAM", "Güçlü bas darbesi", "impact", "impact", { scale: 1.38, jitter: 24 }),
      tp("CAMERA RECOIL", "Geri tepme hareketi", "impact", "impact", { scale: .84, y: .12, jitter: 18 }), tp("ELASTIC BOUNCE", "Taşmalı yay vurgusu", "impact", "impact", { scale: 1.16, bounce: true }),
      tp("STAMP HIT", "Grafik mühür darbesi", "impact", "impact", { scale: .52, rotation: -7 }), tp("CRASH ZOOM", "Agresif zoom patlaması", "impact", "impact", { scale: 1.72, jitter: 30 }),
      tp("MICRO JITTER", "Kısa mikro sarsıntı", "impact", "impact", { scale: 1.04, jitter: 8 }), tp("HEAVY DROP", "Aşağı yönlü ağır darbe", "impact", "impact", { scale: 1.28, y: .18, jitter: 16 }) ] }
  ];
  var activeTransitionCategory = "camera";

  var shakes = [
    ["⌁", "HAFİF", "2 / 8 / 0.3", [2, 8, .3]],
    ["≈", "EL KAMERASI", "4 / 24 / 1.2", [4, 24, 1.2]],
    ["✦", "DARBE", "9 / 65 / 2.5", [9, 65, 2.5]],
    ["※", "KAOS", "14 / 110 / 4", [14, 110, 4]]
  ];

  var formats = [
    ["▯", "REEL 9:16", "1080 × 1920", [1080, 1920, 25]],
    ["▥", "GÖNDERİ 4:5", "1080 × 1350", [1080, 1350, 25]],
    ["□", "KARE 1:1", "1080 × 1080", [1080, 1080, 25]],
    ["▭", "YOUTUBE 16:9", "1920 × 1080", [1920, 1080, 25]]
  ];

  var textTools = [
    ["◌", "YUMUŞAK GİRİŞ", "Yumuşak giriş", "fadeIn"],
    ["◆", "CANLI GİRİŞ", "Dinamik vurgu", "productPop"],
    ["↻", "DÖNÜŞLÜ GİRİŞ", "Dönüşlü giriş", "rotateReveal"],
    ["↗", "YAKINLAŞ", "Yaklaşan tipografi", "zoomIn"]
  ];

  var text3DPresets = [
    ["KROM DERİNLİK", "Metal 3D derinlik", "chrome", "chromeExtrude"],
    ["NEON 3D", "Parlak mavi neon", "neon", "neon3D"],
    ["GÖLGE YIĞINI", "Katmanlı uzun gölge", "shadow", "shadowStack"],
    ["SİNEMA KABARTMASI", "Kabartma ve dramatik gölge", "chrome", "cinemaBevel"],
    ["KİNETİK VURGU", "Canlı ölçek animasyonu", "kinetic", "kineticPop"],
    ["3D DÖNÜŞ", "Y ekseninde sinematik dönüş", "kinetic", "spin3D"],
    ["HOLOGRAM", "Dijital ışık karakteri", "neon", "hologram"],
    ["BLOK DERİNLİĞİ", "Güçlü kalın derinlik", "shadow", "blockDepth"]
  ];

  function toast(message, isError) {
    var element = document.getElementById("toast");
    clearTimeout(toastTimer);
    element.textContent = message;
    element.className = "toast show" + (isError ? " error" : "");
    toastTimer = setTimeout(function () { element.className = "toast"; }, 2600);
  }

  function contextPayload(extra) {
    var payload = {
      durationFrames: Number(document.getElementById("duration").value) || 8,
      intensity: Number(document.getElementById("intensity").value) || 30
    };
    Object.keys(extra || {}).forEach(function (key) { payload[key] = extra[key]; });
    return payload;
  }

  function hostCall(method, payload, quiet) {
    if (method !== "context" && window.DromocobLicense && !DromocobLicense.canUse()) {
      document.querySelector('[data-page="license"]').click();
      toast("Bu araç için Dromocob Ultra lisansını etkinleştir.", true);
      return Promise.resolve({ ok: false, message: "Lisans gerekli." });
    }
    return DromocobBridge.call(method, contextPayload(payload)).then(function (result) {
      if (!quiet) toast(result.message || (result.ok ? "İşlem tamamlandı." : "İşlem uygulanamadı."), !result.ok);
      return result;
    });
  }

  function cardMarkup(item) {
    return '<b>' + item[0] + '</b><strong>' + item[1] + '</strong><small>' + item[2] + '</small>';
  }

  function renderActionGrid(id, items, handler) {
    var grid = document.getElementById(id);
    grid.innerHTML = "";
    items.forEach(function (item) {
      var button = document.createElement("button");
      button.className = "action-card";
      button.innerHTML = cardMarkup(item);
      button.addEventListener("click", function () { handler(item); });
      grid.appendChild(button);
    });
  }

  function renderTransitionGrid(items) {
    var grid = document.getElementById("transitionGrid");
    grid.innerHTML = "";
    items.forEach(function (item) {
      var button = document.createElement("button");
      button.className = "transition-card";
      button.setAttribute("data-style", item.style);
      button.innerHTML = '<div class="transition-preview"><i></i><b>▶</b></div><div class="transition-info"><strong>' + item.name + '</strong><small>' + item.detail + '</small><em>UYGULA ↗</em></div>';
      button.addEventListener("click", function () { hostCall("transition", { type: "profile", family: item.family, profile: item.profile, presetName: item.name }); });
      grid.appendChild(button);
    });
  }

  function renderTransitionLibrary() {
    var tabs = document.getElementById("transitionTabs"), search = document.getElementById("transitionSearch");
    tabs.innerHTML = "";
    transitionCategories.forEach(function (category) {
      var button = document.createElement("button");
      button.className = category.id === activeTransitionCategory ? "active" : "";
      button.innerHTML = '<b>' + category.icon + '</b><span>' + category.name + '</span><small>' + category.items.length + '</small>';
      button.onclick = function () { activeTransitionCategory = category.id; renderTransitionLibrary(); };
      tabs.appendChild(button);
    });
    var current = transitionCategories.filter(function (category) { return category.id === activeTransitionCategory; })[0] || transitionCategories[0];
    var query = String(search.value || "").toLocaleUpperCase("tr-TR");
    var items = query ? [].concat.apply([], transitionCategories.map(function (category) { return category.items; })).filter(function (item) { return (item.name + " " + item.detail).toLocaleUpperCase("tr-TR").indexOf(query) >= 0; }) : current.items;
    document.getElementById("transitionCategoryTitle").textContent = query ? "ARAMA SONUÇLARI" : current.name;
    document.getElementById("transitionCategoryHint").textContent = query ? items.length + " geçiş bulundu" : current.hint;
    renderTransitionGrid(items);
  }

  function renderTools() {
    renderActionGrid("quickActions", quickActions, function (item) { hostCall(item[3]); });
    renderTransitionLibrary();
    renderActionGrid("fxStackGrid", fxStacks, function (item) { hostCall("effectStack", { type: item[3], displayName: item[1] }); });
    renderActionGrid("effectGrid", effects, function (item) { hostCall("addEffect", { matchName: item[3], displayName: item[1] }); });
    renderActionGrid("glowPresetGrid", glowPresets, function (item) {
      setGlowControls(item[3]); hostCall("glowLab", glowPayload(item[1], item[1] === "LASER PULSE"));
    });
    renderActionGrid("shakePresets", shakes, function (item) {
      hostCall("shake", { frequency: item[3][0], amount: item[3][1], rotation: item[3][2] });
    });
    renderActionGrid("formatGrid", formats, function (item) {
      hostCall("createComp", { name: "DROMOCOB_" + item[1].replace(/\s+/g, "_"), width: item[3][0], height: item[3][1], fps: item[3][2] });
    });
    renderActionGrid("textGrid", textTools, function (item) { hostCall(item[3]); });
    var textPresetGrid = document.getElementById("text3DGrid");
    textPresetGrid.innerHTML = "";
    text3DPresets.forEach(function (item) {
      var button = document.createElement("button");
      button.className = "text-preset";
      button.setAttribute("data-style", item[2]);
      button.innerHTML = '<div class="type-demo">Aa</div><strong>' + item[0] + '</strong><small>' + item[1] + '</small>';
      button.addEventListener("click", function () { createAdvancedText(false, item[3]); });
      textPresetGrid.appendChild(button);
    });
  }

  function textPayload(update, style) {
    return {
      text: document.getElementById("textContent").value || "DROMOCOB",
      size: Number(document.getElementById("textSize").value) || 120,
      tracking: Number(document.getElementById("textTracking").value) || 0,
      font: document.getElementById("textFont").value,
      align: document.getElementById("textAlign").value,
      leading: Number(document.getElementById("textLeading").value) || 0,
      strokeWidth: Number(document.getElementById("textStroke").value) || 0,
      allCaps: document.getElementById("textAllCaps").checked,
      fauxBold: document.getElementById("textBold").checked,
      color: document.getElementById("textColor").value,
      depth: Number(document.getElementById("textDepth").value) || 0,
      threeD: document.getElementById("text3D").checked,
      update: Boolean(update),
      style: style || "clean3D"
    };
  }

  function createAdvancedText(update, style) {
    hostCall("textStudio", textPayload(update, style));
  }

  function updateTextPreview() {
    var preview = document.getElementById("textPreview");
    var content = document.getElementById("textContent").value || "DROMOCOB";
    var size = Number(document.getElementById("textSize").value) || 120;
    var tracking = Number(document.getElementById("textTracking").value) || 0;
    var color = document.getElementById("textColor").value;
    var depth = Number(document.getElementById("textDepth").value) || 0;
    preview.textContent = document.getElementById("textAllCaps").checked ? content.toUpperCase() : content;
    preview.style.fontSize = Math.max(20, Math.min(70, size * .42)) + "px";
    preview.style.letterSpacing = Math.max(-2, Math.min(15, tracking / 18)) + "px";
    preview.style.color = color;
    preview.style.fontFamily = document.getElementById("textFont").options[document.getElementById("textFont").selectedIndex].text + ", sans-serif";
    preview.style.textAlign = document.getElementById("textAlign").value;
    var shadows = [];
    for (var i = 1; i <= Math.max(1, Math.min(8, depth)); i++) shadows.push(i + "px " + i + "px 0 rgba(4,62,108," + (.95 - i * .07) + ")");
    shadows.push("0 0 28px rgba(17,140,255,.3)");
    preview.style.textShadow = shadows.join(",");
    document.getElementById("textDepthValue").value = depth;
  }

  function glowPayload(name, forceAnimate) {
    return {
      name: name || "ÖZEL PARLAMA", color: document.getElementById("glowColor").value,
      threshold: Number(document.getElementById("glowThreshold").value), radius: Number(document.getElementById("glowRadius").value),
      power: Number(document.getElementById("glowPower").value) / 100, secondary: Number(document.getElementById("glowSecondary").value),
      mode: document.getElementById("glowMode").value, animate: Boolean(forceAnimate || document.getElementById("glowAnimate").checked)
    };
  }

  function setGlowControls(values) {
    ["glowThreshold", "glowRadius", "glowPower", "glowSecondary"].forEach(function (id, index) { document.getElementById(id).value = values[index]; });
    document.getElementById("glowColor").value = values[4]; updateGlowPreview();
  }

  function updateGlowPreview() {
    var color = document.getElementById("glowColor").value;
    var radius = Number(document.getElementById("glowRadius").value);
    var power = Number(document.getElementById("glowPower").value) / 100;
    var orb = document.getElementById("glowPreview");
    orb.style.setProperty("--glow-color", color);
    orb.style.setProperty("--glow-radius", Math.round(radius / 4) + "px");
    orb.style.setProperty("--glow-power", Math.min(1, power / 2));
    document.querySelectorAll(".range-row").forEach(function (row) {
      var input = row.querySelector("input"), output = row.querySelector("output");
      if (input.id === "glowPower") output.value = (Number(input.value) / 100).toFixed(2);
      else if (input.id === "glowSecondary") output.value = input.value + "%";
      else output.value = input.value;
    });
  }

  function timecode(seconds, fps) {
    var totalFrames = Math.max(0, Math.round((seconds || 0) * (fps || 25)));
    var frames = totalFrames % Math.round(fps || 25);
    var totalSeconds = Math.floor(totalFrames / (fps || 25));
    var secs = totalSeconds % 60;
    var mins = Math.floor(totalSeconds / 60) % 60;
    var hours = Math.floor(totalSeconds / 3600);
    function pad(value) { return value < 10 ? "0" + value : String(value); }
    return pad(hours) + ":" + pad(mins) + ":" + pad(secs) + ":" + pad(frames);
  }

  function initNavigation() {
    document.querySelectorAll(".nav-item").forEach(function (button) {
      button.addEventListener("click", function () {
        document.querySelectorAll(".nav-item").forEach(function (item) { item.classList.remove("active"); });
        document.querySelectorAll(".page").forEach(function (page) { page.classList.remove("active"); });
        button.classList.add("active");
        var page = document.getElementById(button.dataset.page);
        page.classList.add("active");
        document.getElementById("pageTitle").textContent = page.dataset.title;
        if (localStorage.getItem("dromocob.rememberPage") !== "off") localStorage.setItem("dromocob.lastPage", button.dataset.page);
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        button.blur();
      });
    });
  }

  function initGlobalActions() {
    document.getElementById("transitionSearch").addEventListener("input", renderTransitionLibrary);
    document.getElementById("intensity").addEventListener("input", function (event) {
      document.getElementById("intensityValue").value = event.target.value;
    });
    document.getElementById("duration").addEventListener("input", function (event) {
      document.getElementById("transitionDurationLabel").textContent = (Number(event.target.value) || 8) + " KARE";
    });

    document.addEventListener("click", function (event) {
      var external = event.target.closest("[data-external]");
      if (external) { DromocobBridge.openExternal(external.dataset.external); return; }
      var button = event.target.closest("[data-action]");
      if (button) hostCall(button.dataset.action);
    });

    document.getElementById("applyShake").addEventListener("click", function () {
      hostCall("shake", {
        frequency: Number(document.getElementById("shakeFrequency").value) || 4,
        amount: Number(document.getElementById("shakeAmount").value) || 25,
        rotation: Number(document.getElementById("shakeRotation").value) || 0
      });
    });

    document.getElementById("applyCurve").addEventListener("click", function () {
      hostCall("applyCurve", { curve: CurveStudio.getValue() });
    });
    document.getElementById("curveReset").addEventListener("click", CurveStudio.reset);
    document.getElementById("copyCurve").addEventListener("click", function () {
      var text = CurveStudio.getValue().map(function (value) { return value.toFixed(2); }).join(", ");
      var helper = document.createElement("textarea");
      helper.value = text; document.body.appendChild(helper); helper.select(); document.execCommand("copy"); helper.remove();
      toast("Eğri değeri kopyalandı.");
    });
    document.getElementById("pasteCurve").addEventListener("click", function () {
      var pasted = window.prompt("Dört hareket eğrisi değeri:", document.getElementById("bezierCode").textContent);
      if (!pasted) return;
      var parsed = pasted.split(/[ ,]+/).filter(Boolean).map(Number);
      if (!CurveStudio.setValue(parsed)) toast("Eğri formatı geçersiz.", true);
    });
    document.getElementById("saveCurve").addEventListener("click", function () {
      var name = window.prompt("Hazır ayar adı:", "Benim Eğrim");
      if (name && CurveStudio.addPreset(name)) toast("Eğri hazır ayarlara kaydedildi.");
    });

    document.getElementById("refreshContext").addEventListener("click", updateContext);

    ["textContent", "textSize", "textTracking", "textColor", "textDepth", "textFont", "textAlign", "textLeading", "textStroke", "textAllCaps", "textBold"].forEach(function (id) {
      document.getElementById(id).addEventListener("input", updateTextPreview);
    });
    document.getElementById("createText").addEventListener("click", function () { createAdvancedText(false, "clean3D"); });
    document.getElementById("updateText").addEventListener("click", function () { createAdvancedText(true, "clean3D"); });
    ["glowColor", "glowThreshold", "glowRadius", "glowPower", "glowSecondary"].forEach(function (id) { document.getElementById(id).addEventListener("input", updateGlowPreview); });
    document.getElementById("applyGlow").addEventListener("click", function () { hostCall("glowLab", glowPayload("ÖZEL PARLAMA")); });
    document.getElementById("removeGlow").addEventListener("click", function () { hostCall("removeDromocobGlow"); });
    document.getElementById("activateLicense").addEventListener("click", function () {
      var key = document.getElementById("licenseKey").value;
      DromocobLicense.activate(key).then(function () { document.getElementById("licenseKey").value = ""; toast("Dromocob Ultra etkinleştirildi."); }).catch(function (error) { toast(error.message, true); });
    });
    document.getElementById("startTrial").addEventListener("click", function () { DromocobLicense.startTrial().then(function () { toast("Dromocob Ultra deneme sürümü başladı."); }).catch(function (error) { toast(error.message, true); }); });
    document.getElementById("validateLicense").addEventListener("click", function () { DromocobLicense.validate().then(function () { toast("Lisans doğrulandı."); }).catch(function (error) { toast(error.message, true); }); });
    document.getElementById("refreshActiveLicense").addEventListener("click", function () { DromocobLicense.validate().then(function () { toast("Lisans makbuzu yenilendi."); }).catch(function (error) { toast(error.message, true); }); });
    document.getElementById("deactivateLicense").addEventListener("click", function () {
      var licenseState = DromocobLicense.state(), receipt = licenseState.receipt && licenseState.receipt.payload;
      var isTrial = receipt && String(receipt.activationId || "").indexOf("trial:") === 0;
      var key = isTrial ? "" : window.prompt("Bu cihazı kaldırmak için lisans anahtarını doğrula:", "");
      if (!isTrial && !key) return;
      DromocobLicense.deactivate(key).then(function () { document.getElementById("licenseKey").value = ""; toast("Bu cihaz lisansından kaldırıldı."); }).catch(function (error) { toast(error.message, true); });
    });
  }

  function updateContext() {
    hostCall("context", {}, true).then(function (result) {
      var aeStatus = document.getElementById("aeStatus");
      var compStatus = document.getElementById("compStatus");
      if (result.ok) {
        if (window.DromocobPacks && DromocobPacks.setContext) DromocobPacks.setContext(result);
        aeStatus.textContent = "AE BAĞLANDI";
        compStatus.textContent = result.compName ? result.compName + " • " + result.selectedLayers + " katman" : "Aktif kompozisyon yok";
        document.getElementById("hudCompName").textContent = result.compName || "KOMPOZİSYON YOK";
        document.getElementById("hudSize").textContent = result.compName ? result.width + "×" + result.height : "—";
        document.getElementById("hudFps").textContent = result.compName ? Math.round(result.fps * 100) / 100 : "—";
        document.getElementById("hudDuration").textContent = result.compName ? Math.round(result.duration * 10) / 10 + "s" : "—";
        document.getElementById("hudSelection").textContent = result.selectedLayers || 0;
        document.getElementById("hudFrames").textContent = result.compName ? result.totalFrames : "—";
        document.getElementById("hudWorkArea").textContent = result.compName ? Math.round(result.workAreaDuration * 10) / 10 + "s" : "—";
        document.getElementById("hudRenderer").textContent = result.renderer || "—";
        document.getElementById("hudMb").textContent = result.compName ? (result.motionBlur ? "HB AÇIK" : "HB KAPALI") : "HB —";
        document.getElementById("hudProgress").style.width = result.duration ? Math.min(100, result.time / result.duration * 100) + "%" : "0%";
        document.getElementById("hudTime").textContent = timecode(result.time, result.fps);
        document.getElementById("diagnosticTitle").textContent = result.compName || "Kompozisyon bekleniyor";
        document.getElementById("diagnosticText").textContent = result.compName ? result.width + " × " + result.height + " • " + (Math.round(result.fps * 100) / 100) + " fps • " + result.renderer + " • " + result.selectedLayers + " katman seçili" : "Aktif kompozisyon açıldığında canlı proje bilgileri burada görünür.";
      } else {
        aeStatus.textContent = result.offline ? "ÖNİZLEME MODU" : "AE HAZIR DEĞİL";
        compStatus.textContent = result.message || "Bağlantı kurulamadı";
      }
    });
  }

  function initSettings() {
    var accents = {
      blue: ["#118cff", "#15c8ff"],
      cyan: ["#00aeb8", "#35f4e8"],
      violet: ["#7652ff", "#b68cff"],
      orange: ["#f05b21", "#ffb13b"]
    };
    var savedAccent = localStorage.getItem("dromocob.accent") || "blue";
    function applyAccent(name) {
      var colors = accents[name] || accents.blue;
      document.documentElement.style.setProperty("--blue", colors[0]);
      document.documentElement.style.setProperty("--cyan", colors[1]);
      document.querySelectorAll("#accentPicker button").forEach(function (button) { button.classList.toggle("active", button.dataset.accent === name); });
      localStorage.setItem("dromocob.accent", name);
    }
    document.querySelectorAll("#accentPicker button").forEach(function (button) { button.addEventListener("click", function () { applyAccent(button.dataset.accent); }); });
    applyAccent(savedAccent);

    var motion = document.getElementById("motionSetting");
    var compact = document.getElementById("compactSetting");
    var autoUpdate = document.getElementById("autoUpdateSetting");
    var rememberPage = document.getElementById("rememberPageSetting");
    var language = document.getElementById("languageSetting");
    var uiScale = document.getElementById("uiScaleSetting");
    motion.checked = localStorage.getItem("dromocob.motion") !== "off";
    compact.checked = localStorage.getItem("dromocob.compact") === "on";
    autoUpdate.checked = localStorage.getItem("dromocob.autoUpdate") !== "off";
    rememberPage.checked = localStorage.getItem("dromocob.rememberPage") !== "off";
    language.value = localStorage.getItem("dromocob.language") || "tr";
    uiScale.value = localStorage.getItem("dromocob.uiScale") || "1";
    document.body.classList.toggle("reduce-motion", !motion.checked);
    document.body.classList.toggle("compact-mode", compact.checked);
    document.body.style.zoom = uiScale.value;
    motion.addEventListener("change", function () { document.body.classList.toggle("reduce-motion", !motion.checked); localStorage.setItem("dromocob.motion", motion.checked ? "on" : "off"); });
    compact.addEventListener("change", function () { document.body.classList.toggle("compact-mode", compact.checked); localStorage.setItem("dromocob.compact", compact.checked ? "on" : "off"); });
    autoUpdate.addEventListener("change", function () { localStorage.setItem("dromocob.autoUpdate", autoUpdate.checked ? "on" : "off"); });
    rememberPage.addEventListener("change", function () { localStorage.setItem("dromocob.rememberPage", rememberPage.checked ? "on" : "off"); if (!rememberPage.checked) localStorage.removeItem("dromocob.lastPage"); });
    language.addEventListener("change", function () { if (window.DromocobI18n) DromocobI18n.setLanguage(language.value); toast(language.value === "en" ? "Interface language set to English." : "Arayüz dili Türkçe olarak ayarlandı."); });
    uiScale.addEventListener("change", function () { document.body.style.zoom = uiScale.value; localStorage.setItem("dromocob.uiScale", uiScale.value); });

    var defaultDuration = Number(localStorage.getItem("dromocob.defaultDuration")) || 8;
    var defaultIntensity = Number(localStorage.getItem("dromocob.defaultIntensity")) || 30;
    document.getElementById("duration").value = defaultDuration;
    document.getElementById("intensity").value = defaultIntensity;
    document.getElementById("intensityValue").value = defaultIntensity;
    document.getElementById("defaultDuration").value = defaultDuration;
    document.getElementById("defaultIntensity").value = defaultIntensity;
    document.getElementById("defaultDuration").addEventListener("change", function (event) { localStorage.setItem("dromocob.defaultDuration", event.target.value); document.getElementById("duration").value = event.target.value; });
    document.getElementById("defaultIntensity").addEventListener("change", function (event) { localStorage.setItem("dromocob.defaultIntensity", event.target.value); document.getElementById("intensity").value = event.target.value; document.getElementById("intensityValue").value = event.target.value; });
    document.getElementById("resetSettings").addEventListener("click", function () {
      ["dromocob.accent", "dromocob.motion", "dromocob.compact", "dromocob.defaultDuration", "dromocob.defaultIntensity", "dromocob.language", "dromocob.uiScale", "dromocob.autoUpdate", "dromocob.rememberPage", "dromocob.lastPage"].forEach(function (key) { localStorage.removeItem(key); });
      applyAccent("blue"); motion.checked = true; compact.checked = false; autoUpdate.checked = true; rememberPage.checked = true; language.value = "tr"; uiScale.value = "1"; document.body.style.zoom = "1";
      document.body.classList.remove("reduce-motion", "compact-mode");
      if (window.DromocobI18n) DromocobI18n.setLanguage("tr");
      toast("Arayüz ayarları sıfırlandı.");
    });
    if (rememberPage.checked) {
      var lastPage = localStorage.getItem("dromocob.lastPage");
      var lastButton = lastPage && document.querySelector('.nav-item[data-page="' + lastPage + '"]');
      if (lastButton) lastButton.click();
    }
  }

  function applyLut(path) {
    hostCall("applyLut", {
      path: path,
      adjustment: document.getElementById("lutAdjustment").checked,
      strength: Number(document.getElementById("lutStrength").value) || 100
    });
  }

  function init() {
    renderTools();
    initNavigation();
    CurveStudio.init();
    initGlobalActions();
    initSettings();
    updateTextPreview();
    updateGlowPreview();
    window.DromocobApp = { toast: toast, applyLut: applyLut };
    LutStudio.init();
    if (window.CarouselLab) CarouselLab.init();
    updateContext();
    if (window.DromocobLicense) DromocobLicense.init();
    if (window.DromocobPacks) DromocobPacks.init();
    if (window.DromocobI18n) DromocobI18n.init();
    setInterval(updateContext, 6000);
  }

  window.DromocobApp = { toast: toast, applyLut: applyLut };
  document.addEventListener("DOMContentLoaded", init);
})();
