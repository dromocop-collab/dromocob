(function () {
  "use strict";
  var current = localStorage.getItem("dromocob.language") || "tr", applying = false, observer;
  var pairs = [
    ["YARATICI SİSTEM", "CREATIVE SYSTEM"], ["Araçlar", "Tools"], ["Ana", "Home"], ["Geçişler", "Transitions"], ["3D Döngü", "3D Carousel"], ["Eğriler", "Curves"], ["Efektler", "Effects"], ["Parlama", "Glow"], ["Sarsıntı", "Shake"], ["Kare", "Frame"], ["Metin", "Text"], ["Paketler", "Packs"], ["Kılavuz", "Guide"], ["Ayarlar", "Settings"], ["Lisans", "License"],
    ["Kontrol Merkezi", "Command Center"], ["Geçiş Laboratuvarı", "Transition Lab"], ["3D Döngü Laboratuvarı", "3D Carousel Lab"], ["Ultra Ayarlar", "Ultra Settings"], ["Dromocob License Cloud", "Dromocob License Cloud"],
    ["SÜRE", "DURATION"], ["YOĞUNLUK", "INTENSITY"], ["KOMPOZİSYON YOK", "NO COMPOSITION"], ["BOYUT", "SIZE"], ["SEÇİLİ", "SELECTED"], ["ÇALIŞMA", "WORK AREA"], ["AE BAĞLANIYOR", "CONNECTING TO AE"], ["Aktif kompozisyon bekleniyor", "Waiting for an active composition"],
    ["ULTRA AYARLAR", "ULTRA SETTINGS"], ["Panel görünümü, davranış ve proje tercihleri", "Panel appearance, behavior and project preferences"], ["ARAYÜZ DİLİ", "INTERFACE LANGUAGE"], ["Tüm panel dilini anında değiştir.", "Change the entire panel language instantly."], ["Dil", "Language"], ["Türkçe", "Turkish"], ["ARAYÜZ RENGİ", "ACCENT COLOR"], ["Panelin enerji rengini seç.", "Choose the panel energy color."],
    ["CANLI ANİMASYON", "LIVE ANIMATION"], ["Önizleme hareketlerini yönet.", "Control preview motion."], ["KOMPAKT MOD", "COMPACT MODE"], ["Daha fazla kartı ekranda göster.", "Show more cards on screen."], ["VARSAYILANLAR", "DEFAULTS"], ["Yeni açılışta süre ve yoğunluk.", "Duration and intensity on launch."], ["Yoğunluk", "Intensity"], ["ARAYÜZ ÖLÇEĞİ", "INTERFACE SCALE"], ["Panel yoğunluğunu ekranına uyarla.", "Fit panel density to your display."], ["Ölçek", "Scale"],
    ["OTOMATİK GÜNCELLEME", "AUTOMATIC UPDATES"], ["Açılışta güvenli sürüm kontrolü yap.", "Check securely for updates on launch."], ["SON MODÜLÜ HATIRLA", "REMEMBER LAST MODULE"], ["Paneli kaldığın araçta yeniden aç.", "Reopen the panel on your last tool."], ["Aktif", "Active"], ["PROJE DURUMU", "PROJECT STATUS"], ["Kompozisyon bekleniyor", "Waiting for composition"], ["Aktif kompozisyon açıldığında canlı proje bilgileri burada görünür.", "Live project information appears here when a composition is active."], ["HAREKET BULANIKLIĞINI AÇ", "ENABLE MOTION BLUR"], ["GÜVENLİ ALAN", "SAFE AREA"], ["AYARLARI SIFIRLA", "RESET SETTINGS"],
    ["GEÇİŞ LABORATUVARI", "TRANSITION LAB"], ["64 profesyonel preset • 8 kategori • tek tıkla", "64 professional presets • 8 categories • one click"], ["DROMOCOB HAREKET MOTORU", "DROMOCOB MOTION ENGINE"], ["64 hareket karakteri.", "64 motion styles."], ["Tek yaratıcı motor.", "One creative engine."], ["KAMERA", "CAMERA"], ["SAVURMA", "WHIP"], ["DÖNÜŞ", "SPIN"], ["IŞIK", "LIGHT"], ["DİJİTAL", "DIGITAL"], ["ŞEKİL", "SHAPE"], ["DARBE", "IMPACT"], ["ARAMA SONUÇLARI", "SEARCH RESULTS"], ["Katmanı seç, zaman göstergesini kesime getir ve kategoriden geçişini uygula.", "Select a layer, move the playhead to the cut and apply a transition from a category."], ["Sinematik kadraj hareketleri", "Cinematic framing moves"], ["Hızlı yönlü kesmeler", "Fast directional cuts"], ["Spin, roll ve burgu hareketleri", "Spin, roll and twist moves"], ["Flare, burn ve enerji kaplamaları", "Flare, burn and energy overlays"], ["Glitch ve sinyal bozulmaları", "Glitch and signal distortions"], ["Geometrik maskesiz silmeler", "Geometric procedural wipes"], ["Optik ve yönlü bulanıklıklar", "Optical and directional blurs"], ["Beat ve vurgu odaklı hareketler", "Beat and impact focused moves"], ["Geçiş ara", "Search transitions"], ["UYGULA ↗", "APPLY ↗"], ["İPUCU", "TIP"], ["Süre ve yoğunluğu sol panelden canlı ayarla.", "Adjust duration and intensity live from the left panel."], ["Presetler seçili layer üzerinde non-destructive anahtar kareler ve güvenli AE efektleri üretir.", "Presets create non-destructive keyframes and safe AE effects on the selected layer."],
    ["HIZLI AKSİYONLAR", "QUICK ACTIONS"], ["Seçili katman üzerinde çalışır", "Works on the selected layer"], ["Ayar Katmanı", "Adjustment Layer"], ["Null Kontrolcü", "Null Controller"], ["Ön Kompozisyon", "Pre-compose"], ["Güvenli Alan", "Safe Area"], ["FFX Aç", "Open FFX"],
    ["SES VE VFX STÜDYOSU", "AUDIO & VFX STUDIO"], ["SES DOSYASI İÇE AKTAR", "IMPORT AUDIO FILE"], ["Henüz SFX paketi yok", "No SFX pack installed"], ["Paket Merkezi’nden bir ses paketi indir veya kendi dosyanı içe aktar", "Download an audio pack from Pack Center or import your own file"], ["SES ANALİZİ VE RİTİM ARAÇLARI", "AUDIO ANALYSIS & RHYTHM TOOLS"], ["SES KATMANI SEÇ", "SELECT AUDIO LAYER"], ["HASSASİYET", "SENSITIVITY"], ["MİNİMUM MARKER ARALIĞI", "MINIMUM MARKER GAP"], ["BEAT MARKER", "BEAT MARKERS"], ["BASS / IMPACT MARKER", "BASS / IMPACT MARKERS"], ["MARKERLARI TEMİZLE", "CLEAR MARKERS"],
    ["PAKET MERKEZİ VE GÜNCELLEMELER", "PACK CENTER & UPDATES"], ["GÜNCELLEME KONTROL ET", "CHECK FOR UPDATES"], ["Ek Paketler", "Add-on Packs"], ["GÜNCELLE", "UPDATE"], ["KURULUYOR", "INSTALLING"], ["YENİDEN BAŞLATILIYOR", "RESTARTING"],
    ["3D DÖNGÜ LABORATUVARI", "3D CAROUSEL LAB"], ["Parametrik kart sistemleri • kaynakları korur • kontrolcüyle yönetilir", "Parametric card systems • preserves sources • controller driven"], ["HAZIR", "READY"], ["Katmanlarını", "Take your layers"], ["3D dünyaya", "into the 3D world"], ["Sistem seç", "Choose system"], ["Hızlı ayarla", "Quick setup"], ["Oluştur", "Create"], ["Akıllı", "Smart"], ["Dikey 9:16", "Portrait 9:16"], ["Yatay 16:9", "Landscape 16:9"], ["MEDYAYLA DOLDUR", "FILL WITH MEDIA"], ["MEDYAYI DEĞİŞTİR", "REPLACE MEDIA"], ["KAMERA OLUŞTUR", "CREATE CAMERA"], ["YÖNÜ TERS ÇEVİR", "REVERSE DIRECTION"], ["RASTGELE AYARLA", "RANDOMIZE"], ["SIFIRLA", "RESET"], ["DÖNGÜYÜ KALDIR", "REMOVE CAROUSEL"], ["PROFESYONEL HAZIR AYARLAR", "PROFESSIONAL PRESETS"],
    ["EĞRİ HAZIR AYARLARI", "CURVE PRESETS"], ["ANINDA EĞRİ", "LIVE CURVE"], ["Kopyala", "Copy"], ["Yapıştır", "Paste"], ["EĞRİYİ UYGULA", "APPLY CURVE"], ["EFEKT LABORATUVARI", "EFFECT LAB"], ["Yerleşik AE efektleri • hızlı ve güvenli", "Native AE effects • fast and safe"], ["HAZIR EFEKT ZİNCİRLERİ", "EFFECT STACK PRESETS"], ["TEKİL EFEKTLER", "INDIVIDUAL EFFECTS"],
    ["PARLAMA LABORATUVARI PRO", "GLOW LAB PRO"], ["CANLI IŞIK ÖNİZLEMESİ", "LIVE LIGHT PREVIEW"], ["RENK", "COLOR"], ["KARIŞIM", "BLEND"], ["Normal", "Normal"], ["Ekle", "Add"], ["Ekran", "Screen"], ["EŞİK", "THRESHOLD"], ["YARIÇAP", "RADIUS"], ["İKİNCİL IŞIK", "SECONDARY LIGHT"], ["Pulse animasyonu ekle", "Add pulse animation"], ["PARLAMA UYGULA", "APPLY GLOW"], ["DROMOCOB PARLAMAYI TEMİZLE", "REMOVE DROMOCOB GLOW"], ["IŞIK KARAKTERLERİ", "LIGHT STYLES"],
    ["SARSINTI MOTORU", "SHAKE ENGINE"], ["Frekans", "Frequency"], ["Pozisyon", "Position"], ["Rotasyon", "Rotation"], ["UYGULA", "APPLY"], ["TEMİZLE", "CLEAR"], ["KARE VE FORMAT", "FRAME & FORMAT"], ["Sosyal medya ve sinematik kompozisyonlar", "Social media and cinematic compositions"], ["Sinematik Siyah Bant", "Cinematic Letterbox"], ["Güvenli Alan Kılavuzu", "Safe Area Guide"],
    ["3D METİN STÜDYOSU", "3D TEXT STUDIO"], ["METİN", "TEXT"], ["YAZI TİPİ", "FONT"], ["HİZALAMA", "ALIGNMENT"], ["Orta", "Center"], ["Sol", "Left"], ["Sağ", "Right"], ["HARF ARALIĞI", "TRACKING"], ["SATIR ARALIĞI", "LEADING"], ["KENARLIK", "STROKE"], ["DERİNLİK", "DEPTH"], ["Büyük harf", "All caps"], ["Yapay kalınlık", "Faux bold"], ["YENİ METİN OLUŞTUR", "CREATE NEW TEXT"], ["SEÇİLİYİ GÜNCELLE", "UPDATE SELECTED"], ["CANLI 3D ÖNİZLEMESİ", "LIVE 3D PREVIEW"], ["3D METİN KARAKTERLERİ", "3D TEXT STYLES"], ["HIZLI METİN HAREKETLERİ", "QUICK TEXT MOTIONS"],
    ["LUT STÜDYOSU", "LUT STUDIO"], ["KLASÖR SEÇ", "CHOOSE FOLDER"], ["TEK LUT", "SINGLE LUT"], ["Tümü", "All"], ["Favori", "Favorites"], ["Klasör seçilmedi", "No folder selected"], ["LUT arşivini bağla", "Connect LUT library"], ["Ayar katmanı", "Adjustment layer"], ["SEÇİLİ LUT'U UYGULA", "APPLY SELECTED LUT"],
    ["KILAVUZ", "GUIDE"], ["Hedefi seç", "Select target"], ["Aracı aç", "Open tool"], ["Canlı ayarla", "Tune live"], ["Uygula", "Apply"],
    ["DROMOCOB DESTEK MERKEZİ", "DROMOCOB SUPPORT CENTER"], ["Lisans için yanındayız.", "We are here for your license."], ["Satın alma, aktivasyon ve cihaz taşıma işlemlerinde doğrudan destek al.", "Get direct support for purchases, activation and device transfers."], ["WHATSAPP DESTEK", "WHATSAPP SUPPORT"], ["RESMİ WEB SİTESİ", "OFFICIAL WEBSITE"],
    ["Ultra’yı etkinleştir.", "Activate Ultra."], ["LİSANS ANAHTARI", "LICENSE KEY"], ["CİHAZI ETKİNLEŞTİR", "ACTIVATE DEVICE"], ["DENEMEYİ BAŞLAT", "START TRIAL"], ["DOĞRULA", "VALIDATE"], ["LİSANS YÖNETİMİ", "LICENSE MANAGEMENT"], ["Cihaz durumu hazırlanıyor", "Preparing device status"], ["ÜRÜN", "PRODUCT"], ["CİHAZ", "DEVICE"], ["PLAN", "PLAN"], ["ÇEVRİMDIŞI ERİŞİM", "OFFLINE ACCESS"], ["LİSANSI DOĞRULA", "VALIDATE LICENSE"], ["BU CİHAZI KALDIR", "REMOVE THIS DEVICE"], ["PASİF", "INACTIVE"], ["AKTİF", "ACTIVE"]
  ];
  var trToEn = {}, enToTr = {};
  pairs.forEach(function (pair) { trToEn[pair[0]] = pair[1]; enToTr[pair[1]] = pair[0]; });

  function dynamic(value, language) {
    if (language === "en") {
      return value.replace(/^Sürüm ([\w.-]+) • Güncel$/, "Version $1 • Up to date").replace(/^Yeni sürüm ([\w.-]+) hazır$/, "Version $1 available").replace(/^(\d+) KARE$/, "$1 FRAMES").replace(/^(\d+) geçiş bulundu$/, "$1 transitions found");
    }
    return value.replace(/^Version ([\w.-]+) • Up to date$/, "Sürüm $1 • Güncel").replace(/^Version ([\w.-]+) available$/, "Yeni sürüm $1 hazır").replace(/^(\d+) FRAMES$/, "$1 KARE").replace(/^(\d+) transitions found$/, "$1 geçiş bulundu");
  }

  function translateTextNode(node, language) {
    if (!node || !node.nodeValue || /^(SCRIPT|STYLE)$/.test(node.parentNode && node.parentNode.nodeName)) return;
    var raw = node.nodeValue, trimmed = raw.trim(); if (!trimmed) return;
    var translated = language === "en" ? (trToEn[trimmed] || dynamic(trimmed, "en")) : (enToTr[trimmed] || dynamic(trimmed, "tr"));
    if (translated !== trimmed) node.nodeValue = raw.replace(trimmed, translated);
  }

  function apply(language) {
    current = language === "en" ? "en" : "tr"; localStorage.setItem("dromocob.language", current); document.documentElement.lang = current;
    if (applying) return; applying = true;
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false), node;
    while ((node = walker.nextNode())) translateTextNode(node, current);
    document.querySelectorAll("[placeholder],[title],[data-title]").forEach(function (element) {
      ["placeholder", "title", "data-title"].forEach(function (attribute) { if (!element.hasAttribute(attribute)) return; var value = element.getAttribute(attribute); var translated = current === "en" ? (trToEn[value] || dynamic(value, "en")) : (enToTr[value] || dynamic(value, "tr")); element.setAttribute(attribute, translated); });
    });
    var select = document.getElementById("languageSetting"); if (select) select.value = current;
    applying = false;
  }

  function init() {
    apply(current);
    if (observer) observer.disconnect();
    observer = new MutationObserver(function (records) { if (applying) return; records.forEach(function (record) { if (record.type === "characterData") translateTextNode(record.target, current); else Array.prototype.forEach.call(record.addedNodes || [], function (added) { if (added.nodeType === 3) translateTextNode(added, current); else if (added.querySelectorAll) apply(current); }); }); });
    observer.observe(document.body, { childList: true, characterData: true, subtree: true });
  }
  window.DromocobI18n = { init: init, setLanguage: apply, language: function () { return current; } };
})();
